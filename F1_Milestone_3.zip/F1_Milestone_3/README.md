# Formula 1 Milestone 3 — Member 1 Team Handoff

This is a **cleaned handoff copy** of the user's latest Member 1 project, prepared for teammates. It contains the current NLP and knowledge-graph retrieval code, tests, evaluation scripts/data/results, and handoff reports. No credentials or local virtual environment are included.

## Scope

Member 1 implements rule-based and neural intent classification, entity extraction and validation, and parameterized read-only Neo4j retrieval. The working pipeline has 11 supported Neo4j question-type routes. **This is not the full end-to-end team application.** The saved Milestone 1 prediction model, complete LLM layer, session cache, and Streamlit UI are not supplied in this archive. Integrate these with the other members' work.

The 13-label embedding classifier (`src/f1_assistant/nlp/question_type_embedding.py`) is for comparison/evaluation. The main assistant's routing remains primarily rule-based; broad neural suggestions do not authorize arbitrary Cypher. Review that division before integrating.

## Initial setup (Windows PowerShell)

From the `F1_Milestone_3` root:

```powershell
py -3.13 -m venv .venv
.\.venv\Scripts\python.exe -m pip install --upgrade pip
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
Copy-Item .\.env.example .\.env
```

Edit **your own** `.env` locally with real Neo4j credentials. Never send that file in chat or commit it. Teammates must obtain authorized connection details from the database owner. The original user's credentials have intentionally been excluded.

Example configuration file fields: `NEO4J_URI`, `NEO4J_USERNAME`, `NEO4J_PASSWORD`, optionally `NEO4J_DATABASE`. A successful connection requires permission to read the existing Milestone 2 knowledge graph; this package does not include the graph database itself.

Run the tests:

```powershell
$env:PYTHONPATH = (Resolve-Path .\src).Path
.\.venv\Scripts\python.exe -m unittest discover -s .\tests\member1 -p "test_*.py" -q
```

Check against the authorized live database:

```powershell
.\.venv\Scripts\python.exe .\tests\member1\verify_step2a_live.py
.\.venv\Scripts\python.exe .\tests\member1\verify_step2c_live.py
```

Evaluate classification (outputs will be generated in `evaluation/member1/`):

```powershell
.\.venv\Scripts\python.exe .\evaluation\member1\compare_question_types.py
.\.venv\Scripts\python.exe .\evaluation\member1\evaluate_holdout_65.py
```

**Do not tune on the 65-question test set and then report it as independent again.** The 52-question set is a regression/development set and influenced the rules. Preserve the reported measurements and original question labels.

## Project structure

- `src/f1_assistant/`: contracts, NLP extractors/classifiers, pipeline, Neo4j connector, parameterized templates.
- `tests/member1/`: unit tests plus selected live-check scripts.
- `evaluation/`: question datasets, comparison scripts, saved metrics/confusion matrices and predictions.
- `docs/member1/`: PDF technical report and team integration handoff, when included.
- `docs/CURRENT_ROUTES.md`: current supported route names and team-integration notes.
- `.env.example`: blank configuration template only; `.env` is deliberately excluded.
- `requirements.txt`: Python dependencies based on the developer's installed environment (Python 3.13). Teammates may need platform-compatible versions if not using Python 3.13.

## Verified status at handoff

- **175 unit tests** passed on the user's Windows Python 3.13 setup (recorded in chat).
- **11/11 live Neo4j routes** returned answered results with evidence, read-only Cypher trace, and parameters (recorded in chat).
- On the preserved 65-question, 13-label post-development set: **rule-based 27/65 (41.54%, macro-F1 0.5342)**; **neural embedding 47/65 (72.31%, macro-F1 0.7509)**. These are comparison results, not a performance guarantee for new users.
- The five out-of-scope questions in that set were safely abstained on, not explicitly labeled OUT_OF_SCOPE. That distinction matters for the Streamlit and evaluation layers.

See `docs/member1/Member1_Technical_Report.pdf` and `docs/member1/Member1_Team_Handoff.pdf` for implementation detail and limitations.

## Security and collaboration

- Do not commit `.env`, credentials, virtual environments, caches, or backup snapshots.
- Do not add user text to constructed Cypher queries. Use the existing parameterized templates.
- Empty results, ambiguous names, and missing required entities require refusal/clarification rather than invented facts.
- For the final Milestone 3 hand-in, include other members' prediction model/preprocessing, LLM, and Streamlit work separately, with the required report and a current README.
