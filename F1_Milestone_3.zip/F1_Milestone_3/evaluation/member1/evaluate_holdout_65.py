"""Run rule-based and neural classifiers on a frozen 65-question test set.

Run from the F1_Milestone_3 root:
  $env:PYTHONPATH = (Resolve-Path .\\src).Path
  .\\.venv\\Scripts\\python.exe .\\evaluation\\member1\\evaluate_holdout_65.py

Do not modify classifier rules/examples/thresholds based on these results and
continue calling this set 'untouched'. Once observed, this set is no longer
suitable for unbiased re-evaluation following any changes motivated by it.
"""
from __future__ import annotations

import csv
import hashlib
import json
from pathlib import Path

from sklearn.metrics import accuracy_score, classification_report, confusion_matrix, f1_score

from f1_assistant.nlp.rule_based import classify_intent
from f1_assistant.nlp.question_type_embedding import LABELS, QuestionTypeEmbeddingClassifier

ROOT = Path(__file__).resolve().parents[2]
DATA = ROOT / 'evaluation' / 'member1' / 'intent_holdout_65.jsonl'
OUT = ROOT / 'evaluation' / 'member1' / 'results_holdout_65'
CHECKSUM = '7a1141947462d9db567e15fb1aa9377ee0053c2e8eb8f82d6f1d3369375881b0'
UNKNOWN = 'UNKNOWN'


def main() -> None:
    raw = DATA.read_bytes()
    actual_hash = hashlib.sha256(raw).hexdigest()
    if actual_hash != CHECKSUM:
        raise SystemExit(f'STOP: Test-set checksum changed ({actual_hash}). Do not run on an edited holdout.')
    records = [json.loads(line) for line in raw.decode('utf-8-sig').splitlines() if line.strip()]
    if len(records) != 65:
        raise SystemExit('STOP: Expected 65 labeled questions')
    if {r['expected_question_type'] for r in records} != set(LABELS):
        raise SystemExit('STOP: Gold types do not match the classifier label set')
    if any(sum(r['expected_question_type'] == label for r in records) != 5 for label in LABELS):
        raise SystemExit('STOP: Expected 5 questions per type')
    if len({r['question'].casefold() for r in records}) != 65:
        raise SystemExit('STOP: Duplicate question detected')

    print('Dataset:', DATA)
    print('Questions:', len(records))
    print('Labels:', len(LABELS), '(five questions each)')
    print('SHA256:', actual_hash)
    print('Loading embedding classifier...')
    neural = QuestionTypeEmbeddingClassifier()

    gold, rule_pred, neural_pred = [], [], []
    results = []
    for item in records:
        rule = classify_intent(item['question'])
        embed = neural.predict(item['question'])
        expected = item['expected_question_type']
        rtype = rule.question_type or UNKNOWN
        ntype = embed.question_type or UNKNOWN
        gold.append(expected)
        rule_pred.append(rtype)
        neural_pred.append(ntype)
        results.append({
            'id': item['id'],
            'question': item['question'],
            'gold_question_type': expected,
            'gold_broad_intent': item['expected_intent'],
            'rule_question_type': rtype,
            'neural_question_type': ntype,
            'rule_correct': rtype == expected,
            'neural_correct': ntype == expected,
            'neural_abstained': embed.abstained,
            'neural_similarity': embed.similarity,
            'neural_margin': embed.margin,
        })

    OUT.mkdir(parents=True, exist_ok=True)
    all_labels = list(LABELS) + [UNKNOWN]
    report = {'dataset_sha256': actual_hash, 'questions': len(records), 'per_label_support': 5}
    for model_name, guesses in (('rule_based', rule_pred), ('neural_embedding', neural_pred)):
        correct = sum(g == p for g, p in zip(gold, guesses))
        acc = accuracy_score(gold, guesses)
        f1 = f1_score(gold, guesses, labels=list(LABELS), average='macro', zero_division=0)
        report[model_name] = {'correct': correct, 'accuracy': acc, 'macro_f1': f1}
        print(f'\n{model_name.upper()}')
        print(f'Correct: {correct}/65')
        print(f'Accuracy: {acc:.4f} ({acc:.1%})')
        print(f'Macro F1: {f1:.4f}')
        matrix = confusion_matrix(gold, guesses, labels=all_labels)
        with (OUT / f'confusion_{model_name}.csv').open('w', encoding='utf-8-sig', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(['Gold / Predicted'] + all_labels)
            for label, line in zip(all_labels, matrix):
                writer.writerow([label] + [int(v) for v in line])
        with (OUT / f'per_class_{model_name}.txt').open('w', encoding='utf-8') as f:
            f.write(classification_report(gold, guesses, labels=list(LABELS), zero_division=0))

    abstentions = neural_pred.count(UNKNOWN)
    out_of_scope_indices = [i for i, x in enumerate(gold) if x == 'out_of_scope']
    report['neural_abstentions'] = abstentions
    report['out_of_scope'] = {
        'total': len(out_of_scope_indices),
        'rule_explicit_refusals': sum(rule_pred[i] == 'out_of_scope' for i in out_of_scope_indices),
        'rule_safe_abstentions': sum(rule_pred[i] == UNKNOWN for i in out_of_scope_indices),
        'neural_safe_abstentions': sum(neural_pred[i] == UNKNOWN for i in out_of_scope_indices),
        'neural_in_domain_false_positive': sum(neural_pred[i] not in ('out_of_scope', UNKNOWN) for i in out_of_scope_indices),
    }
    print('\nNeural abstentions:', abstentions)
    print('Out-of-scope cases:', len(out_of_scope_indices))
    print('Rule-based explicit out-of-scope:', report['out_of_scope']['rule_explicit_refusals'])
    print('Rule-based safe abstentions:', report['out_of_scope']['rule_safe_abstentions'])
    print('Neural safe abstentions:', report['out_of_scope']['neural_safe_abstentions'])
    print('Neural incorrect in-domain labels on out-of-scope:', report['out_of_scope']['neural_in_domain_false_positive'])

    with (OUT / 'predictions.csv').open('w', encoding='utf-8-sig', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=list(results[0].keys()))
        writer.writeheader()
        writer.writerows(results)
    (OUT / 'metrics.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    (OUT / 'methodology_note.txt').write_text(
        'Fresh 65-item, 13-label post-development evaluation, 5 items per label.\n'
        'Questions are not copied from the prior 52/66 question datasets.\n'
        'They were authored after the project implementation was inspected, so this is\n'
        'not as strong as a separate assessor-authored blind evaluation.\n'
        'Do not tune on these outcomes then claim an independent final estimate.\n'
        'Neural similarity-only OUT_OF_SCOPE classification is prohibited; neural UNKNOWN\n'
        'is a safe abstention, though it is an exact-label error for OUT_OF_SCOPE.\n'
        f'SHA256: {actual_hash}\n',
        encoding='utf-8',
    )
    print('\nSaved results to:', OUT)
    print('Do not tune classifiers using these questions if reporting this as a holdout.')


if __name__ == '__main__':
    main()
