"""Side-by-side 13-label intent comparison on the *development* 52-item set.

Run from project root with PYTHONPATH=src. This does not edit the labeled set.
The 52 questions were used for tuning: outputs are NOT an untouched final test.
"""
from __future__ import annotations

import csv
import hashlib
import json
from collections import Counter
from pathlib import Path

from f1_assistant.nlp.rule_based import classify_intent
from f1_assistant.nlp.question_type_embedding import (
    LABELS, QuestionTypeEmbeddingClassifier,
)

ROOT = Path(__file__).resolve().parents[2]
DATA = ROOT / "evaluation" / "member1" / "intent_final_52.jsonl"
OUTPUT = ROOT / "evaluation" / "member1" / "results_type_aligned_dev"
UNKNOWN = "UNKNOWN"


def accuracy_and_macro_f1(gold: list[str], predicted: list[str]) -> tuple[float, float]:
    if not gold or len(gold) != len(predicted):
        raise ValueError("Gold and predicted labels must have matching nonzero lengths")
    accuracy = sum(a == b for a, b in zip(gold, predicted)) / len(gold)
    scores = []
    for label in LABELS:
        tp = sum(a == label and b == label for a, b in zip(gold, predicted))
        fp = sum(a != label and b == label for a, b in zip(gold, predicted))
        fn = sum(a == label and b != label for a, b in zip(gold, predicted))
        scores.append(2 * tp / (2 * tp + fp + fn) if (2 * tp + fp + fn) else 0.0)
    return accuracy, sum(scores) / len(scores)


def write_confusion(path: Path, gold: list[str], predicted: list[str]) -> None:
    counts = Counter(zip(gold, predicted))
    with path.open("w", encoding="utf-8-sig", newline="") as fh:
        writer = csv.writer(fh)
        columns = list(LABELS) + [UNKNOWN]
        writer.writerow(["Gold / predicted"] + columns)
        for label in LABELS:
            writer.writerow([label] + [counts[(label, p)] for p in columns])


def main() -> None:
    raw = DATA.read_bytes()
    items = [json.loads(line) for line in raw.decode("utf-8-sig").splitlines() if line.strip()]
    assert len(items) == 52, "Expected the original 52-question labeled development set"
    assert set(i["expected_question_type"] for i in items) == set(LABELS)
    assert all(sum(i["expected_question_type"] == x for i in items) == 4 for x in LABELS)
    checksum = hashlib.sha256(raw).hexdigest()
    print("Label set:", len(LABELS), "question types")
    print("Questions:", len(items))
    print("Dataset SHA256:", checksum)
    print("Loading neural sentence embeddings...")
    classifier = QuestionTypeEmbeddingClassifier()

    gold, rule, neural, rows = [], [], [], []
    for item in items:
        q = item["question"]
        r = classify_intent(q)
        n = classifier.predict(q)
        gold_label = item["expected_question_type"]
        rule_label = r.question_type or UNKNOWN
        neural_label = n.question_type or UNKNOWN
        gold.append(gold_label)
        rule.append(rule_label)
        neural.append(neural_label)
        rows.append([
            item["id"], q, gold_label, rule_label, neural_label,
            n.similarity, n.margin, n.abstained,
        ])

    OUTPUT.mkdir(parents=True, exist_ok=True)
    for name, predictions in (("rule_based", rule), ("neural_embedding", neural)):
        accuracy, f1 = accuracy_and_macro_f1(gold, predictions)
        print(f"\n{name}: {sum(a==b for a,b in zip(gold,predictions))}/52 correct")
        print(f"  accuracy: {accuracy:.4f}; macro-F1: {f1:.4f}")
        write_confusion(OUTPUT / f"confusion_{name}.csv", gold, predictions)
    print("\nNeural abstentions:", neural.count(UNKNOWN))
    print("Neural similarity-only OUT_OF_SCOPE assignments: 0 (prohibited by design)")

    with (OUTPUT / "predictions.csv").open("w", newline="", encoding="utf-8-sig") as fh:
        w = csv.writer(fh)
        w.writerow(["ID", "Question", "GoldType", "RuleType", "NeuralType", "Similarity", "Margin", "Abstained"])
        w.writerows(rows)
    (OUTPUT / "evaluation_note.txt").write_text(
        "DEVELOPMENT/REGRESSION EVALUATION ONLY.\n"
        "The 52-item dataset influenced rule-based improvements and is not an independent test.\n"
        "The same exact 13 target labels were used for both classifiers.\n"
        "Neural UNKNOWN is abstention, not a separate required intent.\n"
        "Nearest OUT_OF_SCOPE embedding forces abstention, never a categorical refusal.\n"
        f"Dataset SHA256: {checksum}\n",
        encoding="utf-8",
    )
    print("\nSaved:", OUTPUT)
    print("NOT an independent final accuracy estimate.")


if __name__ == "__main__":
    main()
