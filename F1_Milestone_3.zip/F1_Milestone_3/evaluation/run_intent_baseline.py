"""Benchmark current rule-based F1 intent classifier on a fixed, labeled holdout set.

Run from F1_Milestone_3 root after setting PYTHONPATH to .\\src:
    .\\.venv\\Scripts\\python.exe .\\evaluation\\run_intent_baseline.py

This file does not train or mutate the classifier or the knowledge graph.
"""

import json
from collections import Counter
from pathlib import Path

from f1_assistant.nlp.rule_based import classify_intent

DATASET = Path(__file__).with_name('intent_eval_66.jsonl')
OUTPUT = Path(__file__).with_name('baseline_predictions.jsonl')


def get_label(intent):
    if intent is None:
        return 'UNKNOWN'
    return getattr(intent, 'name', str(intent))


def main():
    records = [json.loads(line) for line in DATASET.read_text(encoding='utf-8').splitlines() if line.strip()]
    results = []

    for item in records:
        prediction = classify_intent(item['question'])
        predicted_intent = get_label(prediction.intent)
        predicted_qtype = prediction.question_type or ''
        result = {
            **item,
            'predicted_intent': predicted_intent,
            'predicted_question_type': predicted_qtype,
            'intent_correct': item['expected_intent'] == predicted_intent,
            'question_type_correct': item['expected_question_type'] == predicted_qtype,
        }
        results.append(result)

    labels = sorted({x['expected_intent'] for x in results} | {x['predicted_intent'] for x in results})
    n = len(results)
    intent_correct = sum(x['intent_correct'] for x in results)
    type_correct = sum(x['question_type_correct'] for x in results)

    print(f'Labeled questions: {n}')
    print(f'Broad intent accuracy: {intent_correct}/{n} ({100 * intent_correct/n:.1f}%)')
    print(f'Question-type exact accuracy: {type_correct}/{n} ({100 * type_correct/n:.1f}%)')
    print('\nPer-intent results (precision / recall / F1):')
    print(f'{"Intent":<28}{"Support":>8}{"Precision":>12}{"Recall":>10}{"F1":>10}')

    macro_f1 = []
    for label in labels:
        tp = sum(x['expected_intent']==label and x['predicted_intent']==label for x in results)
        fp = sum(x['expected_intent']!=label and x['predicted_intent']==label for x in results)
        fn = sum(x['expected_intent']==label and x['predicted_intent']!=label for x in results)
        support = tp+fn
        precision = tp/(tp+fp) if tp+fp else 0.0
        recall = tp/support if support else 0.0
        f1 = 2*precision*recall/(precision+recall) if precision+recall else 0.0
        macro_f1.append(f1)
        print(f'{label:<28}{support:>8}{precision:>12.3f}{recall:>10.3f}{f1:>10.3f}')

    print(f'\nMacro F1 (11 broad categories): {sum(macro_f1)/len(macro_f1):.3f}')
    print('\nMisclassified broad intents:')
    for x in results:
        if not x['intent_correct']:
            print(f"  {x['id']} expected={x['expected_intent']} predicted={x['predicted_intent']} | {x['question']}")

    # All predictions are preserved for error analysis and future comparison.
    OUTPUT.write_text(''.join(json.dumps(x, ensure_ascii=False)+'\n' for x in results),encoding='utf-8')
    print(f'\nPredictions written to: {OUTPUT}')
    print('Reminder: retain this evaluation set as holdout; do not train the neural model on its questions.')


if __name__ == '__main__':
    main()
