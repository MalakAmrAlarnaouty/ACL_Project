"""Evaluate the F1 semantic intent prototype on the *development* set.

This evaluation set has already been inspected and used for iteration; it is
not a blind final test set. This script never edits the labeled questions.
"""

import json
import sys
from pathlib import Path

from sklearn.metrics import accuracy_score, f1_score

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT / "src"))

from f1_assistant.nlp.embedding_classifier import EmbeddingIntentClassifier  # noqa: E402

DATASET = PROJECT_ROOT / "evaluation" / "intent_eval_66.jsonl"
OUTPUT = PROJECT_ROOT / "evaluation" / "embedding_predictions_dev_v2.jsonl"

records = [json.loads(line) for line in DATASET.read_text(encoding="utf-8").splitlines() if line.strip()]
classifier = EmbeddingIntentClassifier(min_margin=0.01)

expected, predicted, rows = [], [], []
for item in records:
    result = classifier.predict(item["question"])
    label = result.intent.value if result.intent is not None else "UNKNOWN"
    expected.append(item["expected_intent"])
    predicted.append(label)
    rows.append({
        **item,
        "predicted_intent": label,
        "similarity": result.similarity,
        "margin": result.margin,
        "abstained": result.abstained,
    })

OUTPUT.write_text(
    "".join(json.dumps(row, ensure_ascii=False) + "\n" for row in rows),
    encoding="utf-8",
)
correct = sum(truth == guess for truth, guess in zip(expected, predicted))
print("NEURAL DEVELOPMENT EVALUATION — expanded intent examples")
print("Questions:", len(records))
print("Correct:", correct)
print("Accuracy:", round(accuracy_score(expected, predicted), 3))
print("Macro F1:", round(f1_score(expected, predicted, average="macro", zero_division=0), 3))
print("Abstentions:", sum(row["abstained"] for row in rows))
print("Saved:", OUTPUT.relative_to(PROJECT_ROOT))
