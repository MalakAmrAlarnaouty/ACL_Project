
import unittest

from f1_assistant.nlp.race_extractor import (
    extract_race_entities,
)


class TestRaceExtractor(unittest.TestCase):

    def setUp(self):
        # Real race IDs previously verified in Neo4j.
        # Unit tests do not require a live connection.
        self.races = [
            {
                "race_id": 1061,
                "race_name": "British Grand Prix",
                "year": 2021,
            },
            {
                "race_id": 1083,
                "race_name": "British Grand Prix",
                "year": 2022,
            },
            {
                "race_id": 1020,
                "race_name": "German Grand Prix",
                "year": 2019,
            },
        ]

    def test_british_gp_2021(self):
        result = extract_race_entities(
            "Who won the 2021 British Grand Prix?",
            self.races,
        )

        self.assertEqual(
            result.entities["races"][0]["race_id"],
            1061,
        )
        self.assertEqual(result.missing, [])
        self.assertEqual(result.ambiguous, {})

    def test_british_gp_2022_alias(self):
        result = extract_race_entities(
            "Who won the 2022 British GP?",
            self.races,
        )

        self.assertEqual(
            result.entities["races"][0]["race_id"],
            1083,
        )

    def test_missing_year(self):
        result = extract_race_entities(
            "Who won the British Grand Prix?",
            self.races,
        )

        self.assertIn("year", result.missing)
        self.assertNotIn("races", result.entities)

    def test_race_outside_dataset(self):
        result = extract_race_entities(
            "Who won the 2025 British Grand Prix?",
            self.races,
        )

        self.assertIn("race", result.missing)
        self.assertNotIn("races", result.entities)

    def test_german_gp(self):
        result = extract_race_entities(
            "Who won the 2019 German Grand Prix?",
            self.races,
        )

        self.assertEqual(
            result.entities["races"][0]["race_id"],
            1020,
        )

    def test_multiple_years_ambiguous(self):
        result = extract_race_entities(
            "Compare the 2021 and 2022 British Grand Prix",
            self.races,
        )

        self.assertIn("year", result.ambiguous)
        self.assertEqual(
            result.ambiguous["year"],
            ["2021", "2022"],
        )

    def test_missing_race_name(self):
        result = extract_race_entities(
            "How many podiums did Leclerc get in 2022?",
            self.races,
        )

        self.assertIn("race", result.missing)

    def test_multiple_race_names(self):
        result = extract_race_entities(
            "Compare the 2021 British GP and 2019 German GP",
            self.races,
        )

        self.assertIn("race", result.ambiguous)
        self.assertEqual(
            set(result.ambiguous["race"]),
            {"British Grand Prix", "German Grand Prix"},
        )


if __name__ == "__main__":
    unittest.main()
