r"""Live, read-only Neo4j smoke test for Step 2C retrieval routes.

From the project root:
    $env:PYTHONPATH = (Resolve-Path .\src).Path
    .\.venv\Scripts\python.exe .\tests\member1\verify_step2c_live.py

Requires the user's existing .env; never prints credentials.
"""
from f1_assistant.pipeline import F1Assistant
from f1_assistant.retrieval.neo4j_client import Neo4jClient

QUESTIONS = [
    (
        "Who finished ahead more often, Lando Norris versus Daniel Ricciardo at McLaren?",
        "driver_comparison",
    ),
    (
        "What position did Lewis Hamilton qualify in at the 2021 British Grand Prix?",
        "qualifying_position",
    ),
    (
        "What was the fastest pit stop at the 2023 Qatar Grand Prix?",
        "fastest_pit_stop",
    ),
    (
        "Which drivers had different teams in 2020 versus 2021?",
        "season_team_changes",
    ),
]


def main():
    with Neo4jClient() as db:
        db.verify_connection()
        assistant = F1Assistant(db)
        for question, expected_type in QUESTIONS:
            result = assistant.ask(question)
            print("\nQUESTION:", question)
            print("STATUS:", result.get("status"))
            print("QUESTION TYPE:", result.get("question_type"))
            print("ANSWER:", result.get("answer", result.get("message")))
            print("EVIDENCE ROWS:", len(result.get("evidence", [])))
            if result.get("status") != "answered":
                raise AssertionError(
                    f"Expected grounded answer for {expected_type}, "
                    f"got {result.get('status')}: {result.get('message')}"
                )
            assert result.get("question_type") == expected_type, result
            assert result.get("evidence"), "Missing Neo4j evidence"
            assert result.get("parameters"), "Missing bound query parameters"
            assert result.get("cypher"), "Missing Cypher trace"
            # Query safety: templates must not interpolate user text.
            assert "$" in result["cypher"], "Missing parameter markers"

    print("\nPASS: 4 live Neo4j question families returned evidence-backed answers")


if __name__ == "__main__":
    main()
