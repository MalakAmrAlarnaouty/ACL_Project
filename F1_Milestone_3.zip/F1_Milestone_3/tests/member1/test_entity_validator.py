
import unittest

from f1_assistant.contracts import (
    EntityExtraction,
    Intent,
    IntentPrediction,
)
from f1_assistant.nlp.entity_validator import (
    validate_entities,
    ready_for_query,
)


class TestEntityValidator(unittest.TestCase):

    def prediction(self, intent, question_type):
        return IntentPrediction(
            intent=intent,
            method="rule_based",
            question_type=question_type,
        )

    def test_valid_driver_podium_question(self):
        prediction = self.prediction(
            Intent.DRIVER_PERFORMANCE,
            "driver_season_podiums",
        )

        extraction = EntityExtraction(
            entities={
                "drivers": [
                    {"driver_id": 1, "name": "Lewis Hamilton"}
                ],
                "years": [2021],
            }
        )

        result = validate_entities(prediction, extraction)

        self.assertTrue(ready_for_query(result))

    def test_missing_year(self):
        prediction = self.prediction(
            Intent.DRIVER_PERFORMANCE,
            "driver_season_podiums",
        )

        extraction = EntityExtraction(
            entities={
                "drivers": [
                    {"driver_id": 1, "name": "Lewis Hamilton"}
                ]
            }
        )

        result = validate_entities(prediction, extraction)

        self.assertIn("years", result.missing)
        self.assertFalse(ready_for_query(result))

    def test_ambiguous_driver(self):
        prediction = self.prediction(
            Intent.DRIVER_PERFORMANCE,
            "driver_circuit_wins",
        )

        extraction = EntityExtraction(
            entities={
                "circuits": [
                    {"circuit_id": 6, "name": "Circuit de Monaco"}
                ]
            },
            ambiguous={
                "schumacher": [
                    "Michael Schumacher",
                    "Ralf Schumacher",
                    "Mick Schumacher",
                ]
            },
        )

        result = validate_entities(prediction, extraction)

        self.assertFalse(ready_for_query(result))
        self.assertIn("schumacher", result.ambiguous)

    def test_valid_race_question(self):
        prediction = self.prediction(
            Intent.RACE_RESULTS,
            "race_winner_or_podium",
        )

        extraction = EntityExtraction(
            entities={
                "races": [
                    {
                        "race_id": 1061,
                        "name": "British Grand Prix",
                        "year": 2021,
                    }
                ]
            }
        )

        result = validate_entities(prediction, extraction)

        self.assertTrue(ready_for_query(result))

    def test_unsupported_question_type(self):
        prediction = self.prediction(
            Intent.PIT_STOP_STRATEGY,
            "unsupported_future_pit_stop_type",
        )

        extraction = EntityExtraction()

        result = validate_entities(prediction, extraction)

        self.assertIn(
            "supported_question_type",
            result.missing,
        )
        self.assertFalse(ready_for_query(result))


if __name__ == "__main__":
    unittest.main()
