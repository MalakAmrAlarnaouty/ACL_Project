
import unittest

from f1_assistant.nlp.circuit_extractor import (
    extract_circuit_entities,
)


class TestCircuitExtractor(unittest.TestCase):

    def setUp(self):
        # Representative records from our Neo4j graph.
        # These tests do not require a database connection.
        self.circuits = [
            {
                "circuit_id": 9,
                "circuit_name": "Silverstone Circuit",
                "circuit_ref": "silverstone",
            },
            {
                "circuit_id": 6,
                "circuit_name": "Circuit de Monaco",
                "circuit_ref": "monaco",
            },
            {
                "circuit_id": 14,
                "circuit_name": "Autodromo Nazionale di Monza",
                "circuit_ref": "monza",
            },
            {
                "circuit_id": 13,
                "circuit_name": "Circuit de Spa-Francorchamps",
                "circuit_ref": "spa",
            },
        ]

    def test_silverstone_alias(self):
        result = extract_circuit_entities(
            "Where is Silverstone located?",
            self.circuits,
        )

        self.assertEqual(
            result.entities["circuits"][0]["circuit_id"],
            9,
        )
        self.assertEqual(result.ambiguous, {})

    def test_monaco_alias(self):
        result = extract_circuit_entities(
            "How many wins did Hamilton have at Monaco?",
            self.circuits,
        )

        self.assertEqual(
            result.entities["circuits"][0]["circuit_id"],
            6,
        )

    def test_monza_alias(self):
        result = extract_circuit_entities(
            "Who won at Monza in 2021?",
            self.circuits,
        )

        self.assertEqual(
            result.entities["circuits"][0]["circuit_id"],
            14,
        )

    def test_full_circuit_name(self):
        result = extract_circuit_entities(
            "Where is Circuit de Spa-Francorchamps?",
            self.circuits,
        )

        self.assertEqual(
            result.entities["circuits"][0]["circuit_id"],
            13,
        )

        # The full name and its shorter alias
        # must not create duplicate matches.
        self.assertEqual(
            len(result.entities["circuits"]),
            1,
        )

    def test_multiple_circuits(self):
        result = extract_circuit_entities(
            "Compare Monaco and Silverstone",
            self.circuits,
        )

        ids = [
            item["circuit_id"]
            for item in result.entities["circuits"]
        ]

        self.assertEqual(ids, [6, 9])

    def test_missing_circuit(self):
        result = extract_circuit_entities(
            "How many points did Ferrari earn in 2021?",
            self.circuits,
        )

        self.assertEqual(result.entities, {})
        self.assertEqual(result.missing, ["circuit"])

    def test_case_insensitivity(self):
        result = extract_circuit_entities(
            "WHAT HAPPENED AT SPA IN 2021?",
            self.circuits,
        )

        self.assertEqual(
            result.entities["circuits"][0]["circuit_id"],
            13,
        )

    def test_ambiguous_alias(self):
        # Synthetic records deliberately share a reference.
        circuits = [
            {
                "circuit_id": 101,
                "circuit_name": "Alpha Circuit",
                "circuit_ref": "shared_track",
            },
            {
                "circuit_id": 102,
                "circuit_name": "Beta Circuit",
                "circuit_ref": "shared_track",
            },
        ]

        result = extract_circuit_entities(
            "Where is shared track?",
            circuits,
        )

        self.assertEqual(result.entities, {})
        self.assertIn("shared track", result.ambiguous)

        self.assertEqual(
            set(result.ambiguous["shared track"]),
            {"Alpha Circuit", "Beta Circuit"},
        )


if __name__ == "__main__":
    unittest.main()
