"""Read-only smoke test against the user's real Neo4j database.

Run from project root with PYTHONPATH=src. Never logs credentials.
"""
from f1_assistant.pipeline import F1Assistant
from f1_assistant.retrieval.neo4j_client import Neo4jClient

QUESTIONS = [
    ("How many wins did Lewis Hamilton have in the 2021 season?", "driver_season_wins"),
    ("How many races did Ferrari win in 2021?", "constructor_season_wins"),
    ("Which country is the Silverstone track in?", "circuit_location"),
]

with Neo4jClient() as db:
    db.verify_connection()
    assistant = F1Assistant(db)
    for question, expected_type in QUESTIONS:
        result = assistant.ask(question)
        print("QUESTION:", question)
        print("STATUS:", result.get("status"))
        print("QUESTION TYPE:", result.get("question_type"))
        print("ANSWER:", result.get("answer", result.get("message")))
        assert result.get("status") == "answered", result
        assert result.get("question_type") == expected_type, result
        assert result.get("evidence"), result
        print("---")
print("PASS: 3 real Neo4j routes returned evidence-backed answers")
