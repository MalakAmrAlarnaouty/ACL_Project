﻿import json
import unittest
from pathlib import Path

from f1_assistant.nlp.rule_based import classify_intent
from f1_assistant.pipeline import F1Assistant


ROOT = Path(__file__).resolve().parents[2]
DATASET = ROOT / "evaluation/member1/intent_final_52.jsonl"


class TestMember1RoutingRegression(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.records = [
            json.loads(line)
            for line in DATASET.read_text(
                encoding="utf-8-sig"
            ).splitlines()
            if line.strip()
        ]

    def test_dataset_integrity(self):
        self.assertEqual(len(self.records), 52)
        questions = [r["question"] for r in self.records]
        self.assertEqual(len(set(questions)), 52)

    def test_all_52_question_types(self):
        for record in self.records:
            with self.subTest(id=record["id"]):
                prediction = classify_intent(record["question"])
                self.assertEqual(
                    prediction.question_type,
                    record["expected_question_type"],
                )

    def test_all_52_broad_intents(self):
        for record in self.records:
            with self.subTest(id=record["id"]):
                prediction = classify_intent(record["question"])
                actual = (
                    prediction.intent.value
                    if prediction.intent is not None
                    else "UNKNOWN"
                )
                self.assertEqual(
                    actual,
                    record["expected_intent"],
                )

    def test_unknown_f1_question_not_explicitly_refused(self):
        prediction = classify_intent(
            "What was the longest Formula 1 race?"
        )
        self.assertNotEqual(
            prediction.intent.value if prediction.intent else None,
            "OUT_OF_SCOPE",
        )

    def test_retrieval_route_count(self):
        self.assertGreaterEqual(
            len(F1Assistant.SUPPORTED_QUESTION_TYPES),
            10,
        )


if __name__ == "__main__":
    unittest.main()
