"""Regression checks for the meaning of two graph-derived statistics."""
import unittest

from f1_assistant.pipeline import F1Assistant
from f1_assistant.retrieval.templates import (
    FASTEST_RACE_PIT_STOP_CYPHER,
    SEASON_TEAM_CHANGES_CYPHER,
)
from test_step2c_new_families import FakeDB


class EvidenceScopeTests(unittest.TestCase):
    def test_pit_lane_elapsed_time_is_not_stationary_stop_time(self):
        result = F1Assistant(FakeDB()).ask(
            "What was the fastest pit stop at the 2023 Qatar Grand Prix?"
        )
        self.assertEqual(result["status"], "answered", result)
        self.assertEqual(result["template_id"], "fastest_pit_stop")
        self.assertIn("pit-lane elapsed time", result["answer"])
        self.assertIn("not the stationary tyre-change time", result["answer"])
        self.assertIn("1.900 seconds", result["answer"])

    def test_team_participation_is_not_reported_as_a_certain_transfer(self):
        result = F1Assistant(FakeDB()).ask(
            "Which drivers had different teams in 2020 versus 2021?"
        )
        self.assertEqual(result["status"], "answered", result)
        self.assertIn("constructor participation", result["answer"])
        self.assertIn("not necessarily permanent transfers", result["answer"])
        self.assertIn("one-off substitute drives", result["answer"])

    def test_no_team_participation_data_is_not_overstated(self):
        result = F1Assistant(FakeDB({SEASON_TEAM_CHANGES_CYPHER: []})).ask(
            "Which drivers changed teams between 2020 and 2021?"
        )
        self.assertEqual(result["status"], "no_data", result)
        self.assertIn("differing recorded", result["message"])

    def test_pit_stop_no_data_does_not_invent_stationary_duration(self):
        result = F1Assistant(FakeDB({FASTEST_RACE_PIT_STOP_CYPHER: []})).ask(
            "What was the fastest pit stop at the 2023 Qatar Grand Prix?"
        )
        self.assertEqual(result["status"], "no_data", result)
        self.assertNotIn("seconds", result["message"])


if __name__ == "__main__":
    unittest.main()
