"""New retrieval routes: pure unit tests without external graph access."""
import unittest
from f1_assistant.contracts import Intent
from f1_assistant.pipeline import F1Assistant
from f1_assistant.retrieval.templates import (
    retrieve_driver_season_wins,
    retrieve_constructor_season_wins,
    retrieve_circuit_location,
    DRIVER_SEASON_WINS_CYPHER,
    CONSTRUCTOR_SEASON_WINS_CYPHER,
    CIRCUIT_LOCATION_CYPHER,
)

class FakeDB:
    def __init__(self, overrides=None):
        self.calls = []
        self.overrides = overrides or {}

    def run_read(self, query, parameters=None):
        parameters = parameters or {}
        if "MATCH (d:Driver)" in query and "driver_id" not in parameters:
            return [{"driver_id": 1, "first_name": "Lewis", "last_name": "Hamilton"},
                    {"driver_id": 30, "first_name": "Michael", "last_name": "Schumacher"},
                    {"driver_id": 23, "first_name": "Ralf", "last_name": "Schumacher"}]
        if "MATCH (c:Constructor)" in query and "constructor_id" not in parameters:
            return [{"constructor_id": 6, "constructor_name": "Ferrari", "constructor_ref": "ferrari"}]
        if "MATCH (c:Circuit)" in query and "circuit_id" not in parameters:
            return [{"circuit_id": 9, "circuit_name": "Silverstone Circuit", "circuit_ref": "silverstone", "city": "Silverstone", "country": "UK"}]
        if "MATCH (r:Race)" in query:
            return []
        self.calls.append((query, parameters))
        if query in self.overrides:
            return self.overrides[query]
        if query == DRIVER_SEASON_WINS_CYPHER:
            return [{"driver_id": 1, "driver": "Lewis Hamilton", "year": parameters["year"], "race_entries": 22, "wins": 8}]
        if query == CONSTRUCTOR_SEASON_WINS_CYPHER:
            return [{"constructor_id": 6, "constructor": "Ferrari", "year": parameters["year"], "race_entries": 22, "wins": 0}]
        if query == CIRCUIT_LOCATION_CYPHER:
            return [{"circuit_id": 9, "circuit": "Silverstone Circuit", "city": "Silverstone", "country": "UK"}]
        return []

class TestTemplates(unittest.TestCase):
    def test_driver_season_wins_parameterized(self):
        db=FakeDB(); r=retrieve_driver_season_wins(db, 1, 2021)
        self.assertEqual(r.intent, Intent.DRIVER_PERFORMANCE)
        self.assertEqual(r.template_id, 'driver_season_wins')
        self.assertEqual(db.calls[-1][1], {'driver_id':1, 'year':2021})
        self.assertIn('$driver_id',r.cypher)
        self.assertIn('count(DISTINCT CASE',r.cypher)

    def test_constructor_season_wins_race_dedup(self):
        db=FakeDB();r=retrieve_constructor_season_wins(db, 6, 2021)
        self.assertEqual(r.intent,Intent.CONSTRUCTOR_PERFORMANCE)
        self.assertIn('count(DISTINCT r.raceId)', r.cypher)
        self.assertEqual(db.calls[-1][1], {'constructor_id':6, 'year':2021})

    def test_circuit_location_is_bounded(self):
        db=FakeDB();r=retrieve_circuit_location(db, 9)
        self.assertEqual(r.template_id, 'circuit_location')
        self.assertIn('LIMIT 1',r.cypher)
        self.assertEqual(db.calls[-1][1],{'circuit_id':9})

class TestPipeline(unittest.TestCase):
    def test_driver_season_wins(self):
        db=FakeDB(); r=F1Assistant(db).ask('How many wins did Lewis Hamilton have in the 2021 season?')
        self.assertEqual(r['status'],'answered',r)
        self.assertEqual(r['question_type'],'driver_season_wins')
        self.assertIn('8 Grands Prix',r['answer'])
        self.assertEqual(r['parameters'],{'driver_id':1,'year':2021})

    def test_constructor_season_wins_zero_valid(self):
        r=F1Assistant(FakeDB()).ask('How many races did Ferrari win in 2021?')
        self.assertEqual(r['status'],'answered',r)
        self.assertIn('0 Grands Prix',r['answer'])

    def test_circuit_location(self):
        r=F1Assistant(FakeDB()).ask('Which country is the Silverstone track in?')
        self.assertEqual(r['status'],'answered',r)
        self.assertIn('UK',r['answer'])

    def test_no_entries_not_zero_wins(self):
        db=FakeDB({DRIVER_SEASON_WINS_CYPHER:[{'driver_id':1,'driver':'Lewis Hamilton','year':2021,'race_entries':0,'wins':0}]})
        r=F1Assistant(db).ask('How many wins did Lewis Hamilton have in 2021?')
        self.assertEqual(r['status'],'no_data',r)

    def test_no_circuit_location_is_no_data(self):
        db=FakeDB({CIRCUIT_LOCATION_CYPHER:[{'circuit_id':9,'circuit':'Silverstone Circuit','city':None,'country':None}]})
        r=F1Assistant(db).ask('Where is the Silverstone circuit located?')
        self.assertEqual(r['status'],'no_data',r)

    def test_ambiguous_driver_blocks_query(self):
        db=FakeDB();r=F1Assistant(db).ask('How many wins did Schumacher have in 2021?')
        self.assertEqual(r['status'],'needs_clarification',r)
        self.assertFalse(db.calls)

    def test_missing_year_blocks_query(self):
        db=FakeDB();r=F1Assistant(db).ask('How many wins did Lewis Hamilton have in a season?')
        self.assertEqual(r['status'],'needs_clarification',r)
        self.assertFalse(db.calls)

if __name__=='__main__':unittest.main()
