
import unittest

from f1_assistant.contracts import Intent

from f1_assistant.retrieval.templates import (
    DRIVER_SEASON_PODIUMS_CYPHER,
    retrieve_driver_season_podiums,
    CONSTRUCTOR_SEASON_POINTS_CYPHER,
    retrieve_constructor_season_points,
    RACE_WINNER_CYPHER,
    retrieve_race_winner,
    RACE_PODIUM_CYPHER,
    retrieve_race_podium,
    DRIVER_CIRCUIT_WINS_CYPHER,
    retrieve_driver_circuit_wins,
)



class FakeNeo4jClient:
    """A fake database client for isolated unit tests."""

    def __init__(self, rows=None):
        self.rows = rows if rows is not None else []
        self.last_query = None
        self.last_parameters = None

    def run_read(self, cypher, parameters=None):
        self.last_query = cypher
        self.last_parameters = parameters
        return self.rows


class TestRetrievalTemplates(unittest.TestCase):

    def test_driver_season_podiums_result(self):
        db = FakeNeo4jClient(rows=[
            {
                "driver_id": 1,
                "driver": "Lewis Hamilton",
                "year": 2021,
                "race_entries": 22,
                "podiums": 17,
            }
        ])

        result = retrieve_driver_season_podiums(
            db=db,
            driver_id=1,
            year=2021,
        )

        self.assertEqual(
            result.intent,
            Intent.DRIVER_PERFORMANCE,
        )
        self.assertEqual(
            result.template_id,
            "driver_season_podiums",
        )
        self.assertEqual(
            result.rows[0]["podiums"],
            17,
        )
        self.assertEqual(
            result.rows[0]["race_entries"],
            22,
        )

    def test_query_is_parameterized(self):
        db = FakeNeo4jClient()

        retrieve_driver_season_podiums(
            db=db,
            driver_id=1,
            year=2021,
        )

        self.assertEqual(
            db.last_parameters,
            {"driver_id": 1, "year": 2021},
        )

        self.assertIn("$driver_id", db.last_query)
        self.assertIn("$year", db.last_query)

        self.assertEqual(
            db.last_query,
            DRIVER_SEASON_PODIUMS_CYPHER,
        )

    def test_empty_database_result(self):
        db = FakeNeo4jClient(rows=[])

        result = retrieve_driver_season_podiums(
            db=db,
            driver_id=99999,
            year=2021,
        )

        self.assertEqual(result.rows, [])
        self.assertEqual(
            result.parameters["driver_id"],
            99999,
        )

    def test_parameters_are_not_reused(self):
        db = FakeNeo4jClient()

        retrieve_driver_season_podiums(
            db=db,
            driver_id=1,
            year=2021,
        )

        retrieve_driver_season_podiums(
            db=db,
            driver_id=830,
            year=2022,
        )

        self.assertEqual(
            db.last_parameters,
            {"driver_id": 830, "year": 2022},
        )

    def test_constructor_season_points_result(self):
        db = FakeNeo4jClient(rows=[
            {
                "constructor_id": 6,
                "constructor": "Ferrari",
                "year": 2021,
                "race_entries": 44,
                "points": 322.5,
            }
        ])

        result = retrieve_constructor_season_points(
            db=db,
            constructor_id=6,
            year=2021,
        )

        self.assertEqual(
            result.intent,
            Intent.CONSTRUCTOR_PERFORMANCE,
        )

        self.assertEqual(
            result.template_id,
            "constructor_season_points",
        )

        self.assertEqual(result.rows[0]["points"], 322.5)
        self.assertEqual(result.rows[0]["race_entries"], 44)

    def test_constructor_points_are_parameterized(self):
        db = FakeNeo4jClient()

        retrieve_constructor_season_points(
            db=db,
            constructor_id=6,
            year=2021,
        )

        self.assertEqual(
            db.last_parameters,
            {"constructor_id": 6, "year": 2021},
        )

        self.assertEqual(
            db.last_query,
            CONSTRUCTOR_SEASON_POINTS_CYPHER,
        )

        self.assertIn("$constructor_id", db.last_query)
        self.assertIn("$year", db.last_query)

    def test_constructor_points_empty_result(self):
        db = FakeNeo4jClient(rows=[])

        result = retrieve_constructor_season_points(
            db=db,
            constructor_id=99999,
            year=2021,
        )

        self.assertEqual(result.rows, [])
        self.assertEqual(
            result.parameters["constructor_id"],
            99999,
        )


    def test_race_winner_result(self):
        db = FakeNeo4jClient(rows=[
            {
                "race_id": 1020,
                "race": "German Grand Prix",
                "year": 2019,
                "driver_id": 830,
                "winner": "Max Verstappen",
                "finishing_position": 1,
            }
        ])

        result = retrieve_race_winner(
            db=db,
            race_id=1020,
        )

        self.assertEqual(result.intent, Intent.RACE_RESULTS)
        self.assertEqual(result.template_id, "race_winner")
        self.assertEqual(result.rows[0]["winner"], "Max Verstappen")
        self.assertEqual(result.rows[0]["finishing_position"], 1)

    def test_race_winner_is_parameterized(self):
        db = FakeNeo4jClient()

        retrieve_race_winner(
            db=db,
            race_id=1061,
        )

        self.assertEqual(
            db.last_parameters,
            {"race_id": 1061},
        )

        self.assertEqual(
            db.last_query,
            RACE_WINNER_CYPHER,
        )

        self.assertIn("$race_id", db.last_query)

    def test_race_winner_empty_result(self):
        db = FakeNeo4jClient(rows=[])

        result = retrieve_race_winner(
            db=db,
            race_id=99999,
        )

        self.assertEqual(result.rows, [])
        self.assertEqual(
            result.parameters,
            {"race_id": 99999},
        )

    def test_race_winner_preserves_multiple_records(self):
        # Synthetic historical edge case.
        # The retrieval function must not silently
        # discard records returned by Neo4j.

        db = FakeNeo4jClient(rows=[
            {
                "race_id": 100,
                "winner": "Driver A",
                "finishing_position": 1,
            },
            {
                "race_id": 100,
                "winner": "Driver B",
                "finishing_position": 1,
            },
        ])

        result = retrieve_race_winner(
            db=db,
            race_id=100,
        )

        self.assertEqual(len(result.rows), 2)

    def test_race_podium_result(self):
        db = FakeNeo4jClient(rows=[
            {
                "race_id": 1020,
                "race": "German Grand Prix",
                "year": 2019,
                "driver_id": 830,
                "driver": "Max Verstappen",
                "finishing_position": 1,
            },
            {
                "race_id": 1020,
                "race": "German Grand Prix",
                "year": 2019,
                "driver_id": 20,
                "driver": "Sebastian Vettel",
                "finishing_position": 2,
            },
            {
                "race_id": 1020,
                "race": "German Grand Prix",
                "year": 2019,
                "driver_id": 826,
                "driver": "Daniil Kvyat",
                "finishing_position": 3,
            },
        ])

        result = retrieve_race_podium(
            db=db,
            race_id=1020,
        )

        self.assertEqual(
            result.intent,
            Intent.RACE_RESULTS,
        )
        self.assertEqual(
            result.template_id,
            "race_podium",
        )
        self.assertEqual(len(result.rows), 3)

        positions = [
            row["finishing_position"]
            for row in result.rows
        ]

        self.assertEqual(positions, [1, 2, 3])

        self.assertEqual(
            result.rows[0]["driver"],
            "Max Verstappen",
        )

    def test_race_podium_is_parameterized(self):
        db = FakeNeo4jClient()

        retrieve_race_podium(
            db=db,
            race_id=1061,
        )

        self.assertEqual(
            db.last_parameters,
            {"race_id": 1061},
        )

        self.assertEqual(
            db.last_query,
            RACE_PODIUM_CYPHER,
        )

        self.assertIn("$race_id", db.last_query)

    def test_race_podium_empty_result(self):
        db = FakeNeo4jClient(rows=[])

        result = retrieve_race_podium(
            db=db,
            race_id=99999,
        )

        self.assertEqual(result.rows, [])
        self.assertEqual(
            result.parameters,
            {"race_id": 99999},
        )

    def test_race_podium_preserves_shared_drives(self):
        # Synthetic historical scenario:
        # multiple drivers share a podium position.
        db = FakeNeo4jClient(rows=[
            {
                "race_id": 100,
                "driver": "Driver A",
                "finishing_position": 1,
            },
            {
                "race_id": 100,
                "driver": "Driver B",
                "finishing_position": 2,
            },
            {
                "race_id": 100,
                "driver": "Driver C",
                "finishing_position": 2,
            },
            {
                "race_id": 100,
                "driver": "Driver D",
                "finishing_position": 3,
            },
        ])

        result = retrieve_race_podium(
            db=db,
            race_id=100,
        )

        # Do not discard the fourth record.
        self.assertEqual(len(result.rows), 4)

        self.assertEqual(
            [row["finishing_position"] for row in result.rows],
            [1, 2, 2, 3],
        )

    def test_driver_circuit_wins_all_seasons(self):
        db = FakeNeo4jClient(rows=[
            {
                "driver_id": 1,
                "driver": "Lewis Hamilton",
                "circuit_id": 6,
                "circuit": "Circuit de Monaco",
                "year": None,
                "race_entries": 17,
                "wins": 3,
            }
        ])

        result = retrieve_driver_circuit_wins(
            db=db,
            driver_id=1,
            circuit_id=6,
        )

        self.assertEqual(
            result.intent,
            Intent.DRIVER_PERFORMANCE,
        )
        self.assertEqual(
            result.template_id,
            "driver_circuit_wins",
        )
        self.assertEqual(result.rows[0]["wins"], 3)
        self.assertEqual(result.rows[0]["race_entries"], 17)
        self.assertIsNone(result.parameters["year"])

    def test_driver_circuit_wins_with_year(self):
        db = FakeNeo4jClient(rows=[
            {
                "driver_id": 1,
                "driver": "Lewis Hamilton",
                "circuit_id": 6,
                "circuit": "Circuit de Monaco",
                "year": 2021,
                "race_entries": 1,
                "wins": 0,
            }
        ])

        result = retrieve_driver_circuit_wins(
            db=db,
            driver_id=1,
            circuit_id=6,
            year=2021,
        )

        self.assertEqual(
            result.parameters,
            {
                "driver_id": 1,
                "circuit_id": 6,
                "year": 2021,
            },
        )

        self.assertEqual(result.rows[0]["wins"], 0)
        self.assertEqual(result.rows[0]["race_entries"], 1)

    def test_driver_circuit_wins_parameterization(self):
        db = FakeNeo4jClient()

        retrieve_driver_circuit_wins(
            db=db,
            driver_id=30,
            circuit_id=6,
            year=None,
        )

        self.assertEqual(
            db.last_query,
            DRIVER_CIRCUIT_WINS_CYPHER,
        )

        self.assertEqual(
            db.last_parameters,
            {
                "driver_id": 30,
                "circuit_id": 6,
                "year": None,
            },
        )

        self.assertIn("$driver_id", db.last_query)
        self.assertIn("$circuit_id", db.last_query)
        self.assertIn("$year", db.last_query)

    def test_driver_circuit_wins_empty_result(self):
        db = FakeNeo4jClient(rows=[])

        result = retrieve_driver_circuit_wins(
            db=db,
            driver_id=99999,
            circuit_id=6,
        )

        self.assertEqual(result.rows, [])
        self.assertEqual(
            result.parameters["driver_id"],
            99999,
        )

if __name__ == "__main__":
    unittest.main()
