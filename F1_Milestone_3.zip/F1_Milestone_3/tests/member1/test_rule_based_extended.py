
import unittest

from f1_assistant.contracts import Intent
from f1_assistant.nlp.rule_based import classify_intent


class TestExtendedRuleBasedClassifier(unittest.TestCase):

    def test_constructor_season_points(self):
        result = classify_intent(
            "How many points did Ferrari earn in 2021?"
        )
        self.assertEqual(
            result.intent,
            Intent.CONSTRUCTOR_SEASON_POINTS
        )

    def test_qualifying_poles(self):
        result = classify_intent(
            "How many pole positions did Verstappen have in 2023?"
        )
        self.assertEqual(
            result.intent,
            Intent.QUALIFYING_POLES
        )

    def test_fastest_pit_stop(self):
        result = classify_intent(
            "What was the fastest pit stop at the 2023 Qatar Grand Prix?"
        )
        self.assertEqual(
            result.intent,
            Intent.FASTEST_PIT_STOP
        )

    def test_head_to_head(self):
        result = classify_intent(
            "Who finished ahead more often, Hamilton or Bottas?"
        )
        self.assertEqual(result.intent, Intent.HEAD_TO_HEAD)

    def test_race_podium(self):
        result = classify_intent(
            "Who won the 2019 German Grand Prix?"
        )
        self.assertEqual(result.intent, Intent.RACE_PODIUM)

    def test_season_team_changes(self):
        result = classify_intent(
            "Which drivers changed teams between 2020 and 2021?"
        )
        self.assertEqual(
            result.intent,
            Intent.SEASON_TEAM_CHANGES
        )


if __name__ == "__main__":
    unittest.main()
