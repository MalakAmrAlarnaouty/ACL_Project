"""Regression tests for a safe, optional broad-intent neural fallback."""
import unittest
from types import SimpleNamespace
from unittest.mock import Mock, patch

from f1_assistant.contracts import Intent, IntentPrediction
from f1_assistant.pipeline import F1Assistant


class TestOptionalHybridFallback(unittest.TestCase):
    def setUp(self):
        self.db = Mock()
        loaders = (
            'load_drivers', 'load_constructors', 'load_circuits', 'load_races'
        )
        patches = [patch(f'f1_assistant.pipeline.{name}', return_value=[])
                   for name in loaders]
        for item in patches:
            item.start()
            self.addCleanup(item.stop)

    def test_old_constructor_and_unknown_behavior_still_work(self):
        assistant = F1Assistant(self.db)
        result = assistant.ask('Tell me about F1 technology?')
        self.assertEqual(result['status'], 'needs_clarification')
        self.assertNotIn('suggested_intent', result)
        self.db.run_read.assert_not_called()

    def test_neural_suggestion_never_runs_neo4j(self):
        neural = Mock()
        neural.predict.return_value = SimpleNamespace(
            intent=Intent.DRIVER_PERFORMANCE
        )
        assistant = F1Assistant(self.db, neural_classifier=neural)
        with patch('f1_assistant.pipeline.classify_intent', return_value=
                   IntentPrediction(intent=None, method='rule_based',
                                    needs_clarification=True,
                                    reason='Unknown wording.')):
            result = assistant.ask('Tell me how the racer performed.')
        self.assertEqual(result['status'], 'needs_clarification')
        self.assertEqual(result['suggested_intent'], 'DRIVER_PERFORMANCE')
        self.db.run_read.assert_not_called()

    def test_neural_out_of_scope_does_not_decide_out_of_scope(self):
        neural = Mock()
        neural.predict.return_value = SimpleNamespace(
            intent=Intent.OUT_OF_SCOPE
        )
        assistant = F1Assistant(self.db, neural_classifier=neural)
        result = assistant.ask('Can you tell me about qualifying regulations?')
        self.assertEqual(result['status'], 'needs_clarification')
        self.assertNotIn('suggested_intent', result)
        self.db.run_read.assert_not_called()

    def test_rule_out_of_scope_remains_independent(self):
        neural = Mock()
        assistant = F1Assistant(self.db, neural_classifier=neural)
        result = assistant.ask('What is the weather tomorrow?')
        self.assertEqual(result['status'], 'out_of_scope')
        neural.predict.assert_not_called()
        self.db.run_read.assert_not_called()

    def test_neural_error_fails_closed(self):
        neural = Mock()
        neural.predict.side_effect = RuntimeError('Neural engine offline')
        assistant = F1Assistant(self.db, neural_classifier=neural)
        result = assistant.ask('What can you tell me about racing?')
        self.assertEqual(result['status'], 'needs_clarification')
        self.db.run_read.assert_not_called()

    def test_recognized_rule_does_not_call_neural(self):
        neural = Mock()
        assistant = F1Assistant(self.db, neural_classifier=neural)
        result = assistant.ask('How many podiums did Leclerc get in 2022?')
        self.assertEqual(result['status'], 'needs_clarification')
        self.assertIn('missing', result)
        neural.predict.assert_not_called()
        self.db.run_read.assert_not_called()


if __name__ == '__main__':
    unittest.main()
