
import unittest

from f1_assistant.contracts import Intent
from f1_assistant.nlp.rule_based import classify_intent


class TestIntentRouting(unittest.TestCase):

    def test_all_broad_intents(self):
        cases = [
            (
                "How many podiums did Leclerc get in 2022?",
                Intent.DRIVER_PERFORMANCE,
                "driver_season_podiums",
            ),
            (
                "How many points did Ferrari earn in 2021?",
                Intent.CONSTRUCTOR_PERFORMANCE,
                "constructor_season_points",
            ),
            (
                "Who finished ahead more often, Hamilton or Bottas?",
                Intent.HEAD_TO_HEAD,
                "driver_comparison",
            ),
            (
                "Who won the 2019 German Grand Prix?",
                Intent.RACE_RESULTS,
                "race_winner_or_podium",
            ),
            (
                "Where is Silverstone located?",
                Intent.CIRCUIT_FACTS,
                "circuit_location",
            ),
            (
                "How many pole positions did Verstappen have in 2023?",
                Intent.QUALIFYING_GRID,
                "pole_positions",
            ),
            (
                "What was the fastest pit stop at the 2023 Qatar Grand Prix?",
                Intent.PIT_STOP_STRATEGY,
                "fastest_pit_stop",
            ),
            (
                "Which drivers changed teams between 2020 and 2021?",
                Intent.SEASON_HISTORY,
                "season_team_changes",
            ),
            (
                "Predict Norris at the 2024 Miami Grand Prix",
                Intent.PODIUM_PREDICTION,
                "podium_prediction",
            ),
            (
                "What is the weather tomorrow?",
                Intent.OUT_OF_SCOPE,
                "out_of_scope",
            ),
        ]

        for question, expected_intent, expected_type in cases:
            with self.subTest(question=question):
                result = classify_intent(question)

                self.assertEqual(
                    result.intent,
                    expected_intent,
                )

                self.assertEqual(
                    result.question_type,
                    expected_type,
                )

    def test_unrecognized_question_abstains(self):
        result = classify_intent(
            "How many safety cars were deployed in 2019?"
        )

        self.assertIsNone(result.intent)
        self.assertTrue(result.needs_clarification)

    def test_driver_season_wins(self):
        result = classify_intent(
            "How many wins did Verstappen have in 2023?"
        )

        self.assertEqual(
            result.intent,
            Intent.DRIVER_PERFORMANCE,
        )

        self.assertEqual(
            result.question_type,
            "driver_season_wins",
        )


    def test_constructor_reliability(self):
        questions = [
            "How reliable was Williams between 2014 and 2021?",
            "What was Ferrari's classified finish rate from 2014 to 2021?",
        ]

        for question in questions:
            with self.subTest(question=question):
                result = classify_intent(question)

                self.assertEqual(
                    result.intent,
                    Intent.CONSTRUCTOR_PERFORMANCE,
                )

                self.assertEqual(
                    result.question_type,
                    "constructor_reliability",
                )

    def test_constructor_season_wins(self):
        questions = [
            "How many races did Ferrari win in 2021?",
            "How many wins did Mercedes have in 2020?",
        ]

        for question in questions:
            with self.subTest(question=question):
                result = classify_intent(question)

                self.assertEqual(
                    result.intent,
                    Intent.CONSTRUCTOR_PERFORMANCE,
                )

                self.assertEqual(
                    result.question_type,
                    "constructor_season_wins",
                )

    def test_constructor_race_entries(self):
        questions = [
            "How many race entries did Ferrari have in 2021?",
            "How many race starts did Williams record in 2020?",
        ]

        for question in questions:
            with self.subTest(question=question):
                result = classify_intent(question)

                self.assertEqual(
                    result.intent,
                    Intent.CONSTRUCTOR_PERFORMANCE,
                )

                self.assertEqual(
                    result.question_type,
                    "constructor_race_entries",
                )

    def test_q3_appearances(self):
        questions = [
            "How many Q3 appearances did Leclerc have in 2022?",
            "How often did Verstappen reach Q3 in 2023?",
        ]

        for question in questions:
            with self.subTest(question=question):
                result = classify_intent(question)

                self.assertEqual(
                    result.intent,
                    Intent.QUALIFYING_GRID,
                )

                self.assertEqual(
                    result.question_type,
                    "q3_appearances",
                )

    def test_grid_position_gains(self):
        questions = [
            "Which driver gained the most places from the grid at Monza in 2021?",
            "How many positions did Leclerc improve from his starting position in 2022?",
        ]

        for question in questions:
            with self.subTest(question=question):
                result = classify_intent(question)

                self.assertEqual(
                    result.intent,
                    Intent.QUALIFYING_GRID,
                )

                self.assertEqual(
                    result.question_type,
                    "grid_position_gains",
                )

    def test_qualifying_position(self):
        questions = [
            "Where did Norris qualify at the 2021 Italian Grand Prix?",
            "What qualifying position did Leclerc get at Monaco in 2021?",
        ]

        for question in questions:
            with self.subTest(question=question):
                result = classify_intent(question)

                self.assertEqual(
                    result.intent,
                    Intent.QUALIFYING_GRID,
                )

                self.assertEqual(
                    result.question_type,
                    "qualifying_position",
                )

    def test_driver_pit_stop_count(self):
        questions = [
            "How many pit stops did Norris make at the 2023 Qatar Grand Prix?",
            "What was the total number of pit stops made by Hamilton in 2021?",
        ]

        for question in questions:
            with self.subTest(question=question):
                result = classify_intent(question)

                self.assertEqual(
                    result.intent,
                    Intent.PIT_STOP_STRATEGY,
                )

                self.assertEqual(
                    result.question_type,
                    "driver_pit_stop_count",
                )

    def test_average_pit_stops_per_race(self):
        questions = [
            "What was Hamilton's average number of pit stops per race in 2021?",
            "On average, how many pit stops did Norris make per race in 2023?",
        ]

        for question in questions:
            with self.subTest(question=question):
                result = classify_intent(question)

                self.assertEqual(
                    result.intent,
                    Intent.PIT_STOP_STRATEGY,
                )

                self.assertEqual(
                    result.question_type,
                    "average_pit_stops_per_race",
                )

if __name__ == "__main__":
    unittest.main()
