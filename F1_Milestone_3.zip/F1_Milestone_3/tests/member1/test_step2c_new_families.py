"""Regression tests for the four graph-retrieval families introduced in Step 2C.
All data returned by this test client are deliberately synthetic; this is NOT
live Neo4j verification.
"""
import unittest

from f1_assistant.contracts import Intent
from f1_assistant.nlp.rule_based import classify_intent
from f1_assistant.pipeline import F1Assistant
from f1_assistant.retrieval.templates import (
    DRIVER_HEAD_TO_HEAD_CYPHER,
    DRIVER_RACE_QUALIFYING_CYPHER,
    FASTEST_RACE_PIT_STOP_CYPHER,
    SEASON_TEAM_CHANGES_CYPHER,
    retrieve_driver_head_to_head,
    retrieve_driver_race_qualifying,
    retrieve_fastest_race_pit_stop,
    retrieve_season_team_changes,
)


class FakeDB:
    def __init__(self, overrides=None):
        self.calls = []
        self.overrides = overrides or {}

    def run_read(self, cypher, parameters=None):
        parameters = parameters or {}
        if "MATCH (d:Driver)" in cypher and not parameters:
            return [
                {"driver_id": 846, "first_name": "Lando", "last_name": "Norris"},
                {"driver_id": 817, "first_name": "Daniel", "last_name": "Ricciardo"},
                {"driver_id": 1, "first_name": "Lewis", "last_name": "Hamilton"},
                {"driver_id": 30, "first_name": "Michael", "last_name": "Schumacher"},
                {"driver_id": 23, "first_name": "Ralf", "last_name": "Schumacher"},
            ]
        if "MATCH (c:Constructor)" in cypher and not parameters:
            return [
                {"constructor_id": 1, "constructor_name": "McLaren", "constructor_ref": "mclaren"},
                {"constructor_id": 6, "constructor_name": "Ferrari", "constructor_ref": "ferrari"},
            ]
        if "MATCH (c:Circuit)" in cypher and not parameters:
            return [
                {"circuit_id": 9, "circuit_name": "Silverstone Circuit", "circuit_ref": "silverstone"},
            ]
        if "MATCH (r:Race)" in cypher and not parameters:
            return [
                {"race_id": 1061, "race_name": "British Grand Prix", "year": 2021},
                {"race_id": 1123, "race_name": "Qatar Grand Prix", "year": 2023},
                {"race_id": 1, "race_name": "Monaco Grand Prix", "year": 2000},
            ]
        self.calls.append((cypher, dict(parameters)))
        if cypher in self.overrides:
            return self.overrides[cypher]
        if cypher == DRIVER_HEAD_TO_HEAD_CYPHER:
            return [{
                "driver1": "Lando Norris", "driver2": "Daniel Ricciardo",
                "shared_races": 20, "driver1_ahead": 14,
                "driver2_ahead": 6, "ties": 0,
            }]
        if cypher == DRIVER_RACE_QUALIFYING_CYPHER:
            return [{
                "race": "British Grand Prix", "year": 2021,
                "driver": "Lewis Hamilton", "qualifying_position": 1,
            }]
        if cypher == FASTEST_RACE_PIT_STOP_CYPHER:
            return [{
                "race": "Qatar Grand Prix", "year": 2023,
                "driver": "Lando Norris", "stop_number": 1,
                "lap": 12, "milliseconds": 1900,
            }]
        if cypher == SEASON_TEAM_CHANGES_CYPHER:
            return [{
                "driver": "Daniel Ricciardo", "earlier_teams": ["Renault"],
                "later_teams": ["McLaren"],
            }]
        raise AssertionError("Unexpected Cypher in fake database")


class CypherContractTests(unittest.TestCase):
    def test_head_to_head_uses_both_id_parameters_and_optional_team(self):
        db = FakeDB()
        r = retrieve_driver_head_to_head(db, 846, 817, constructor_id=1)
        self.assertEqual(r.intent, Intent.HEAD_TO_HEAD)
        self.assertEqual(r.parameters, {
            "driver1_id": 846, "driver2_id": 817,
            "constructor_id": 1, "year_from": None, "year_to": None,
        })
        self.assertIn("[:FOR_CONSTRUCTOR]", r.cypher)
        self.assertIn("[:FOR_RACE]", r.cypher)
        self.assertIn("LIMIT 1", r.cypher)

    def test_refuses_to_compare_identical_driver(self):
        with self.assertRaises(ValueError):
            retrieve_driver_head_to_head(FakeDB(), 846, 846)

    def test_qualifying_template_uses_driver_and_race_ids(self):
        db = FakeDB()
        result = retrieve_driver_race_qualifying(db, 1, 1061)
        self.assertEqual(result.parameters, {"driver_id": 1, "race_id": 1061})
        self.assertIn("q.position", result.cypher)
        self.assertIn("LIMIT 2", result.cypher)

    def test_pit_stop_template_is_bounded_and_filters_missing_times(self):
        r = retrieve_fastest_race_pit_stop(FakeDB(), 1123)
        self.assertEqual(r.parameters, {"race_id": 1123})
        self.assertIn("min(p.milliseconds)", r.cypher)
        self.assertIn("p.milliseconds IS NOT NULL", r.cypher)
        self.assertIn("LIMIT 10", r.cypher)

    def test_team_change_template_compares_both_years(self):
        r = retrieve_season_team_changes(FakeDB(), 2020, 2021)
        self.assertEqual(r.parameters, {"year1": 2020, "year2": 2021})
        self.assertIn("collect(DISTINCT", r.cypher)
        self.assertIn("LIMIT 50", r.cypher)

    def test_same_season_team_change_rejected(self):
        with self.assertRaises(ValueError):
            retrieve_season_team_changes(FakeDB(), 2020, 2020)


class EndToEndMockTests(unittest.TestCase):
    def test_head_to_head_with_team_filter(self):
        db = FakeDB()
        r = F1Assistant(db).ask(
            "Who finished ahead more often, Lando Norris versus Daniel Ricciardo at McLaren?"
        )
        self.assertEqual(r["status"], "answered", r)
        self.assertEqual(r["question_type"], "driver_comparison")
        self.assertEqual(r["parameters"]["constructor_id"], 1)
        self.assertIn("14 times", r["answer"])

    def test_head_to_head_missing_second_driver_no_query(self):
        db = FakeDB()
        r = F1Assistant(db).ask("Compare Lando Norris at McLaren")
        self.assertEqual(r["status"], "needs_clarification", r)
        self.assertEqual(db.calls, [])

    def test_head_to_head_ambiguous_surname_no_query(self):
        db = FakeDB()
        r = F1Assistant(db).ask("Compare Schumacher versus Lando Norris")
        self.assertEqual(r["status"], "needs_clarification", r)
        self.assertEqual(db.calls, [])

    def test_head_to_head_teammates_without_team_requests_clarification(self):
        db = FakeDB()
        r = F1Assistant(db).ask("Compare the teammates Lando Norris versus Daniel Ricciardo")
        self.assertEqual(r["status"], "needs_clarification", r)
        self.assertEqual(db.calls, [])

    def test_head_to_head_no_overlap_is_no_data(self):
        db = FakeDB({DRIVER_HEAD_TO_HEAD_CYPHER: []})
        r = F1Assistant(db).ask("Compare Lando Norris versus Daniel Ricciardo at McLaren")
        self.assertEqual(r["status"], "no_data", r)

    def test_head_to_head_year_filter(self):
        r = F1Assistant(FakeDB()).ask(
            "Compare Lando Norris versus Daniel Ricciardo at McLaren in 2021"
        )
        self.assertEqual(r["status"], "answered", r)
        self.assertEqual(r["parameters"]["year_from"], 2021)
        self.assertEqual(r["parameters"]["year_to"], 2021)

    def test_qualifying_result_reports_not_starting_grid(self):
        db = FakeDB()
        r = F1Assistant(db).ask(
            "What position did Lewis Hamilton qualify in at the 2021 British Grand Prix?"
        )
        self.assertEqual(r["status"], "answered", r)
        self.assertEqual(r["question_type"], "qualifying_position")
        self.assertIn("P1", r["answer"])
        self.assertIn("not necessarily", r["answer"])
        self.assertEqual(r["parameters"], {"driver_id": 1, "race_id": 1061})

    def test_qualifying_result_missing_rows_is_no_data(self):
        db = FakeDB({DRIVER_RACE_QUALIFYING_CYPHER: []})
        r = F1Assistant(db).ask(
            "What position did Lewis Hamilton qualify in at the 2021 British Grand Prix?"
        )
        self.assertEqual(r["status"], "no_data", r)

    def test_qualifying_duplicate_rows_need_review(self):
        row = {"race":"British Grand Prix", "year":2021, "driver":"Lewis Hamilton", "qualifying_position":1}
        db = FakeDB({DRIVER_RACE_QUALIFYING_CYPHER: [row, row]})
        r = F1Assistant(db).ask(
            "What position did Lewis Hamilton qualify in at the 2021 British Grand Prix?"
        )
        self.assertEqual(r["status"], "needs_review", r)

    def test_fastest_pit_stop(self):
        r = F1Assistant(FakeDB()).ask("What was the fastest pit stop at the 2023 Qatar Grand Prix?")
        self.assertEqual(r["status"], "answered", r)
        self.assertEqual(r["question_type"], "fastest_pit_stop")
        self.assertIn("1.900 seconds", r["answer"])

    def test_fastest_pit_stop_no_data(self):
        db = FakeDB({FASTEST_RACE_PIT_STOP_CYPHER: []})
        r = F1Assistant(db).ask("What was the fastest pit stop at the 2000 Monaco Grand Prix?")
        self.assertEqual(r["status"], "no_data", r)

    def test_fastest_pit_stop_invalid_duration_needs_review(self):
        row = {"race":"Qatar Grand Prix", "year":2023, "driver":"Lando Norris", "stop_number":1, "lap":5, "milliseconds":0}
        db = FakeDB({FASTEST_RACE_PIT_STOP_CYPHER: [row]})
        r = F1Assistant(db).ask("What was the fastest pit stop at the 2023 Qatar Grand Prix?")
        self.assertEqual(r["status"], "needs_review", r)

    def test_season_team_changes_versus_does_not_trigger_head_to_head(self):
        q = "Which drivers had different teams in 2020 versus 2021?"
        p = classify_intent(q)
        self.assertEqual(p.intent, Intent.SEASON_HISTORY)
        self.assertEqual(p.question_type, "season_team_changes")
        r = F1Assistant(FakeDB()).ask(q)
        self.assertEqual(r["status"], "answered", r)
        self.assertEqual(r["parameters"], {"year1": 2020, "year2": 2021})
        self.assertIn("Renault to McLaren", r["answer"])

    def test_season_team_changes_requires_two_years(self):
        db = FakeDB()
        r = F1Assistant(db).ask("Which drivers changed teams in 2021?")
        self.assertEqual(r["status"], "needs_clarification", r)
        self.assertEqual(db.calls, [])

    def test_season_team_changes_three_years_rejected(self):
        db = FakeDB()
        r = F1Assistant(db).ask("Which drivers changed teams in 2019, 2020, and 2021?")
        self.assertEqual(r["status"], "needs_clarification", r)
        self.assertEqual(db.calls, [])

    def test_season_team_changes_no_rows(self):
        db = FakeDB({SEASON_TEAM_CHANGES_CYPHER: []})
        r = F1Assistant(db).ask("Which drivers changed teams between 2020 and 2021?")
        self.assertEqual(r["status"], "no_data", r)


if __name__ == "__main__":
    unittest.main()
