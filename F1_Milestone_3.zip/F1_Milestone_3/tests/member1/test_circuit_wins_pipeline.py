
import unittest

from f1_assistant.pipeline import F1Assistant


class FakeNeo4jClient:
    """
    Fake Neo4j client for driver-circuit-wins tests.

    Simulates entity catalogs and retrieval results
    without requiring a real database connection.
    """

    def __init__(self):
        self.retrieval_calls = []

    def run_read(self, cypher, parameters=None):

        # Driver catalog
        if "MATCH (d:Driver)" in cypher:
            return [
                {
                    "driver_id": 1,
                    "first_name": "Lewis",
                    "last_name": "Hamilton",
                },
                {
                    "driver_id": 30,
                    "first_name": "Michael",
                    "last_name": "Schumacher",
                },
            ]

        # Constructor catalog
        if "MATCH (c:Constructor)" in cypher:
            return []

        # Circuit catalog
        if "MATCH (c:Circuit)" in cypher:
            return [
                {
                    "circuit_id": 6,
                    "circuit_name": "Circuit de Monaco",
                    "circuit_ref": "monaco",
                },
            ]

        # Race catalog
        if "MATCH (r:Race)" in cypher:
            return []

        # Driver circuit wins retrieval
        if (
            "driver_id" in (parameters or {})
            and "circuit_id" in parameters
        ):
            self.retrieval_calls.append({
                "cypher": cypher,
                "parameters": dict(parameters),
            })

            driver_id = parameters["driver_id"]
            circuit_id = parameters["circuit_id"]
            year = parameters["year"]

            if circuit_id != 6:
                return []

            if driver_id == 1:
                driver_name = "Lewis Hamilton"
            elif driver_id == 30:
                driver_name = "Michael Schumacher"
            else:
                return []

            # Simulated statistics based on
            # previously verified live results.
            statistics = {
                (1, 6, None): (17, 3),
                (30, 6, None): (18, 5),
                (1, 6, 2021): (1, 0),
                (1, 6, 2020): (0, 0),
            }

            race_entries, wins = statistics.get(
                (driver_id, circuit_id, year),
                (0, 0),
            )

            return [{
                "driver_id": driver_id,
                "driver": driver_name,
                "circuit_id": circuit_id,
                "circuit": "Circuit de Monaco",
                "year": year,
                "race_entries": race_entries,
                "wins": wins,
            }]

        raise AssertionError(
            "Unexpected Cypher query received."
        )


class TestCircuitWinsPipeline(unittest.TestCase):

    def setUp(self):
        self.db = FakeNeo4jClient()
        self.assistant = F1Assistant(self.db)

    def test_hamilton_all_seasons(self):
        result = self.assistant.ask(
            "How many times did Lewis Hamilton "
            "win at Monaco?"
        )

        self.assertEqual(result["status"], "answered")

        self.assertEqual(
            result["template_id"],
            "driver_circuit_wins",
        )

        self.assertEqual(
            result["parameters"],
            {
                "driver_id": 1,
                "circuit_id": 6,
                "year": None,
            },
        )

        self.assertIn(
            "3 Grand Prix wins",
            result["answer"],
        )

        self.assertEqual(len(self.db.retrieval_calls), 1)

    def test_schumacher_all_seasons(self):
        result = self.assistant.ask(
            "How many times did Michael Schumacher "
            "win at Monaco?"
        )

        self.assertEqual(result["status"], "answered")

        self.assertEqual(
            result["parameters"]["driver_id"],
            30,
        )

        self.assertIn(
            "5 Grand Prix wins",
            result["answer"],
        )

    def test_zero_wins_is_valid(self):
        result = self.assistant.ask(
            "How many times did Lewis Hamilton "
            "win at Monaco in 2021?"
        )

        self.assertEqual(result["status"], "answered")

        self.assertEqual(
            result["parameters"]["year"],
            2021,
        )

        self.assertIn(
            "0 Grand Prix wins",
            result["answer"],
        )

        self.assertEqual(
            result["evidence"][0]["race_entries"],
            1,
        )

    def test_no_race_entries(self):
        # Monaco had no 2020 Grand Prix.
        # The fake database returns zero entries.
        result = self.assistant.ask(
            "How many times did Lewis Hamilton "
            "win at Monaco in 2020?"
        )

        self.assertEqual(result["status"], "no_data")

        self.assertEqual(
            len(self.db.retrieval_calls),
            1,
        )

        self.assertNotIn("answer", result)


if __name__ == "__main__":
    unittest.main()
