"""Offline checks for exact-label neural routing; no downloads or Neo4j needed."""
import unittest
import numpy as np

from f1_assistant.nlp.question_type_embedding import (
    QUESTION_TYPE_EXAMPLES,
    LABELS,
    QuestionTypeEmbeddingClassifier,
)


class FakeEncoder:
    def __init__(self):
        self.calls = 0
        self.mapping = {
            phrase: index for index, (_, phrases) in enumerate(QUESTION_TYPE_EXAMPLES.items())
            for phrase in phrases
        }

    def embed(self, texts):
        self.calls += 1
        for t in texts:
            v = np.zeros(len(LABELS), dtype=np.float32)
            if t in self.mapping:
                v[self.mapping[t]] = 1.0
            yield v


class TestQuestionTypeEmbedding(unittest.TestCase):
    def setUp(self):
        self.fake = FakeEncoder()
        self.clf = QuestionTypeEmbeddingClassifier(encoder=self.fake)

    def test_exact_thirteen_labels(self):
        self.assertEqual(len(LABELS), 13)
        self.assertEqual(set(LABELS), {
            'circuit_location', 'constructor_season_points', 'constructor_season_wins',
            'driver_circuit_wins', 'driver_comparison', 'driver_season_podiums',
            'driver_season_wins', 'fastest_pit_stop', 'qualifying_position',
            'race_winner_or_podium', 'season_team_changes', 'podium_prediction',
            'out_of_scope',
        })

    def test_examples_embedded_only_once(self):
        self.assertEqual(self.fake.calls, 1)
        self.clf.predict(QUESTION_TYPE_EXAMPLES['driver_season_wins'][0])
        self.assertEqual(self.fake.calls, 2)

    def test_all_supported_type_examples_recognized(self):
        for label, samples in QUESTION_TYPE_EXAMPLES.items():
            if label == 'out_of_scope':
                continue
            with self.subTest(label=label):
                p = self.clf.predict(samples[0])
                self.assertEqual(p.question_type, label)
                self.assertFalse(p.abstained)

    def test_similarity_does_not_proclaim_out_of_scope(self):
        result = self.clf.predict(QUESTION_TYPE_EXAMPLES['out_of_scope'][0])
        self.assertIsNone(result.question_type)
        self.assertTrue(result.abstained)

    def test_unknown_and_blank_are_abstentions(self):
        self.assertTrue(self.clf.predict('  ').abstained)
        self.assertIsNone(self.clf.predict('unrepresented input').question_type)

    def test_bad_thresholds_rejected(self):
        with self.assertRaises(ValueError):
            QuestionTypeEmbeddingClassifier(encoder=self.fake, min_margin=-0.01)
        with self.assertRaises(ValueError):
            QuestionTypeEmbeddingClassifier(encoder=self.fake, min_similarity=1.5)

    def test_scores_cover_every_label(self):
        result = self.clf.predict(QUESTION_TYPE_EXAMPLES['circuit_location'][0])
        self.assertEqual(set(result.scores), set(LABELS))

    def test_mismatch_dimension_is_rejected(self):
        class WrongEncoder:
            def embed(self, texts):
                for t in texts:
                    yield np.zeros(4 if len(texts) == 1 else 3, dtype=np.float32)
        bad = QuestionTypeEmbeddingClassifier(encoder=WrongEncoder())
        with self.assertRaises(ValueError):
            bad.predict('test')


if __name__ == '__main__':
    unittest.main()
