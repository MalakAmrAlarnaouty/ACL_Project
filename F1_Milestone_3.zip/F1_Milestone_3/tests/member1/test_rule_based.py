
import unittest

from f1_assistant.contracts import Intent
from f1_assistant.nlp.rule_based import classify_intent


class TestRuleBasedClassifier(unittest.TestCase):

    def test_driver_podiums(self):
        result = classify_intent(
            "How many podiums did Leclerc get in 2022?"
        )
        self.assertEqual(
            result.intent,
            Intent.DRIVER_SEASON_PODIUMS
        )

    def test_driver_circuit_wins(self):
        result = classify_intent(
            "How many wins did Hamilton have at Silverstone?"
        )
        self.assertEqual(
            result.intent,
            Intent.DRIVER_CIRCUIT_WINS
        )

    def test_prediction(self):
        result = classify_intent(
            "Predict Norris at the Miami Grand Prix"
        )
        self.assertEqual(
            result.intent,
            Intent.PODIUM_PREDICTION
        )

    def test_out_of_scope(self):
        result = classify_intent(
            "What is the weather tomorrow?"
        )
        self.assertEqual(
            result.intent,
            Intent.OUT_OF_SCOPE
        )

    def test_unknown_f1_question(self):
        result = classify_intent(
           "How many safety cars were deployed in 2019?"
        )
        self.assertIsNone(result.intent)
        self.assertTrue(result.needs_clarification)

    def test_empty_question(self):
        result = classify_intent("")
        self.assertIsNone(result.intent)
        self.assertTrue(result.needs_clarification)

    def test_case_insensitivity(self):
        result = classify_intent(
            "HOW MANY PODIUMS DID LECLERC GET IN 2022?"
        )
        self.assertEqual(
            result.intent,
            Intent.DRIVER_SEASON_PODIUMS
        )


if __name__ == "__main__":
    unittest.main()
