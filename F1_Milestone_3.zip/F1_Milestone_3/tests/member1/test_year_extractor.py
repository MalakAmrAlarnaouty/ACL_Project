
import unittest

from f1_assistant.nlp.year_extractor import (
    extract_year_entities,
)


class TestYearExtractor(unittest.TestCase):

    def test_single_year(self):
        result = extract_year_entities(
            "How many podiums did Leclerc get in 2022?"
        )

        self.assertEqual(
            result.entities["years"],
            [2022],
        )
        self.assertEqual(result.missing, [])

    def test_two_years(self):
        result = extract_year_entities(
            "Which drivers changed teams between 2020 and 2021?"
        )

        self.assertEqual(
            result.entities["years"],
            [2020, 2021],
        )

    def test_year_range(self):
        result = extract_year_entities(
            "How reliable was Ferrari from 2014 to 2021?"
        )

        self.assertEqual(
            result.entities["years"],
            [2014, 2021],
        )

    def test_missing_year(self):
        result = extract_year_entities(
            "How many races did Hamilton win?"
        )

        self.assertEqual(result.entities, {})
        self.assertEqual(result.missing, ["year"])

    def test_duplicate_years(self):
        result = extract_year_entities(
            "Compare 2021 and 2022 with 2021 again"
        )

        self.assertEqual(
            result.entities["years"],
            [2021, 2022],
        )

    def test_no_partial_year_match(self):
        result = extract_year_entities(
            "The reference number is 120221"
        )

        self.assertEqual(result.entities, {})
        self.assertEqual(result.missing, ["year"])


if __name__ == "__main__":
    unittest.main()
