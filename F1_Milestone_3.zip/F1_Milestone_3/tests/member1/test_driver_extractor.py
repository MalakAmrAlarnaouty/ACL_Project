
import unittest

from f1_assistant.nlp.driver_extractor import (
    extract_driver_entities,
)


class TestDriverExtractor(unittest.TestCase):

    def setUp(self):
        # Representative records from our F1 graph.
        # Unit tests don't need a live database connection.
        self.drivers = [
            {
                "driver_id": 1,
                "first_name": "Lewis",
                "last_name": "Hamilton",
            },
            {
                "driver_id": 822,
                "first_name": "Valtteri",
                "last_name": "Bottas",
            },
            {
                "driver_id": 23,
                "first_name": "Ralf",
                "last_name": "Schumacher",
            },
            {
                "driver_id": 30,
                "first_name": "Michael",
                "last_name": "Schumacher",
            },
            {
                "driver_id": 854,
                "first_name": "Mick",
                "last_name": "Schumacher",
            },
        ]

    def test_full_name(self):
        result = extract_driver_entities(
            "How many podiums did Michael Schumacher get?",
            self.drivers,
        )

        self.assertEqual(
            result.entities["drivers"][0]["driver_id"],
            30,
        )
        self.assertEqual(result.ambiguous, {})
        self.assertEqual(result.missing, [])

    def test_ambiguous_surname(self):
        result = extract_driver_entities(
            "How many wins did Schumacher have?",
            self.drivers,
        )

        self.assertIn("schumacher", result.ambiguous)
        self.assertEqual(
            len(result.ambiguous["schumacher"]),
            3,
        )
        self.assertEqual(result.entities, {})

    def test_two_drivers(self):
        result = extract_driver_entities(
            "Compare Lewis Hamilton and Valtteri Bottas",
            self.drivers,
        )

        ids = {
            driver["driver_id"]
            for driver in result.entities["drivers"]
        }

        self.assertEqual(ids, {1, 822})

    def test_missing_driver(self):
        result = extract_driver_entities(
            "How many podiums were there in 2022?",
            self.drivers,
        )

        self.assertEqual(result.entities, {})
        self.assertEqual(result.missing, ["driver"])

    def test_case_insensitive_surname(self):
        result = extract_driver_entities(
            "HOW MANY WINS DID HAMILTON HAVE?",
            self.drivers,
        )

        self.assertEqual(
            result.entities["drivers"][0]["driver_id"],
            1,
        )


if __name__ == "__main__":
    unittest.main()
