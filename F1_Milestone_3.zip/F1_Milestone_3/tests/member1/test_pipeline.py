import unittest

from f1_assistant.pipeline import F1Assistant


class FakeNeo4jClient:
    """
    Simulated Neo4j client for pipeline unit tests.

    No real database connection is required.
    """

    def __init__(self):
        self.retrieval_calls = []
        self.conflicting_winners = False

    def run_read(self, cypher, parameters=None):

        # ------------------------------------------
        # Entity catalogs
        # ------------------------------------------

        if "MATCH (d:Driver)" in cypher:
            return [
                {
                    "driver_id": 1,
                    "first_name": "Lewis",
                    "last_name": "Hamilton",
                },
                {
                    "driver_id": 289,
                    "first_name": "Duncan",
                    "last_name": "Hamilton",
                },
                {
                    "driver_id": 30,
                    "first_name": "Michael",
                    "last_name": "Schumacher",
                },
                {
                    "driver_id": 23,
                    "first_name": "Ralf",
                    "last_name": "Schumacher",
                },
                {
                    "driver_id": 854,
                    "first_name": "Mick",
                    "last_name": "Schumacher",
                },
            ]

        if "MATCH (c:Constructor)" in cypher:
            return [
                {
                    "constructor_id": 6,
                    "constructor_name": "Ferrari",
                    "constructor_ref": "ferrari",
                }
            ]

        if "MATCH (c:Circuit)" in cypher:
            return [
                {
                    "circuit_id": 6,
                    "circuit_name": "Circuit de Monaco",
                    "circuit_ref": "monaco",
                }
            ]

        if "MATCH (r:Race)" in cypher:
            return [
                {
                    "race_id": 1020,
                    "race_name": "German Grand Prix",
                    "year": 2019,
                },
                {
                    "race_id": 1061,
                    "race_name": "British Grand Prix",
                    "year": 2021,
                },
            ]

        # ------------------------------------------
        # Constructor points retrieval
        # ------------------------------------------

        if "constructor_id" in (parameters or {}):
            self.retrieval_calls.append({
                "cypher": cypher,
                "parameters": dict(parameters),
            })

            constructor_id = parameters["constructor_id"]
            year = parameters["year"]

            if constructor_id == 6 and year == 2021:
                return [{
                    "constructor_id": 6,
                    "constructor": "Ferrari",
                    "year": 2021,
                    "race_entries": 44,
                    "points": 322.5,
                }]

            return [{
                "constructor_id": constructor_id,
                "constructor": "Ferrari",
                "year": year,
                "race_entries": 0,
                "points": 0.0,
            }]

        # ------------------------------------------
        # Driver podium retrieval
        # ------------------------------------------

        if "MATCH (s:Season" in cypher:
            self.retrieval_calls.append({
                "cypher": cypher,
                "parameters": dict(parameters),
            })

            driver_id = parameters["driver_id"]
            year = parameters["year"]

            if driver_id == 1 and year == 2021:
                return [{
                    "driver_id": 1,
                    "driver": "Lewis Hamilton",
                    "year": 2021,
                    "race_entries": 22,
                    "podiums": 17,
                }]

            return [{
                "driver_id": driver_id,
                "driver": "Lewis Hamilton",
                "year": year,
                "race_entries": 0,
                "podiums": 0,
            }]

        # ------------------------------------------
        # Race podium retrieval
        # ------------------------------------------

        if (
            "MATCH (r:Race {raceId: $race_id})" in cypher
            and "res.positionOrder IN [1, 2, 3]" in cypher
        ):
            self.retrieval_calls.append({
                "cypher": cypher,
                "parameters": dict(parameters),
            })

            race_id = parameters["race_id"]

            podiums = {
                1020: (
                    "German Grand Prix",
                    2019,
                    [
                        (830, "Max Verstappen", 1),
                        (20, "Sebastian Vettel", 2),
                        (826, "Daniil Kvyat", 3),
                    ],
                ),
                1061: (
                    "British Grand Prix",
                    2021,
                    [
                        (1, "Lewis Hamilton", 1),
                        (844, "Charles Leclerc", 2),
                        (822, "Valtteri Bottas", 3),
                    ],
                ),
            }

            if race_id not in podiums:
                return []

            race_name, year, finishers = podiums[race_id]

            return [
                {
                    "race_id": race_id,
                    "race": race_name,
                    "year": year,
                    "driver_id": driver_id,
                    "driver": driver_name,
                    "finishing_position": position,
                }
                for driver_id, driver_name, position
                in finishers
            ]

        # ------------------------------------------
        # Race winner retrieval
        # ------------------------------------------

        if "MATCH (r:Race {raceId: $race_id})" in cypher:
            self.retrieval_calls.append({
                "cypher": cypher,
                "parameters": dict(parameters or {}),
            })

            race_id = parameters["race_id"]

            if race_id == 1020:
                winner = {
                    "race_id": 1020,
                    "race": "German Grand Prix",
                    "year": 2019,
                    "driver_id": 830,
                    "winner": "Max Verstappen",
                    "finishing_position": 1,
                }

                if self.conflicting_winners:
                    return [
                        winner,
                        {
                            **winner,
                            "driver_id": 999,
                            "winner": "Another Driver",
                        },
                    ]

                return [winner]

            if race_id == 1061:
                return [{
                    "race_id": 1061,
                    "race": "British Grand Prix",
                    "year": 2021,
                    "driver_id": 1,
                    "winner": "Lewis Hamilton",
                    "finishing_position": 1,
                }]

            return []

        raise AssertionError(
            "Unexpected Cypher query received."
        )


class TestF1AssistantPipeline(unittest.TestCase):

    def setUp(self):
        self.db = FakeNeo4jClient()
        self.assistant = F1Assistant(self.db)

    # ------------------------------------------
    # Driver podium tests
    # ------------------------------------------

    def test_successful_answer(self):
        result = self.assistant.ask(
            "How many podiums did Lewis Hamilton get in 2021?"
        )

        self.assertEqual(result["status"], "answered")
        self.assertEqual(
            result["answer"],
            "Lewis Hamilton achieved 17 podium "
            "finishes in the 2021 season.",
        )
        self.assertEqual(
            result["template_id"],
            "driver_season_podiums",
        )
        self.assertEqual(len(self.db.retrieval_calls), 1)

    def test_correct_parameters(self):
        self.assistant.ask(
            "How many podiums did Lewis Hamilton get in 2021?"
        )

        self.assertEqual(
            self.db.retrieval_calls[0]["parameters"],
            {"driver_id": 1, "year": 2021},
        )

    def test_missing_year(self):
        result = self.assistant.ask(
            "How many podiums did Lewis Hamilton get?"
        )

        self.assertEqual(
            result["status"],
            "needs_clarification",
        )
        self.assertIn("years", result["missing"])
        self.assertEqual(len(self.db.retrieval_calls), 0)

    def test_ambiguous_driver(self):
        result = self.assistant.ask(
            "How many podiums did Schumacher get in 2004?"
        )

        self.assertEqual(
            result["status"],
            "needs_clarification",
        )
        self.assertIn("schumacher", result["ambiguous"])
        self.assertEqual(len(self.db.retrieval_calls), 0)

    def test_no_race_entries(self):
        # This is synthetic fake-database behavior,
        # not a claim about the real 2020 season.
        result = self.assistant.ask(
            "How many podiums did Lewis Hamilton get in 2020?"
        )

        self.assertEqual(result["status"], "no_data")

    # ------------------------------------------
    # Constructor points tests
    # ------------------------------------------

    def test_constructor_points_answer(self):
        result = self.assistant.ask(
            "How many points did Ferrari score in 2021?"
        )

        self.assertEqual(result["status"], "answered")
        self.assertEqual(
            result["answer"],
            "Ferrari scored 322.5 Grand Prix points "
            "in the 2021 season.",
        )
        self.assertEqual(
            result["template_id"],
            "constructor_season_points",
        )
        self.assertEqual(
            self.db.retrieval_calls[0]["parameters"],
            {"constructor_id": 6, "year": 2021},
        )

    def test_constructor_points_missing_year(self):
        result = self.assistant.ask(
            "How many points did Ferrari score?"
        )

        self.assertEqual(
            result["status"],
            "needs_clarification",
        )
        self.assertIn("years", result["missing"])
        self.assertEqual(len(self.db.retrieval_calls), 0)

    # ------------------------------------------
    # Race winner tests
    # ------------------------------------------

    def test_german_gp_winner(self):
        result = self.assistant.ask(
            "Who won the 2019 German Grand Prix?"
        )

        self.assertEqual(result["status"], "answered")
        self.assertEqual(
            result["answer"],
            "Max Verstappen won the 2019 German Grand Prix.",
        )
        self.assertEqual(
            result["template_id"],
            "race_winner",
        )
        self.assertEqual(
            self.db.retrieval_calls[0]["parameters"],
            {"race_id": 1020},
        )

    def test_british_gp_winner(self):
        result = self.assistant.ask(
            "Who won the 2021 British Grand Prix?"
        )

        self.assertEqual(result["status"], "answered")
        self.assertEqual(
            result["answer"],
            "Lewis Hamilton won the 2021 British Grand Prix.",
        )

        self.assertEqual(
            self.db.retrieval_calls[0]["parameters"],
            {"race_id": 1061},
        )

    def test_race_missing_year(self):
        result = self.assistant.ask(
            "Who won the British Grand Prix?"
        )

        self.assertEqual(
            result["status"],
            "needs_clarification",
        )
        self.assertEqual(len(self.db.retrieval_calls), 0)

    def test_winner_and_second_not_implemented(self):
        result = self.assistant.ask(
            "Who won the 2019 German Grand Prix "
            "and who finished second?"
        )

        self.assertEqual(
            result["status"],
            "not_implemented",
        )
        self.assertEqual(len(self.db.retrieval_calls), 0)

    def test_conflicting_winners_need_review(self):
        self.db.conflicting_winners = True

        result = self.assistant.ask(
            "Who won the 2019 German Grand Prix?"
        )

        self.assertEqual(
            result["status"],
            "needs_review",
        )
        self.assertEqual(len(result["evidence"]), 2)
        self.assertNotIn("answer", result)

    # ------------------------------------------
    # Scope and unsupported question tests
    # ------------------------------------------

    def test_missing_race_for_supported_pit_stop_route(self):
        # This query type is now implemented; the mock catalog has no
        # 2023 Qatar Grand Prix, so it must request clarification.
        result = self.assistant.ask(
            "What was the fastest pit stop "
            "at the 2023 Qatar Grand Prix?"
        )

        self.assertEqual(
            result["status"],
            "needs_clarification",
        )
        self.assertEqual(len(self.db.retrieval_calls), 0)

    def test_out_of_scope(self):
        result = self.assistant.ask(
            "What is the weather tomorrow?"
        )

        self.assertEqual(
            result["status"],
            "out_of_scope",
        )
        self.assertEqual(len(self.db.retrieval_calls), 0)

    def test_german_gp_podium(self):
        result = self.assistant.ask(
            "Who finished on the podium "
            "at the 2019 German Grand Prix?"
        )

        self.assertEqual(result["status"], "answered")

        self.assertEqual(
            result["template_id"],
            "race_podium",
        )

        self.assertEqual(
            result["parameters"],
            {"race_id": 1020},
        )

        self.assertIn("P1: Max Verstappen", result["answer"])
        self.assertIn("P2: Sebastian Vettel", result["answer"])
        self.assertIn("P3: Daniil Kvyat", result["answer"])

        self.assertEqual(len(result["evidence"]), 3)

    def test_british_gp_podium(self):
        result = self.assistant.ask(
            "Who were the podium finishers "
            "at the 2021 British Grand Prix?"
        )

        self.assertEqual(result["status"], "answered")

        self.assertEqual(
            result["template_id"],
            "race_podium",
        )

        self.assertIn("P1: Lewis Hamilton", result["answer"])
        self.assertIn("P2: Charles Leclerc", result["answer"])
        self.assertIn("P3: Valtteri Bottas", result["answer"])

    def test_top_three_finishers(self):
        result = self.assistant.ask(
            "Who were the top three finishers "
            "at the 2021 British Grand Prix?"
        )

        self.assertEqual(result["status"], "answered")

        self.assertEqual(
            result["template_id"],
            "race_podium",
        )

        self.assertEqual(
            result["parameters"],
            {"race_id": 1061},
        )

        positions = [
            row["finishing_position"]
            for row in result["evidence"]
        ]

        self.assertEqual(positions, [1, 2, 3])

    def test_race_podium_missing_year(self):
        result = self.assistant.ask(
            "Who finished on the podium "
            "at the British Grand Prix?"
        )

        self.assertEqual(
            result["status"],
            "needs_clarification",
        )

        self.assertEqual(
            len(self.db.retrieval_calls),
            0,
        )


if __name__ == "__main__":
    unittest.main()