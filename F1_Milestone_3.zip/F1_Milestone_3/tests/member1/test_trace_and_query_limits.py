"""Regression checks for UI retrieval trace and bounded Cypher."""
import unittest
from f1_assistant.pipeline import F1Assistant
from f1_assistant.retrieval.templates import (
    RACE_WINNER_CYPHER, RACE_PODIUM_CYPHER,
)
from test_pipeline import FakeNeo4jClient

class TestTraceAndQueryLimits(unittest.TestCase):
    def setUp(self):
        self.db = FakeNeo4jClient()
        self.assistant = F1Assistant(self.db)

    def check_trace(self, question, template_id):
        result = self.assistant.ask(question)
        self.assertEqual(result['status'], 'answered', result)
        self.assertEqual(result['template_id'],template_id)
        self.assertIsInstance(result['cypher'],str)
        self.assertIn('$',result['cypher'])
        self.assertIsInstance(result['parameters'],dict)
        self.assertIsInstance(result['evidence'],list)

    def test_race_winner_trace(self):
        self.check_trace('Who won the 2019 German Grand Prix?', 'race_winner')

    def test_race_podium_trace(self):
        self.check_trace('Who were the top three finishers at the 2021 British GP?', 'race_podium')

    def test_driver_season_podium_trace(self):
        self.check_trace('How many podiums did Lewis Hamilton get in 2021?', 'driver_season_podiums')

    def test_constructor_points_trace(self):
        self.check_trace('How many points did Ferrari score in 2021?', 'constructor_season_points')

    def test_race_result_templates_are_bounded(self):
        self.assertIn('LIMIT 10',RACE_WINNER_CYPHER)
        self.assertIn('LIMIT 20',RACE_PODIUM_CYPHER)

if __name__=='__main__':
    unittest.main()
