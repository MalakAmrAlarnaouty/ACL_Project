"""Regression tests for driver surnames shared with F1 constructors."""
import unittest
from f1_assistant.nlp.unified_extractor import extract_all_entities
from f1_assistant.nlp.entity_validator import validate_entities, ready_for_query
from f1_assistant.nlp.rule_based import classify_intent


DRIVERS = [
    {"driver_id": 360, "first_name": "Bruce", "last_name": "McLaren"},
    {"driver_id": 817, "first_name": "Daniel", "last_name": "Ricciardo"},
    {"driver_id": 846, "first_name": "Lando", "last_name": "Norris"},
    {"driver_id": 1, "first_name": "Lewis", "last_name": "Hamilton"},
    {"driver_id": 23, "first_name": "Ralf", "last_name": "Schumacher"},
    {"driver_id": 30, "first_name": "Michael", "last_name": "Schumacher"},
    {"driver_id": 886, "first_name": "Jonathan", "last_name": "Williams"},
    {"driver_id": 36, "first_name": "Jackie", "last_name": "Stewart"},
    {"driver_id": 37, "first_name": "Jimmy", "last_name": "Stewart"},
]
CONSTRUCTORS = [
    {"constructor_id": 1, "constructor_name": "McLaren", "constructor_ref": "mclaren"},
    {"constructor_id": 3, "constructor_name": "Williams", "constructor_ref": "williams"},
    {"constructor_id": 4, "constructor_name": "Stewart", "constructor_ref": "stewart"},
]


def extract(question):
    return extract_all_entities(question, DRIVERS, CONSTRUCTORS, [], [])


class NameRoleCollisionTests(unittest.TestCase):
    def test_two_named_drivers_at_mclaren_excludes_bruce_mclaren(self):
        question = "Who finished ahead more often, Lando Norris versus Daniel Ricciardo at McLaren?"
        entities = extract(question)
        self.assertEqual(
            [d["driver_id"] for d in entities.entities["drivers"]],
            [846, 817],
        )
        self.assertEqual(entities.entities["constructors"][0]["constructor_id"], 1)
        valid = validate_entities(classify_intent(question), entities)
        self.assertTrue(ready_for_query(valid), valid)

    def test_bruce_mclaren_full_name_remains_a_driver(self):
        entities = extract("Compare Bruce McLaren versus Daniel Ricciardo at McLaren")
        self.assertEqual(
            [d["driver_id"] for d in entities.entities["drivers"]],
            [360, 817],
        )

    def test_bare_mclaren_does_not_guess_its_role(self):
        entities = extract("Compare McLaren versus Daniel Ricciardo")
        self.assertEqual(
            {d["driver_id"] for d in entities.entities["drivers"]},
            {360, 817},
        )
        # This extraction still reports both possible types. A higher-level
        # intent-aware clarification policy is needed for role ambiguity.
        self.assertEqual(entities.entities["constructors"][0]["constructor_id"], 1)

    def test_full_name_kept_even_when_team_role_also_present(self):
        entities = extract("Bruce McLaren versus Lando Norris at McLaren")
        self.assertEqual(
            [d["driver_id"] for d in entities.entities["drivers"]],
            [360, 846],
        )

    def test_team_only_question_no_false_driver(self):
        entities = extract("How many races did the team McLaren win in 2021?")
        self.assertNotIn("drivers", entities.entities)
        self.assertEqual(entities.entities["years"], [2021])

    def test_williams_team_is_not_jonathan_williams(self):
        entities = extract("Compare Lewis Hamilton and Daniel Ricciardo at Williams")
        self.assertEqual(
            [d["driver_id"] for d in entities.entities["drivers"]],
            [1, 817],
        )

    def test_ambiguous_schumacher_still_asks_for_clarification(self):
        question = "Compare Schumacher versus Lando Norris at McLaren"
        entities = extract(question)
        self.assertIn("schumacher", entities.ambiguous)
        valid = validate_entities(classify_intent(question), entities)
        self.assertFalse(ready_for_query(valid))

    def test_constructor_context_clears_ambiguous_historical_surname(self):
        entities = extract("Compare Lewis Hamilton versus Daniel Ricciardo at Stewart")
        self.assertEqual(
            [d["driver_id"] for d in entities.entities["drivers"]],
            [1, 817],
        )
        self.assertNotIn("stewart", entities.ambiguous)

    def test_unqualified_stewart_surname_remains_ambiguous(self):
        entities = extract("Compare Stewart versus Lando Norris")
        self.assertIn("stewart", entities.ambiguous)

    def test_end_to_end_mock_head_to_head_with_constructor_collision(self):
        from f1_assistant.pipeline import F1Assistant

        class MockDB:
            def __init__(self):
                self.last_parameters = None

            def run_read(self, cypher, parameters=None):
                if "MATCH (d:Driver)" in cypher and not parameters:
                    return DRIVERS
                if "MATCH (c:Constructor)" in cypher and not parameters:
                    return CONSTRUCTORS
                if "MATCH (c:Circuit)" in cypher and not parameters:
                    return []
                if "MATCH (r:Race)" in cypher and not parameters:
                    return []
                self.last_parameters = parameters
                return [{
                    "driver1": "Lando Norris", "driver2": "Daniel Ricciardo",
                    "shared_races": 20, "driver1_ahead": 14,
                    "driver2_ahead": 6, "ties": 0,
                }]

        db = MockDB()
        result = F1Assistant(db).ask(
            "Who finished ahead more often, Lando Norris versus Daniel Ricciardo at McLaren?"
        )
        self.assertEqual(result["status"], "answered", result)
        self.assertEqual(result["question_type"], "driver_comparison")
        self.assertEqual(db.last_parameters["driver1_id"], 846)
        self.assertEqual(db.last_parameters["driver2_id"], 817)
        self.assertEqual(db.last_parameters["constructor_id"], 1)

    def test_mention_order_independent_of_graph_id(self):
        entities = extract("Compare Lando Norris with Daniel Ricciardo")
        self.assertEqual(
            [d["driver_id"] for d in entities.entities["drivers"]],
            [846, 817],
        )


if __name__ == "__main__":
    unittest.main()
