
import unittest

from f1_assistant.nlp.constructor_extractor import (
    extract_constructor_entities,
)


class TestConstructorExtractor(unittest.TestCase):

    def setUp(self):
        # Representative constructor records.
        # No live Neo4j connection is required.

        self.constructors = [
            {
                "constructor_id": 6,
                "constructor_name": "Ferrari",
                "constructor_ref": "ferrari",
            },
            {
                "constructor_id": 131,
                "constructor_name": "Mercedes",
                "constructor_ref": "mercedes",
            },
            {
                "constructor_id": 9,
                "constructor_name": "Red Bull",
                "constructor_ref": "red_bull",
            },
            {
                "constructor_id": 1,
                "constructor_name": "McLaren",
                "constructor_ref": "mclaren",
            },
            {
                "constructor_id": 2,
                "constructor_name": "BMW Sauber",
                "constructor_ref": "bmw_sauber",
            },
            {
                "constructor_id": 15,
                "constructor_name": "Sauber",
                "constructor_ref": "sauber",
            },
        ]

    def test_canonical_name(self):
        result = extract_constructor_entities(
            "How many points did Ferrari earn in 2021?",
            self.constructors,
        )

        self.assertEqual(
            result.entities["constructors"][0]["constructor_id"],
            6,
        )
        self.assertEqual(result.ambiguous, {})
        self.assertEqual(result.missing, [])

    def test_mercedes_alias(self):
        result = extract_constructor_entities(
            "How many races did Mercedes AMG win?",
            self.constructors,
        )

        self.assertEqual(
            result.entities["constructors"][0]["constructor_id"],
            131,
        )

    def test_compact_name(self):
        result = extract_constructor_entities(
            "How reliable was redbull in 2021?",
            self.constructors,
        )

        self.assertEqual(
            result.entities["constructors"][0]["constructor_id"],
            9,
        )

    def test_overlapping_names(self):
        result = extract_constructor_entities(
            "How many points did BMW Sauber earn?",
            self.constructors,
        )

        ids = [
            item["constructor_id"]
            for item in result.entities["constructors"]
        ]

        self.assertEqual(ids, [2])

    def test_multiple_constructors(self):
        result = extract_constructor_entities(
            "Compare McLaren and BMW Sauber",
            self.constructors,
        )

        ids = [
            item["constructor_id"]
            for item in result.entities["constructors"]
        ]

        self.assertEqual(ids, [1, 2])

    def test_missing_constructor(self):
        result = extract_constructor_entities(
            "How many podiums were achieved in 2022?",
            self.constructors,
        )

        self.assertEqual(result.entities, {})
        self.assertEqual(result.missing, ["constructor"])

    def test_ambiguous_alias(self):
        # Synthetic records to test ambiguous aliases.
        constructors = [
            {
                "constructor_id": 201,
                "constructor_name": "Alpha Works",
                "constructor_ref": "common_ref",
            },
            {
                "constructor_id": 202,
                "constructor_name": "Beta Works",
                "constructor_ref": "common_ref",
            },
        ]

        result = extract_constructor_entities(
            "Compare commonref constructors",
            constructors,
        )

        self.assertEqual(result.entities, {})
        self.assertIn("commonref", result.ambiguous)

        self.assertEqual(
            set(result.ambiguous["commonref"]),
            {"Alpha Works", "Beta Works"},
        )


if __name__ == "__main__":
    unittest.main()
