# Current Member 1 routes and classification labels

The following 11 question types are included in `F1Assistant.SUPPORTED_QUESTION_TYPES` and were checked live (11/11) in the user's environment:

1. `circuit_location`
2. `constructor_season_points`
3. `constructor_season_wins`
4. `driver_circuit_wins`
5. `driver_comparison`
6. `driver_season_podiums`
7. `driver_season_wins`
8. `fastest_pit_stop`
9. `qualifying_position`
10. `race_winner_or_podium`
11. `season_team_changes`

The two additional classification labels in the **13-label question-type comparison** are `podium_prediction` and `out_of_scope`. `UNKNOWN` is a safe abstention, **not** a gold category. The project also contains a distinct *broad-intent* 10-category classifier prototype for separate experimentation.

For in-domain retrieval, the assistant resolves drivers, constructors, circuits, races and years; the validator requires missing or ambiguous slots to be clarified. Relevant response keys include `status`, `intent`, `question_type`, `answer`, `template_id`, `cypher`, `parameters`, and `evidence` for answered routes. Check each response status: clarification and out-of-scope responses do not have the same keys.

**Do not assume the 13-label neural classifier is the active runtime router.** The production pipeline currently uses the rule-based classifier first and an optional neural suggestion for clarification. The team integration owner should explicitly choose the deployed behavior, and never execute arbitrary model-generated Cypher.

Legacy draft `docs/intent_catalog.md` was omitted from this clean copy because it describes an older proposed 10-intent plan, not this actual implemented 13-label comparison.
