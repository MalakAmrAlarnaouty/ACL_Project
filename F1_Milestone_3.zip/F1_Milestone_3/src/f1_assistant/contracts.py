
from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any


class Intent(StrEnum):
    """
    Ten supported high-level intent categories.
    """

    # Eight knowledge graph question families.
    DRIVER_PERFORMANCE = "DRIVER_PERFORMANCE"
    CONSTRUCTOR_PERFORMANCE = "CONSTRUCTOR_PERFORMANCE"
    HEAD_TO_HEAD = "HEAD_TO_HEAD"
    RACE_RESULTS = "RACE_RESULTS"
    CIRCUIT_FACTS = "CIRCUIT_FACTS"
    QUALIFYING_GRID = "QUALIFYING_GRID"
    PIT_STOP_STRATEGY = "PIT_STOP_STRATEGY"
    SEASON_HISTORY = "SEASON_HISTORY"

    # Separate prediction and out-of-scope intents.
    PODIUM_PREDICTION = "PODIUM_PREDICTION"
    OUT_OF_SCOPE = "OUT_OF_SCOPE"

    # Temporary backward-compatible aliases.
    # These do not introduce additional unique intents.
    DRIVER_SEASON_PODIUMS = "DRIVER_PERFORMANCE"
    DRIVER_CIRCUIT_WINS = "DRIVER_PERFORMANCE"
    CONSTRUCTOR_SEASON_POINTS = "CONSTRUCTOR_PERFORMANCE"
    RACE_PODIUM = "RACE_RESULTS"
    QUALIFYING_POLES = "QUALIFYING_GRID"
    FASTEST_PIT_STOP = "PIT_STOP_STRATEGY"
    SEASON_TEAM_CHANGES = "SEASON_HISTORY"


@dataclass
class IntentPrediction:
    intent: Intent | None
    method: str
    confidence: float | None = None
    needs_clarification: bool = False
    reason: str | None = None

    # A specific question type within the broad intent.
    question_type: str | None = None


@dataclass
class EntityExtraction:
    entities: dict[str, Any] = field(default_factory=dict)
    missing: list[str] = field(default_factory=list)
    ambiguous: dict[str, list[str]] = field(default_factory=dict)


@dataclass
class RetrievalResult:
    intent: Intent
    template_id: str
    cypher: str
    parameters: dict[str, Any]
    rows: list[dict[str, Any]]
