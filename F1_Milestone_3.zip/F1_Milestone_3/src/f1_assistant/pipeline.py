
import re

from f1_assistant.contracts import Intent

from f1_assistant.nlp.rule_based import classify_intent
from f1_assistant.nlp.unified_extractor import extract_all_entities
from f1_assistant.nlp.entity_validator import (
    validate_entities,
    ready_for_query,
)
from f1_assistant.nlp.entity_catalog import (
    load_drivers,
    load_constructors,
    load_circuits,
    load_races,
)


from f1_assistant.retrieval.templates import (
    retrieve_driver_season_podiums,
    retrieve_constructor_season_points,
    retrieve_race_winner,
    retrieve_race_podium,
    retrieve_driver_circuit_wins,
    retrieve_driver_season_wins,
    retrieve_constructor_season_wins,
    retrieve_circuit_location,
    retrieve_driver_head_to_head,
    retrieve_driver_race_qualifying,
    retrieve_fastest_race_pit_stop,
    retrieve_season_team_changes,
)



class F1Assistant:
    """
    End-to-end F1 question-answering pipeline.

    Supported routes:
    - Driver season podiums
    - Constructor season points
    - Race winners
    - Race podium finishers
    - Driver season wins and circuit wins
    - Constructor season wins
    - Circuit location

    Answers are generated from Neo4j evidence.
    """

    
    SUPPORTED_QUESTION_TYPES = {
        "driver_season_podiums",
        "constructor_season_points",
        "race_winner_or_podium",
        "driver_circuit_wins",
        "driver_season_wins",
        "constructor_season_wins",
        "circuit_location",
        "driver_comparison",
        "qualifying_position",
        "fastest_pit_stop",
        "season_team_changes",
    }


    def __init__(self, db, neural_classifier=None):
        # The neural classifier is optional, keeping existing integrations intact.
        # It only suggests broad intents; it cannot select a Cypher template.
        self.db = db
        self.neural_classifier = neural_classifier

        self.drivers = load_drivers(db)
        self.constructors = load_constructors(db)
        self.circuits = load_circuits(db)
        self.races = load_races(db)

    @staticmethod
    def _evidence_answer(prediction, retrieval, answer: str) -> dict:
        return {
            "status": "answered",
            "intent": prediction.intent.value,
            "question_type": prediction.question_type,
            "answer": answer,
            "template_id": retrieval.template_id,
            "cypher": retrieval.cypher,
            "parameters": retrieval.parameters,
            "evidence": retrieval.rows,
        }

    def ask(self, question: str) -> dict:

        # ------------------------------------------
        # 1. Intent classification
        # ------------------------------------------

        prediction = classify_intent(question)

        if prediction.intent is None:
            # Do not route uncertain questions to Neo4j. A neural model
            # can suggest a broad intent, but it cannot choose a query type.
            if self.neural_classifier is not None:
                try:
                    neural = self.neural_classifier.predict(question)
                except Exception:
                    # Keep the core assistant usable if the optional model
                    # is missing, offline, or fails to initialize/infer.
                    neural = None

                if neural is not None and neural.intent not in (
                    None,
                    Intent.OUT_OF_SCOPE,
                ):
                    return {
                        "status": "needs_clarification",
                        "suggested_intent": neural.intent.value,
                        "message": (
                            "I think this may concern "
                            + neural.intent.value.replace("_", " ").lower()
                            + ". Please provide the specific question "
                            "and relevant names or dates."
                        ),
                    }

            return {
                "status": "needs_clarification",
                "message": (
                    prediction.reason
                    or "I could not identify the question."
                ),
            }

        if prediction.intent == Intent.OUT_OF_SCOPE:
            return {
                "status": "out_of_scope",
                "message": (
                    "This question is outside the "
                    "supported Formula 1 assistant."
                ),
            }

        if prediction.question_type not in self.SUPPORTED_QUESTION_TYPES:
            return {
                "status": "not_implemented",
                "intent": prediction.intent.value,
                "question_type": prediction.question_type,
                "message": (
                    "This question type is recognized, "
                    "but its Neo4j retrieval template "
                    "has not been implemented yet."
                ),
            }

        # ------------------------------------------
        # 2. Entity extraction
        # ------------------------------------------

        extraction = extract_all_entities(
            question,
            self.drivers,
            self.constructors,
            self.circuits,
            self.races,
        )

        # ------------------------------------------
        # 3. Entity validation
        # ------------------------------------------

        validation = validate_entities(
            prediction,
            extraction,
        )

        if not ready_for_query(validation):

            if validation.ambiguous:
                return {
                    "status": "needs_clarification",
                    "message": (
                        "Please clarify the ambiguous "
                        "entity or entities."
                    ),
                    "ambiguous": validation.ambiguous,
                    "missing": validation.missing,
                }

            return {
                "status": "needs_clarification",
                "message": (
                    "The question is missing required "
                    "information."
                ),
                "missing": validation.missing,
            }

        # ------------------------------------------
        # 4. Multi-hop head-to-head, qualifying,
        # pit stop and season-history templates.
        # ------------------------------------------

        if prediction.question_type == "driver_comparison":
            drivers = validation.entities["drivers"]
            if drivers[0]["driver_id"] == drivers[1]["driver_id"]:
                return {
                    "status": "needs_clarification",
                    "message": "Please name two different drivers.",
                }
            constructors = validation.entities.get("constructors", [])
            years = validation.entities.get("years", [])
            if len(constructors) > 1 or len(years) > 2:
                return {
                    "status": "needs_clarification",
                    "message": "Specify at most one team and a period of at most two years.",
                }
            if re.search(r"\bteammates?\b", question, flags=re.IGNORECASE) and not constructors:
                return {
                    "status": "needs_clarification",
                    "message": "Please specify the constructor for a teammate comparison.",
                }
            constructor_id = (
                constructors[0]["constructor_id"] if constructors else None
            )
            year_from = min(years) if years else None
            year_to = max(years) if years else None
            retrieval = retrieve_driver_head_to_head(
                self.db,
                drivers[0]["driver_id"],
                drivers[1]["driver_id"],
                constructor_id=constructor_id,
                year_from=year_from,
                year_to=year_to,
            )
            if not retrieval.rows:
                return {
                    "status": "no_data",
                    "message": "No comparable Grand Prix race results were found for both drivers in the specified scope.",
                }
            if len(retrieval.rows) != 1:
                return {
                    "status": "needs_review",
                    "message": "Unexpected number of head-to-head summary rows.",
                    "evidence": retrieval.rows,
                }
            row = retrieval.rows[0]
            shared = row["shared_races"]
            if shared == 0:
                return {
                    "status": "no_data",
                    "message": "The drivers have no shared races with comparable results in this scope.",
                }
            scope = (
                f" while both represented {constructors[0]['name']}"
                if constructors else ""
            )
            period = (
                f" from {year_from} to {year_to}"
                if year_from is not None and year_from != year_to
                else (f" in {year_from}" if year_from is not None else "")
            )
            answer = (
                f"In {shared} shared Grands Prix{period}{scope}, "
                f"{row['driver1']} was classified ahead "
                f"{row['driver1_ahead']} times and "
                f"{row['driver2']} {row['driver2_ahead']} times "
                f"({row['ties']} ties), using the recorded finishing order."
            )
            return self._evidence_answer(prediction, retrieval, answer)

        if prediction.question_type == "qualifying_position":
            # We report Qualifying.position, not the potentially
            # different starting grid (e.g. penalties or sprint weekends).
            driver = validation.entities["drivers"][0]
            race = validation.entities["races"][0]
            retrieval = retrieve_driver_race_qualifying(
                self.db, driver["driver_id"], race["race_id"],
            )
            if not retrieval.rows:
                return {
                    "status": "no_data",
                    "message": "The graph has no qualifying result for that driver and race.",
                }
            if len(retrieval.rows) != 1:
                return {
                    "status": "needs_review",
                    "message": "More than one qualifying result was returned for this driver and race.",
                    "evidence": retrieval.rows,
                }
            row = retrieval.rows[0]
            if row.get("qualifying_position") is None:
                return {
                    "status": "no_data",
                    "message": "The qualifying position is not recorded in the graph.",
                }
            answer = (
                f"{row['driver']} was classified P{row['qualifying_position']} "
                f"in qualifying for the {row['year']} {row['race']} "
                "(Qualifying.position, not necessarily the race starting grid)."
            )
            return self._evidence_answer(prediction, retrieval, answer)

        if prediction.question_type == "fastest_pit_stop":
            race = validation.entities["races"][0]
            retrieval = retrieve_fastest_race_pit_stop(self.db, race["race_id"])
            if not retrieval.rows:
                return {
                    "status": "no_data",
                    "message": "The graph has no timed pit-stop records for that Grand Prix.",
                }
            # The query returns all tied fastest stops, bounded to 10.
            fastest = retrieval.rows[0]["milliseconds"]
            if fastest is None or fastest <= 0:
                return {
                    "status": "needs_review",
                    "message": "The fastest recorded pit-stop duration is invalid.",
                    "evidence": retrieval.rows,
                }
            if any(row["milliseconds"] != fastest for row in retrieval.rows):
                return {
                    "status": "needs_review",
                    "message": "The pit-stop rows disagree on the minimum duration.",
                    "evidence": retrieval.rows,
                }
            drivers = ", ".join(
                f"{row['driver']} (stop {row['stop_number']})"
                for row in retrieval.rows
            )
            first = retrieval.rows[0]
            answer = (
                f"The shortest recorded pit-lane elapsed time at the {first['year']} "
                f"{first['race']} was {fastest / 1000:.3f} seconds: "
                f"{drivers}. This is the pit-lane duration stored in the graph, "
                "not the stationary tyre-change time."
            )
            return self._evidence_answer(prediction, retrieval, answer)

        if prediction.question_type == "season_team_changes":
            years = validation.entities["years"]
            if years[0] == years[1]:
                return {
                    "status": "needs_clarification",
                    "message": "Specify two different seasons for comparison.",
                }
            retrieval = retrieve_season_team_changes(
                self.db, years[0], years[1],
            )
            if not retrieval.rows:
                return {
                    "status": "no_data",
                    "message": (
                        f"The graph contains no drivers with differing recorded "
                        f"constructor participation in {years[0]} versus {years[1]}."
                    ),
                }
            parts = [
                f"{row['driver']}: "
                f"{'/'.join(row['earlier_teams'])} to {'/'.join(row['later_teams'])}"
                for row in retrieval.rows
            ]
            answer = (
                f"The graph records these drivers with different constructor "
                f"participation in {years[0]} versus {years[1]}: "
                + "; ".join(parts)
                + ". This compares constructors appearing in Grand Prix results, "
                  "not necessarily permanent transfers; one-off substitute drives "
                  "and constructor rebranding can also appear."
            )
            return self._evidence_answer(prediction, retrieval, answer)

        # ------------------------------------------
        # 4. Additional factual retrieval routes.
        # All Cypher comes from static, parameterized templates.
        # ------------------------------------------

        if prediction.question_type in (
            "driver_season_wins",
            "constructor_season_wins",
        ):
            years = validation.entities["years"]
            year = years[0]
            if prediction.question_type == "driver_season_wins":
                driver = validation.entities["drivers"][0]
                retrieval = retrieve_driver_season_wins(
                    self.db, driver["driver_id"], year,
                )
                entity_key = "driver"
                kind = "driver"
            else:
                constructor = validation.entities["constructors"][0]
                retrieval = retrieve_constructor_season_wins(
                    self.db, constructor["constructor_id"], year,
                )
                entity_key = "constructor"
                kind = "constructor"

            if not retrieval.rows:
                return {
                    "status": "no_data",
                    "message": "No matching driver, constructor, or season was found.",
                }
            if len(retrieval.rows) != 1:
                return {
                    "status": "needs_review",
                    "message": "An unexpected number of summary rows was returned.",
                    "evidence": retrieval.rows,
                }
            row = retrieval.rows[0]
            if row["race_entries"] == 0:
                return {
                    "status": "no_data",
                    "message": f"No Grand Prix entries were found for this {kind} in {year}.",
                }
            answer = (
                f"{row[entity_key]} won {row['wins']} Grands Prix "
                f"in the {row['year']} season (Grand Prix results only; "
                "sprint events excluded)."
            )
            return {
                "status": "answered",
                "intent": prediction.intent.value,
                "question_type": prediction.question_type,
                "answer": answer,
                "template_id": retrieval.template_id,
                "cypher": retrieval.cypher,
                "parameters": retrieval.parameters,
                "evidence": retrieval.rows,
            }

        if prediction.question_type == "circuit_location":
            circuit = validation.entities["circuits"][0]
            retrieval = retrieve_circuit_location(
                self.db, circuit["circuit_id"],
            )
            if not retrieval.rows:
                return {
                    "status": "no_data",
                    "message": "No circuit location record was found.",
                }
            if len(retrieval.rows) != 1:
                return {
                    "status": "needs_review",
                    "message": "Multiple circuit records were returned.",
                    "evidence": retrieval.rows,
                }
            row = retrieval.rows[0]
            city = row.get("city")
            country = row.get("country")
            if not city and not country:
                return {
                    "status": "no_data",
                    "message": "The circuit has no recorded location in the graph.",
                }
            detail = ", ".join(part for part in (city, country) if part)
            answer = f"{row['circuit']} is located in {detail}."
            return {
                "status": "answered",
                "intent": prediction.intent.value,
                "question_type": prediction.question_type,
                "answer": answer,
                "template_id": retrieval.template_id,
                "cypher": retrieval.cypher,
                "parameters": retrieval.parameters,
                "evidence": retrieval.rows,
            }

        # ------------------------------------------
        # 4. Race results
        # ------------------------------------------

        if prediction.question_type == "race_winner_or_podium":

            text = question.casefold()

            winner_requested = bool(
                re.search(
                    r"\b(?:who\s+won|"
                    r"who\s+(?:took|claimed|secured)\s+(?:the\s+)?victory|"
                    r"which\s+driver\s+won|"
                    r"winner|"
                    r"who\s+finished\s+(?:in\s+)?first)\b",
                    text,
                )
            )

            podium_requested = bool(
                re.search(
                    r"\b(?:podiums?|"
                    r"top\s*(?:3|three)|"
                    r"second|third|"
                    r"p2|p3|"
                    r"runner[\s-]?up)\b",
                    text,
                )
            )

            # Prevent silently answering only part of
            # a multi-part question.
            if winner_requested and podium_requested:
                return {
                    "status": "not_implemented",
                    "question_type": prediction.question_type,
                    "message": (
                        "Combined winner and additional "
                        "finishing-position requests are "
                        "not supported yet."
                    ),
                }

            if not winner_requested and not podium_requested:
                return {
                    "status": "not_implemented",
                    "question_type": prediction.question_type,
                    "message": (
                        "This race-results request is "
                        "not supported yet."
                    ),
                }

            race = validation.entities["races"][0]
            race_id = race["race_id"]

            # --------------------------------------
            # 4A. Race winner
            # --------------------------------------

            if winner_requested:

                retrieval = retrieve_race_winner(
                    db=self.db,
                    race_id=race_id,
                )

                if not retrieval.rows:
                    return {
                        "status": "no_data",
                        "message": (
                            "No winner record was found "
                            "for this race."
                        ),
                    }

                if len(retrieval.rows) != 1:
                    return {
                        "status": "needs_review",
                        "message": (
                            "Multiple winner records "
                            "were returned. Verification "
                            "is required."
                        ),
                        "evidence": retrieval.rows,
                    }

                row = retrieval.rows[0]

                answer = (
                    f"{row['winner']} won the "
                    f"{row['year']} {row['race']}."
                )

            # --------------------------------------
            # 4B. Full race podium
            # --------------------------------------

            else:

                retrieval = retrieve_race_podium(
                    db=self.db,
                    race_id=race_id,
                )

                if not retrieval.rows:
                    return {
                        "status": "no_data",
                        "message": (
                            "No podium records were found "
                            "for this race."
                        ),
                    }

                rows = retrieval.rows

                podium_parts = [
                    f"P{row['finishing_position']}: "
                    f"{row['driver']}"
                    for row in rows
                ]

                podium_text = "; ".join(podium_parts)

                answer = (
                    f"The podium at the "
                    f"{rows[0]['year']} "
                    f"{rows[0]['race']} was: "
                    f"{podium_text}."
                )

            return {
                "status": "answered",
                "intent": prediction.intent.value,
                "question_type": prediction.question_type,
                "answer": answer,
                "template_id": retrieval.template_id,
                "cypher": retrieval.cypher,
                "parameters": retrieval.parameters,
                "evidence": retrieval.rows,
            }

        # ------------------------------------------
        # 4C. Driver wins at a circuit
        # ------------------------------------------

        if prediction.question_type == "driver_circuit_wins":

            # These entities have already passed
            # intent-aware validation.
            driver = validation.entities["drivers"][0]
            circuit = validation.entities["circuits"][0]

            # A year is optional for this question type.
            years = validation.entities.get("years", [])

            # Do not silently ignore multiple seasons.
            if len(years) > 1:
                return {
                    "status": "needs_clarification",
                    "message": (
                        "Please specify one season, "
                        "or ask for wins across all seasons."
                    ),
                    "ambiguous": {
                        "years": years,
                    },
                }

            year = years[0] if years else None

            # Execute the predefined Cypher template.
            retrieval = retrieve_driver_circuit_wins(
                db=self.db,
                driver_id=driver["driver_id"],
                circuit_id=circuit["circuit_id"],
                year=year,
            )

            if not retrieval.rows:
                return {
                    "status": "no_data",
                    "message": (
                        "The requested driver or circuit "
                        "was not found in the Knowledge Graph."
                    ),
                }

            row = retrieval.rows[0]

            if row["race_entries"] == 0:
                return {
                    "status": "no_data",
                    "message": (
                        f"No race entries were recorded "
                        f"for {row['driver']} at "
                        f"{row['circuit']}"
                        + (
                            f" in {year}."
                            if year is not None
                            else " in the available dataset."
                        )
                    ),
                }

            # Format the time period accurately.
            if year is None:
                period = "across all available seasons"
            else:
                period = f"in {year}"

            # Zero wins is a valid answer when a
            # driver participated but did not win.
            answer = (
                f"{row['driver']} recorded "
                f"{row['wins']} Grand Prix wins at "
                f"{row['circuit']} {period}."
            )

            return {
                "status": "answered",
                "intent": prediction.intent.value,
                "question_type": prediction.question_type,
                "answer": answer,
                "template_id": retrieval.template_id,
                "cypher": retrieval.cypher,
                "parameters": retrieval.parameters,
                "evidence": retrieval.rows,
            }


        # ------------------------------------------
        # 5. Driver season podiums
        # ------------------------------------------

        if prediction.question_type == "driver_season_podiums":

            driver = validation.entities["drivers"][0]
            year = validation.entities["years"][0]

            retrieval = retrieve_driver_season_podiums(
                db=self.db,
                driver_id=driver["driver_id"],
                year=year,
            )

        # ------------------------------------------
        # 6. Constructor season points
        # ------------------------------------------

        elif prediction.question_type == "constructor_season_points":

            constructor = validation.entities["constructors"][0]
            year = validation.entities["years"][0]

            retrieval = retrieve_constructor_season_points(
                db=self.db,
                constructor_id=constructor["constructor_id"],
                year=year,
            )

        else:
            return {
                "status": "not_implemented",
                "message": (
                    "No retrieval template is available."
                ),
            }

        # ------------------------------------------
        # 7. Validate retrieval results
        # ------------------------------------------

        if not retrieval.rows:
            return {
                "status": "no_data",
                "message": (
                    "No matching records were found "
                    "in the Knowledge Graph."
                ),
            }

        row = retrieval.rows[0]

        if row["race_entries"] == 0:
            return {
                "status": "no_data",
                "message": (
                    "No race entries were recorded "
                    f"for the requested entity in {year}."
                ),
            }

        # ------------------------------------------
        # 8. Generate grounded answers
        # ------------------------------------------

        if prediction.question_type == "driver_season_podiums":

            answer = (
                f"{row['driver']} achieved "
                f"{row['podiums']} podium finishes "
                f"in the {row['year']} season."
            )

        elif prediction.question_type == "constructor_season_points":

            answer = (
                f"{row['constructor']} scored "
                f"{row['points']} Grand Prix points "
                f"in the {row['year']} season."
            )

        return {
            "status": "answered",
            "intent": prediction.intent.value,
            "question_type": prediction.question_type,
            "answer": answer,
            "template_id": retrieval.template_id,
            "cypher": retrieval.cypher,
            "parameters": retrieval.parameters,
            "evidence": retrieval.rows,
        }
