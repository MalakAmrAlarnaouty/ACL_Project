
from f1_assistant.contracts import Intent, RetrievalResult
from f1_assistant.retrieval.neo4j_client import Neo4jClient


# Fixed, read-only Cypher template.
# Driver IDs and years are passed as parameters.
# User text is never inserted into the query.

DRIVER_SEASON_PODIUMS_CYPHER = """
MATCH (s:Season {year: $year})
MATCH (d:Driver {driverId: $driver_id})

OPTIONAL MATCH
    (d)<-[:BY_DRIVER]-(res:Result)-[:FOR_RACE]->(r:Race)
WHERE r.year = s.year

RETURN
    d.driverId AS driver_id,
    d.forename + ' ' + d.surname AS driver,
    s.year AS year,
    count(DISTINCT r.raceId) AS race_entries,
    count(
        DISTINCT CASE
            WHEN res.positionOrder IN [1, 2, 3]
            THEN r.raceId
            ELSE NULL
        END
    ) AS podiums
"""


def retrieve_driver_season_podiums(
    db: Neo4jClient,
    driver_id: int,
    year: int,
) -> RetrievalResult:
    """
    Count a driver's podium finishes in one season.

    A podium means finishing position 1, 2, or 3.
    Shared-drive duplicates do not count twice.
    """

    parameters = {
        "driver_id": driver_id,
        "year": year,
    }

    rows = db.run_read(
        DRIVER_SEASON_PODIUMS_CYPHER,
        parameters,
    )

    return RetrievalResult(
        intent=Intent.DRIVER_PERFORMANCE,
        template_id="driver_season_podiums",
        cypher=DRIVER_SEASON_PODIUMS_CYPHER,
        parameters=parameters,
        rows=rows,
    )

# --------------------------------------------------
# Constructor season points
# --------------------------------------------------

CONSTRUCTOR_SEASON_POINTS_CYPHER = """
MATCH (s:Season {year: $year})
MATCH (c:Constructor {constructorId: $constructor_id})

OPTIONAL MATCH
    (c)<-[:FOR_CONSTRUCTOR]-(res:Result)-[:FOR_RACE]->(r:Race)
WHERE r.year = s.year

RETURN
    c.constructorId AS constructor_id,
    c.constructor_name AS constructor,
    s.year AS year,
    count(res) AS race_entries,
    coalesce(sum(res.points), 0.0) AS points
"""


def retrieve_constructor_season_points(
    db: Neo4jClient,
    constructor_id: int,
    year: int,
) -> RetrievalResult:
    """
    Retrieve a constructor's Grand Prix points
    for a specified season.

    Points are summed from Result nodes.
    Sprint points are not included because the
    Milestone 2 graph does not contain sprint results.
    """

    parameters = {
        "constructor_id": constructor_id,
        "year": year,
    }

    rows = db.run_read(
        CONSTRUCTOR_SEASON_POINTS_CYPHER,
        parameters,
    )

    return RetrievalResult(
        intent=Intent.CONSTRUCTOR_PERFORMANCE,
        template_id="constructor_season_points",
        cypher=CONSTRUCTOR_SEASON_POINTS_CYPHER,
        parameters=parameters,
        rows=rows,
    )

# --------------------------------------------------
# Race winner retrieval
# --------------------------------------------------

RACE_WINNER_CYPHER = """
MATCH (r:Race {raceId: $race_id})
MATCH (res:Result)-[:FOR_RACE]->(r)
MATCH (res)-[:BY_DRIVER]->(d:Driver)
WHERE res.positionOrder = 1

RETURN DISTINCT
    r.raceId AS race_id,
    r.name AS race,
    r.year AS year,
    d.driverId AS driver_id,
    d.forename + ' ' + d.surname AS winner,
    res.positionOrder AS finishing_position

ORDER BY driver_id
LIMIT 10
"""


def retrieve_race_winner(
    db: Neo4jClient,
    race_id: int,
) -> RetrievalResult:
    """
    Retrieve the winner of a specific Grand Prix.

    Uses the official finishing order recorded
    in Result nodes.

    Returns all matching records rather than
    arbitrarily choosing a driver.
    """

    parameters = {
        "race_id": race_id,
    }

    rows = db.run_read(
        RACE_WINNER_CYPHER,
        parameters,
    )

    return RetrievalResult(
        intent=Intent.RACE_RESULTS,
        template_id="race_winner",
        cypher=RACE_WINNER_CYPHER,
        parameters=parameters,
        rows=rows,
    )

# --------------------------------------------------
# Race podium retrieval
# --------------------------------------------------

RACE_PODIUM_CYPHER = """
MATCH (r:Race {raceId: $race_id})
MATCH (res:Result)-[:FOR_RACE]->(r)
MATCH (res)-[:BY_DRIVER]->(d:Driver)

WHERE res.positionOrder IN [1, 2, 3]

RETURN DISTINCT
    r.raceId AS race_id,
    r.name AS race,
    r.year AS year,
    d.driverId AS driver_id,
    d.forename + ' ' + d.surname AS driver,
    res.positionOrder AS finishing_position

ORDER BY finishing_position ASC, driver_id ASC
LIMIT 20
"""


def retrieve_race_podium(
    db: Neo4jClient,
    race_id: int,
) -> RetrievalResult:
    """
    Retrieve podium finishers for a specific race.

    Uses the Result nodes in the Knowledge Graph.

    Historical shared drives may result in more
    than three drivers associated with podium
    finishing positions. We preserve those records.
    """

    parameters = {
        "race_id": race_id,
    }

    rows = db.run_read(
        RACE_PODIUM_CYPHER,
        parameters,
    )

    return RetrievalResult(
        intent=Intent.RACE_RESULTS,
        template_id="race_podium",
        cypher=RACE_PODIUM_CYPHER,
        parameters=parameters,
        rows=rows,
    )

# --------------------------------------------------
# Driver wins at a circuit
# --------------------------------------------------

DRIVER_CIRCUIT_WINS_CYPHER = """
MATCH (d:Driver {driverId: $driver_id})
MATCH (c:Circuit {circuitId: $circuit_id})

OPTIONAL MATCH
    (d)<-[:BY_DRIVER]-(res:Result)
       -[:FOR_RACE]->(r:Race)
       -[:AT_CIRCUIT]->(c)

WHERE $year IS NULL OR r.year = $year

RETURN
    d.driverId AS driver_id,
    d.forename + ' ' + d.surname AS driver,
    c.circuitId AS circuit_id,
    c.circuit_name AS circuit,
    $year AS year,
    count(DISTINCT r.raceId) AS race_entries,
    count(
        DISTINCT CASE
            WHEN res.positionOrder = 1
            THEN r.raceId
            ELSE NULL
        END
    ) AS wins
"""


def retrieve_driver_circuit_wins(
    db: Neo4jClient,
    driver_id: int,
    circuit_id: int,
    year: int | None = None,
) -> RetrievalResult:
    """
    Count a driver's Grand Prix wins at one circuit.

    When year is None, include all available seasons.
    When a year is provided, filter to that season.

    Count distinct races to avoid duplicate counting.
    """

    parameters = {
        "driver_id": driver_id,
        "circuit_id": circuit_id,
        "year": year,
    }

    rows = db.run_read(
        DRIVER_CIRCUIT_WINS_CYPHER,
        parameters,
    )

    return RetrievalResult(
        intent=Intent.DRIVER_PERFORMANCE,
        template_id="driver_circuit_wins",
        cypher=DRIVER_CIRCUIT_WINS_CYPHER,
        parameters=parameters,
        rows=rows,
    )


# --------------------------------------------------
# Driver season wins (race-level victories)
# --------------------------------------------------

DRIVER_SEASON_WINS_CYPHER = """
MATCH (s:Season {year: $year})
MATCH (d:Driver {driverId: $driver_id})
OPTIONAL MATCH (d)<-[:BY_DRIVER]-(res:Result)-[:FOR_RACE]->(r:Race)
WHERE r.year = s.year
RETURN
    d.driverId AS driver_id,
    d.forename + ' ' + d.surname AS driver,
    s.year AS year,
    count(DISTINCT r.raceId) AS race_entries,
    count(DISTINCT CASE WHEN res.positionOrder = 1
        THEN r.raceId ELSE NULL END) AS wins
"""


def retrieve_driver_season_wins(
    db: Neo4jClient, driver_id: int, year: int,
) -> RetrievalResult:
    parameters = {"driver_id": driver_id, "year": year}
    return RetrievalResult(
        intent=Intent.DRIVER_PERFORMANCE,
        template_id="driver_season_wins",
        cypher=DRIVER_SEASON_WINS_CYPHER,
        parameters=parameters,
        rows=db.run_read(DRIVER_SEASON_WINS_CYPHER, parameters),
    )


# --------------------------------------------------
# Constructor season wins (deduplicated by race)
# --------------------------------------------------

CONSTRUCTOR_SEASON_WINS_CYPHER = """
MATCH (s:Season {year: $year})
MATCH (c:Constructor {constructorId: $constructor_id})
OPTIONAL MATCH (c)<-[:FOR_CONSTRUCTOR]-(res:Result)-[:FOR_RACE]->(r:Race)
WHERE r.year = s.year
RETURN
    c.constructorId AS constructor_id,
    c.constructor_name AS constructor,
    s.year AS year,
    count(DISTINCT r.raceId) AS race_entries,
    count(DISTINCT CASE WHEN res.positionOrder = 1
        THEN r.raceId ELSE NULL END) AS wins
"""


def retrieve_constructor_season_wins(
    db: Neo4jClient, constructor_id: int, year: int,
) -> RetrievalResult:
    parameters = {"constructor_id": constructor_id, "year": year}
    return RetrievalResult(
        intent=Intent.CONSTRUCTOR_PERFORMANCE,
        template_id="constructor_season_wins",
        cypher=CONSTRUCTOR_SEASON_WINS_CYPHER,
        parameters=parameters,
        rows=db.run_read(CONSTRUCTOR_SEASON_WINS_CYPHER, parameters),
    )


# --------------------------------------------------
# Circuit location (official circuit node properties)
# --------------------------------------------------

CIRCUIT_LOCATION_CYPHER = """
MATCH (c:Circuit {circuitId: $circuit_id})
RETURN
    c.circuitId AS circuit_id,
    c.circuit_name AS circuit,
    c.circuit_loc AS city,
    c.circuit_country AS country
LIMIT 1
"""


def retrieve_circuit_location(
    db: Neo4jClient, circuit_id: int,
) -> RetrievalResult:
    parameters = {"circuit_id": circuit_id}
    return RetrievalResult(
        intent=Intent.CIRCUIT_FACTS,
        template_id="circuit_location",
        cypher=CIRCUIT_LOCATION_CYPHER,
        parameters=parameters,
        rows=db.run_read(CIRCUIT_LOCATION_CYPHER, parameters),
    )


# --------------------------------------------------
# Two-driver head-to-head in races where both appear.
# Optionally restrict both drivers to the same constructor.
# --------------------------------------------------

DRIVER_HEAD_TO_HEAD_CYPHER = """
MATCH (d1:Driver {driverId: $driver1_id})
MATCH (d2:Driver {driverId: $driver2_id})
MATCH (a:Result)-[:BY_DRIVER]->(d1)
MATCH (a)-[:FOR_RACE]->(r:Race)
MATCH (b:Result)-[:BY_DRIVER]->(d2)
MATCH (b)-[:FOR_RACE]->(r)
MATCH (a)-[:FOR_CONSTRUCTOR]->(ca:Constructor)
MATCH (b)-[:FOR_CONSTRUCTOR]->(cb:Constructor)
WHERE d1.driverId <> d2.driverId
  AND a.positionOrder IS NOT NULL
  AND b.positionOrder IS NOT NULL
  AND ($year_from IS NULL OR r.year >= $year_from)
  AND ($year_to IS NULL OR r.year <= $year_to)
  AND ($constructor_id IS NULL OR
       (ca.constructorId = $constructor_id AND
        cb.constructorId = $constructor_id))
WITH d1, d2, r.raceId AS race_id,
     min(a.positionOrder) AS position1,
     min(b.positionOrder) AS position2
WITH d1, d2, count(race_id) AS shared_races,
     sum(CASE WHEN position1 < position2 THEN 1 ELSE 0 END) AS driver1_ahead,
     sum(CASE WHEN position2 < position1 THEN 1 ELSE 0 END) AS driver2_ahead,
     sum(CASE WHEN position1 = position2 THEN 1 ELSE 0 END) AS ties
RETURN
    d1.forename + ' ' + d1.surname AS driver1,
    d2.forename + ' ' + d2.surname AS driver2,
    shared_races, driver1_ahead, driver2_ahead, ties
LIMIT 1
"""


def retrieve_driver_head_to_head(
    db: Neo4jClient,
    driver1_id: int,
    driver2_id: int,
    constructor_id: int | None = None,
    year_from: int | None = None,
    year_to: int | None = None,
) -> RetrievalResult:
    """Compare official result-order positions in shared Grand Prix races."""
    if driver1_id == driver2_id:
        raise ValueError("Head-to-head requires two different drivers")
    parameters = {
        "driver1_id": driver1_id,
        "driver2_id": driver2_id,
        "constructor_id": constructor_id,
        "year_from": year_from,
        "year_to": year_to,
    }
    return RetrievalResult(
        intent=Intent.HEAD_TO_HEAD,
        template_id="driver_comparison",
        cypher=DRIVER_HEAD_TO_HEAD_CYPHER,
        parameters=parameters,
        rows=db.run_read(DRIVER_HEAD_TO_HEAD_CYPHER, parameters),
    )


# --------------------------------------------------
# Qualifying result for one driver in one named race.
# This is Qualifying.position, NOT the race starting grid.
# --------------------------------------------------

DRIVER_RACE_QUALIFYING_CYPHER = """
MATCH (r:Race {raceId: $race_id})
MATCH (q:Qualifying)-[:FOR_RACE]->(r)
MATCH (q)-[:BY_DRIVER]->(d:Driver {driverId: $driver_id})
RETURN
    r.name AS race,
    r.year AS year,
    d.forename + ' ' + d.surname AS driver,
    q.position AS qualifying_position
ORDER BY q.qualifyId ASC
LIMIT 2
"""


def retrieve_driver_race_qualifying(
    db: Neo4jClient, driver_id: int, race_id: int,
) -> RetrievalResult:
    parameters = {"driver_id": driver_id, "race_id": race_id}
    return RetrievalResult(
        intent=Intent.QUALIFYING_GRID,
        template_id="qualifying_position",
        cypher=DRIVER_RACE_QUALIFYING_CYPHER,
        parameters=parameters,
        rows=db.run_read(DRIVER_RACE_QUALIFYING_CYPHER, parameters),
    )


# --------------------------------------------------
# Fastest measured pit stop(s) for one race.
# Return ties up to 10 rows, not an arbitrary single winner.
# --------------------------------------------------

FASTEST_RACE_PIT_STOP_CYPHER = """
MATCH (r:Race {raceId: $race_id})
MATCH (p:PitStop)-[:FOR_RACE]->(r)
WHERE p.milliseconds IS NOT NULL
WITH r, min(p.milliseconds) AS fastest_ms
MATCH (p:PitStop)-[:FOR_RACE]->(r)
MATCH (p)-[:BY_DRIVER]->(d:Driver)
WHERE p.milliseconds = fastest_ms
RETURN
    r.name AS race,
    r.year AS year,
    d.forename + ' ' + d.surname AS driver,
    p.stop AS stop_number,
    p.lap AS lap,
    p.milliseconds AS milliseconds
ORDER BY driver ASC, stop_number ASC
LIMIT 10
"""


def retrieve_fastest_race_pit_stop(
    db: Neo4jClient, race_id: int,
) -> RetrievalResult:
    parameters = {"race_id": race_id}
    return RetrievalResult(
        intent=Intent.PIT_STOP_STRATEGY,
        template_id="fastest_pit_stop",
        cypher=FASTEST_RACE_PIT_STOP_CYPHER,
        parameters=parameters,
        rows=db.run_read(FASTEST_RACE_PIT_STOP_CYPHER, parameters),
    )


# --------------------------------------------------
# Drivers with different constructor participation
# across two distinct seasons (including multi-team years).
# --------------------------------------------------

SEASON_TEAM_CHANGES_CYPHER = """
MATCH (res1:Result)-[:FOR_RACE]->(r1:Race {year: $year1})
MATCH (res1)-[:BY_DRIVER]->(d:Driver)
MATCH (res1)-[:FOR_CONSTRUCTOR]->(c1:Constructor)
WITH d, collect(DISTINCT c1.constructor_name) AS earlier_teams
MATCH (res2:Result)-[:BY_DRIVER]->(d)
MATCH (res2)-[:FOR_RACE]->(r2:Race {year: $year2})
MATCH (res2)-[:FOR_CONSTRUCTOR]->(c2:Constructor)
WITH d, earlier_teams,
     collect(DISTINCT c2.constructor_name) AS later_teams
WHERE any(t IN earlier_teams WHERE NOT (t IN later_teams))
   OR any(t IN later_teams WHERE NOT (t IN earlier_teams))
RETURN
    d.forename + ' ' + d.surname AS driver,
    earlier_teams, later_teams
ORDER BY driver ASC
LIMIT 50
"""


def retrieve_season_team_changes(
    db: Neo4jClient, year1: int, year2: int,
) -> RetrievalResult:
    if year1 == year2:
        raise ValueError("Two distinct seasons are required")
    parameters = {"year1": year1, "year2": year2}
    return RetrievalResult(
        intent=Intent.SEASON_HISTORY,
        template_id="season_team_changes",
        cypher=SEASON_TEAM_CHANGES_CYPHER,
        parameters=parameters,
        rows=db.run_read(SEASON_TEAM_CHANGES_CYPHER, parameters),
    )
