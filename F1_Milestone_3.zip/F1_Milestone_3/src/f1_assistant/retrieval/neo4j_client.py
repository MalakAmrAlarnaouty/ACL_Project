
from pathlib import Path

import truststore

# Use Windows' trusted certificates.
# This must run before importing the Neo4j driver.
truststore.inject_into_ssl()

from dotenv import dotenv_values
from neo4j import GraphDatabase, READ_ACCESS


class Neo4jClient:
    """Reusable connection for querying the F1 Knowledge Graph."""

    def __init__(self):
        # Locate the project root and its .env file.
        project_root = Path(__file__).resolve().parents[3]
        env_path = project_root / ".env"

        config = dotenv_values(
            env_path,
            encoding="utf-8-sig"
        )

        uri = config.get("NEO4J_URI")
        username = config.get("NEO4J_USERNAME")
        password = config.get("NEO4J_PASSWORD")

        if not all([uri, username, password]):
            raise ValueError(
                "Missing Neo4j configuration in .env"
            )

        self.database = config.get("NEO4J_DATABASE") or None

        self.driver = GraphDatabase.driver(
            uri,
            auth=(username, password),
            connection_timeout=15
        )

    def verify_connection(self):
        """Verify the Neo4j server is reachable."""
        self.driver.verify_connectivity()

    def run_read(self, cypher, parameters=None):
        """Execute a parameterized read query and return records."""

        parameters = parameters or {}

        with self.driver.session(
            database=self.database,
            default_access_mode=READ_ACCESS
        ) as session:

            def execute(tx):
                result = tx.run(cypher, parameters)
                return [record.data() for record in result]

            return session.execute_read(execute)

    def close(self):
        """Release database connections."""
        self.driver.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        self.close()
