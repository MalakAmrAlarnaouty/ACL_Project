
import re
from collections import defaultdict

from f1_assistant.contracts import EntityExtraction


def normalize_name(text: str) -> str:
    """Normalize case, punctuation and whitespace."""
    text = re.sub(r"[^\w\s]", " ", text.casefold())
    text = text.replace("_", " ")
    return " ".join(text.split())


# Additional commonly used circuit names.
# Keys correspond to circuitRef values in Neo4j.
EXTRA_ALIASES = {
    "silverstone": ["Silverstone"],
    "monaco": ["Monaco", "Monte Carlo"],
    "monza": ["Monza"],
    "spa": ["Spa", "Spa Francorchamps"],
    "americas": ["COTA"],
    "albert_park": ["Albert Park"],
    "interlagos": ["Interlagos"],
}


def extract_circuit_entities(
    question: str,
    circuits: list[dict],
) -> EntityExtraction:
    """
    Extract circuit IDs from natural-language questions.

    Prefer longer matches and report ambiguous aliases.
    """

    text = normalize_name(question)
    result = EntityExtraction()

    alias_map = defaultdict(dict)

    # Build aliases using actual Neo4j circuit records.
    for circuit in circuits:
        circuit_id = circuit["circuit_id"]
        circuit_name = circuit["circuit_name"]
        circuit_ref = circuit.get("circuit_ref") or ""

        aliases = [
            circuit_name,
            circuit_ref,
            *EXTRA_ALIASES.get(circuit_ref, []),
        ]

        for raw_alias in aliases:
            alias = normalize_name(raw_alias)

            if not alias:
                continue

            alias_map[alias][circuit_id] = circuit

    # Find candidate mentions.
    matches = []

    for alias, candidate_map in alias_map.items():
        pattern = r"(?<!\w)" + re.escape(alias) + r"(?!\w)"

        for match in re.finditer(pattern, text):
            matches.append(
                (
                    match.start(),
                    match.end(),
                    alias,
                    list(candidate_map.values()),
                )
            )

    # Prefer longer names when matches overlap.
    matches.sort(
        key=lambda item: (
            -(item[1] - item[0]),
            item[0],
        )
    )

    selected = []
    occupied = []

    for start, end, alias, candidates in matches:
        overlaps = any(
            start < previous_end and end > previous_start
            for previous_start, previous_end in occupied
        )

        if overlaps:
            continue

        occupied.append((start, end))

        if len(candidates) > 1:
            result.ambiguous[alias] = [
                candidate["circuit_name"]
                for candidate in candidates
            ]
            continue

        circuit = candidates[0]

        selected.append(
            (
                start,
                {
                    "circuit_id": circuit["circuit_id"],
                    "name": circuit["circuit_name"],
                },
            )
        )

    # Preserve the order of circuit mentions.
    selected.sort(key=lambda item: item[0])

    unique = {}

    for _, circuit in selected:
        unique[circuit["circuit_id"]] = circuit

    if unique:
        result.entities["circuits"] = list(unique.values())

    if not unique and not result.ambiguous:
        result.missing.append("circuit")

    return result
