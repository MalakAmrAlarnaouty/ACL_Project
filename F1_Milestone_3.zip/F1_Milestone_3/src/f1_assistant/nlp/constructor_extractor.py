
import re
from collections import defaultdict

from f1_assistant.contracts import EntityExtraction


def normalize_name(text: str) -> str:
    """Normalize names, punctuation, underscores, and case."""
    text = re.sub(r"[^\w\s]", " ", text.casefold())
    text = text.replace("_", " ")
    return " ".join(text.split())


def extract_constructor_entities(
    question: str,
    constructors: list[dict],
) -> EntityExtraction:
    """Identify constructor IDs using Neo4j names and aliases."""

    text = normalize_name(question)
    result = EntityExtraction()

    # Map each supported name or alias to its constructors.
    alias_map = defaultdict(dict)

    for constructor in constructors:
        constructor_id = constructor["constructor_id"]
        canonical_name = constructor["constructor_name"]

        aliases = [
            canonical_name,
            constructor.get("constructor_ref") or "",
        ]

        # Common aliases not necessarily present in Neo4j.
        if normalize_name(canonical_name) == "mercedes":
            aliases.extend(["Mercedes AMG", "Mercedes-AMG"])

        for raw_alias in aliases:
            alias = normalize_name(raw_alias)

            if not alias:
                continue

            alias_map[alias][constructor_id] = constructor

            # Support compact names such as "redbull".
            compact = alias.replace(" ", "")

            if len(compact) >= 4:
                alias_map[compact][constructor_id] = constructor

    # Locate matching aliases in the question.
    matches = []

    for alias, candidates in alias_map.items():
        if len(alias) < 3:
            continue

        pattern = r"(?<!\w)" + re.escape(alias) + r"(?!\w)"

        for match in re.finditer(pattern, text):
            matches.append((
                match.start(),
                match.end(),
                alias,
                list(candidates.values()),
            ))

    # Prefer the longest name when matches overlap.
    matches.sort(key=lambda item: (
        -(item[1] - item[0]),
        item[0],
    ))

    selected = []
    occupied = []

    for start, end, alias, candidates in matches:
        overlaps = any(
            start < previous_end and end > previous_start
            for previous_start, previous_end in occupied
        )

        if overlaps:
            continue

        occupied.append((start, end))

        if len(candidates) > 1:
            result.ambiguous[alias] = [
                candidate["constructor_name"]
                for candidate in candidates
            ]
            continue

        constructor = candidates[0]

        selected.append((
            start,
            {
                "constructor_id": constructor["constructor_id"],
                "name": constructor["constructor_name"],
            },
        ))

    # Preserve the order of mentions in the question.
    selected.sort(key=lambda item: item[0])

    unique = {}

    for _, constructor in selected:
        unique[constructor["constructor_id"]] = constructor

    if unique:
        result.entities["constructors"] = list(unique.values())

    if not unique and not result.ambiguous:
        result.missing.append("constructor")

    return result
