
import re

from f1_assistant.contracts import EntityExtraction


YEAR_PATTERN = re.compile(
    r"(?<!\d)(?:19|20)\d{2}(?!\d)"
)


def extract_year_entities(question: str) -> EntityExtraction:
    """
    Extract four-digit year mentions from a question.

    Supports one or multiple years.
    Preserves mention order and removes duplicates.
    """

    result = EntityExtraction()

    years = []
    seen = set()

    for match in YEAR_PATTERN.finditer(question):
        year = int(match.group())

        if year not in seen:
            years.append(year)
            seen.add(year)

    if years:
        result.entities["years"] = years
    else:
        result.missing.append("year")

    return result
