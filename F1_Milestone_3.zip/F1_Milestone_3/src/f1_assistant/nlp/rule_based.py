
import re

from f1_assistant.contracts import Intent, IntentPrediction
from f1_assistant.nlp.rule_extensions import classify_extended


def normalize_text(text: str) -> str:
    """Normalize capitalization and whitespace."""
    return re.sub(r"\s+", " ", text.casefold()).strip()


def matches(pattern: str, text: str) -> bool:
    """Check whether a regular expression matches."""
    return re.search(pattern, text) is not None


def recognized(
    intent: Intent,
    question_type: str,
) -> IntentPrediction:
    """Build a standardized classification result."""
    return IntentPrediction(
        intent=intent,
        method="rule_based",
        question_type=question_type,
    )


def classify_intent(text: str) -> IntentPrediction:
    """Recognize an F1 question using explicit patterns."""

    question = normalize_text(text)

    if not question:
        return IntentPrediction(
            intent=None,
            method="rule_based",
            needs_clarification=True,
            reason="Please enter a question.",
        )

    # --------------------------------------------------
    extra = classify_extended(question)
    if extra is not None:
        return extra

    # 1. Prediction requests
    # --------------------------------------------------

    if matches(
        r"\b(predict|prediction|podium probability|podium chances?)\b",
        question,
    ):
        return recognized(
            Intent.PODIUM_PREDICTION,
            "podium_prediction",
        )

    if (
        matches(r"\b(likely|likelihood|chance|chances)\b", question)
        and matches(r"\bpodium\b", question)
    ):
        return recognized(
            Intent.PODIUM_PREDICTION,
            "podium_prediction",
        )

    # --------------------------------------------------
    # 2. Pit stop questions
    # --------------------------------------------------

    # Fastest pit stop.
    if (
        matches(
            r"\b(pit stops?|pitstops?)\b",
            question,
        )
        and matches(
            r"\b(fastest|quickest|shortest)\b",
            question,
        )
    ):
        return recognized(
            Intent.PIT_STOP_STRATEGY,
            "fastest_pit_stop",
        )

    # Average pit stops per race.
    if (
        matches(
            r"\b(pit stops?|pitstops?)\b",
            question,
        )
        and matches(
            r"\b(average|mean|per race)\b",
            question,
        )
    ):
        return recognized(
            Intent.PIT_STOP_STRATEGY,
            "average_pit_stops_per_race",
        )

    # Number of pit stops made by a driver.
    if (
        matches(
            r"\b(pit stops?|pitstops?)\b",
            question,
        )
        and matches(
            r"\b(how many|number of|total|count)\b",
            question,
        )
    ):
        return recognized(
            Intent.PIT_STOP_STRATEGY,
            "driver_pit_stop_count",
        )

    # --------------------------------------------------
    # 3. Qualifying and grid questions
    # --------------------------------------------------

    # Q3 appearances.
    if (
        matches(
            r"\b(q3|final qualifying session)\b",
            question,
        )
        and matches(
            r"\b(how many|how often|appearances?|"
            r"reached?|made|qualified|times)\b",
            question,
        )
    ):
        return recognized(
            Intent.QUALIFYING_GRID,
            "q3_appearances",
        )

    # Grid positions gained.
    if (
        matches(
            r"\b(gain|gains|gained|gaining|"
            r"improve|improved|improvement|"
            r"made up|picked up|climbed)\b",
            question,
        )
        and matches(
            r"\b(grid|starting positions?|starting grid)\b",
            question,
        )
        and matches(
            r"\b(places?|positions?|spots?)\b",
            question,
        )
    ):
        return recognized(
            Intent.QUALIFYING_GRID,
            "grid_position_gains",
        )

    # Qualifying position.
    if (
        matches(
            r"\b(qualified|qualify|qualifying)\b",
            question,
        )
        and matches(
            r"\b(position|where|place)\b",
            question,
        )
    ):
        return recognized(
            Intent.QUALIFYING_GRID,
            "qualifying_position",
        )

    # Pole positions.
    if matches(
        r"\b(pole positions?|poles?|"
        r"qualified first|qualified on pole)\b",
        question,
    ):
        return recognized(
            Intent.QUALIFYING_GRID,
            "pole_positions",
        )

    # --------------------------------------------------
    # 5. Season history and team changes
    # --------------------------------------------------

    if (
        matches(
            r"\b(changes?|changed|switched?|moved?|"
            r"transferred?|different)\b",
            question,
        )
        and matches(
            r"\b(teams?|constructors?|seats?)\b",
            question,
        )
    ):
        return recognized(
            Intent.SEASON_HISTORY,
            "season_team_changes",
        )

    # --------------------------------------------------
    # 4. Head-to-head comparisons
    # --------------------------------------------------

    if matches(
        r"\b(head[\s-]?to[\s-]?head|compare|versus|vs\.?|"
        r"who finished ahead|who placed ahead|who beat whom)\b",
        question,
    ):
        return recognized(
            Intent.HEAD_TO_HEAD,
            "driver_comparison",
        )

    # --------------------------------------------------
    # 6. Constructor performance
    # --------------------------------------------------

    # Constructor reliability.
    if matches(
        r"\b(reliable|reliability|classified finish(?:es)?|"
        r"classification rate|finish rate)\b",
        question,
    ):
        return recognized(
            Intent.CONSTRUCTOR_PERFORMANCE,
            "constructor_reliability",
        )

    # Constructor season points.
    if (
        matches(r"\bpoints?\b", question)
        and matches(
            r"\b(teams?|constructors?|ferrari|mercedes|"
            r"mclaren|red bull|redbull|williams|renault|"
            r"alpine|aston martin|haas|sauber)\b",
            question,
        )
    ):
        return recognized(
            Intent.CONSTRUCTOR_PERFORMANCE,
            "constructor_season_points",
        )

    # Constructor season wins.
    if (
        matches(
            r"\b(wins?|won|victory|victories)\b",
            question,
        )
        and matches(
            r"\b(teams?|constructors?|ferrari|mercedes|"
            r"mclaren|red bull|redbull|williams|"
            r"renault|alpine|aston martin|haas|sauber)\b",
            question,
        )
    ):
        return recognized(
            Intent.CONSTRUCTOR_PERFORMANCE,
            "constructor_season_wins",
        )

    # Constructor race entries.
    if (
        matches(
            r"\b(race entries|race starts|race appearances|"
            r"entries|entered races|participations)\b",
            question,
        )
        and matches(
            r"\b(teams?|constructors?|ferrari|mercedes|"
            r"mclaren|red bull|redbull|williams|"
            r"renault|alpine|aston martin|haas|sauber)\b",
            question,
        )
    ):
        return recognized(
            Intent.CONSTRUCTOR_PERFORMANCE,
            "constructor_race_entries",
        )

    # --------------------------------------------------
    # 7. Race-specific top-three requests
    # --------------------------------------------------
    # IMPORTANT:
    # This rule must appear BEFORE driver podium
    # statistics, because "top three" can refer
    # either to a particular race or a whole season.

    if (
        matches(
            r"\btop\s*(?:3|three)\s+"
            r"(?:finishers?|drivers?|positions?)\b",
            question,
        )
        and matches(
            r"\b(?:grand\s+prix|gp)\b",
            question,
        )
    ):
        return recognized(
            Intent.RACE_RESULTS,
            "race_winner_or_podium",
        )

    # --------------------------------------------------
    # 8. Driver performance
    # --------------------------------------------------

    # Driver season podium count.
    if (
        matches(
            r"\b(podiums?|top[\s-]+(?:three|3))\b",
            question,
        )
        and matches(
            r"\b(how many|number of|count|total)\b",
            question,
        )
    ):
        return recognized(
            Intent.DRIVER_PERFORMANCE,
            "driver_season_podiums",
        )

    # Driver season points.
    if (
        matches(r"\bpoints?\b", question)
        and matches(
            r"\b(scored?|earned?|gained?|how many)\b",
            question,
        )
    ):
        return recognized(
            Intent.DRIVER_PERFORMANCE,
            "driver_season_points",
        )

    # Driver wins at a circuit.
    if (
        (
            matches(r"\b(wins?|victory|victories)\b", question)
            or (
                matches(r"\bwon\b", question)
                and matches(
                    r"\b(how many|number of|times)\b",
                    question,
                )
            )
        )
        and matches(
            r"\b(at|around|on)\b",
            question,
        )
    ):
        return recognized(
            Intent.DRIVER_PERFORMANCE,
            "driver_circuit_wins",
        )

    # Driver season wins.
    if (
        matches(
            r"\b(how many|number of|count|total)\b",
            question,
        )
        and matches(
            r"\b(wins?|victories|victory|races won)\b",
            question,
        )
        and matches(
            r"\b(in|during|season|year)\b",
            question,
        )
    ):
        return recognized(
            Intent.DRIVER_PERFORMANCE,
            "driver_season_wins",
        )

    # --------------------------------------------------
    # 9. Race winners and podium finishers
    # --------------------------------------------------

    if (
        matches(
            r"\b(who won|winner of|race winner|"
            r"who finished on the podium|"
            r"podium finishers?|race podium)\b",
            question,
        )
        and matches(
            r"\b(grand prix|gp|race|podium|at|in)\b",
            question,
        )
    ):
        return recognized(
            Intent.RACE_RESULTS,
            "race_winner_or_podium",
        )

    # --------------------------------------------------
    # 10. Circuit location facts
    # --------------------------------------------------

    if (
        matches(
            r"\b(where is|where's|which country|"
            r"which city|location of|located)\b",
            question,
        )
        and matches(
            r"\b(circuit|track|silverstone|monaco|"
            r"monza|spa)\b",
            question,
        )
    ):
        return recognized(
            Intent.CIRCUIT_FACTS,
            "circuit_location",
        )

    # --------------------------------------------------
    # 11. Out-of-scope questions
    # --------------------------------------------------

    # Explicitly unrelated topics.
    # Neural similarity alone must never decide out-of-scope.
    if matches(
        r"\b(?:bake|baking|recipes?|jokes?)\b|\bcapital of\b",
        question,
    ):
        return recognized(
            Intent.OUT_OF_SCOPE,
            "out_of_scope",
        )
    if matches(
        r"\b(weather|pizza|stock price)\b",
        question,
    ):
        return recognized(
            Intent.OUT_OF_SCOPE,
            "out_of_scope",
        )

    # --------------------------------------------------
    # 12. Unknown questions
    # --------------------------------------------------

    # Unknown questions must not be assigned
    # an F1 intent without sufficient evidence.
    return IntentPrediction(
        intent=None,
        method="rule_based",
        needs_clarification=True,
        reason="Intent is not confidently recognized.",
    )
