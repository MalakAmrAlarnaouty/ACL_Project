"""Local neural embedding-based broad-intent classification for F1 questions.

Does not touch the 66-question evaluation dataset or the Neo4j graph.
Prototype phrases are authored separately from the evaluation questions.
"""

from __future__ import annotations

from dataclasses import dataclass
import re

import numpy as np
from fastembed import TextEmbedding

from f1_assistant.contracts import Intent


# Six independent prototype phrasings for each supported broad intent.
# UNKNOWN is represented by abstention, not a matching prototype category.
INTENT_EXAMPLES: dict[Intent, list[str]] = {
    Intent.DRIVER_PERFORMANCE: [
        "Give me a driver's total championship points for a season.",
        "Count a racer's victories during a specific year.",
        "Show the number of podium results for a driver.",
        "How often did a driver win at a particular circuit?",
        "Summarize one driver's performance across a racing season.",
        "Calculate how many race finishes were top three for this driver.",
    ],
    Intent.CONSTRUCTOR_PERFORMANCE: [
        "Total the season points earned by a Formula One team.",
        "Count the races won by a constructor in one year.",
        "How many entries did a racing team make over this period?",
        "Evaluate a constructor's classified-finish reliability.",
        "Compare the race participation statistics of a team.",
        "Report how successfully this constructor finished its starts.",
    ],
    Intent.HEAD_TO_HEAD: [
        "Compare the race results of two drivers against each other.",
        "Which of these two racers finished ahead more frequently?",
        "Give a head-to-head comparison between two teammates.",
        "How often was driver A better placed than driver B?",
        "Show the record when these competitors raced together.",
        "Which driver came out ahead in their shared Grands Prix?",
    ],
    Intent.RACE_RESULTS: [
        "Name the winner of a particular Grand Prix.",
        "List the podium finishers from a specified race.",
        "Give the first, second, and third-place drivers in one event.",
        "Who took the victory at this Formula One race?",
        "Which competitors occupied the podium after this Grand Prix?",
        "Tell me the official finishing order for the selected event.",
    ],
    Intent.CIRCUIT_FACTS: [
        "In which country is this Formula One circuit located?",
        "Tell me the city where the racing track is situated.",
        "Give the geographic location of an F1 venue.",
        "Where can I find this Grand Prix circuit?",
        "Identify the country and city of the specified track.",
        "Provide basic location facts about this racing circuit.",
    ],
    Intent.QUALIFYING_GRID: [
        "Count how many pole positions the driver secured.",
        "At what grid position did this racer qualify?",
        "How many times did a driver make the third qualifying session?",
        "Calculate the places a racer gained from starting grid to finish.",
        "Give the qualifying placement from a Grand Prix weekend.",
        "Report qualifying and starting-position statistics.",
    ],
    Intent.PIT_STOP_STRATEGY: [
        "Find the quickest tyre change during a Grand Prix.",
        "How many visits to the pits did this racer make?",
        "Calculate the mean pit-stop count for each race.",
        "Show pit-lane stop durations for a selected event.",
        "Which stop had the lowest recorded service time?",
        "Analyze pit-stop counts and durations in Formula One.",
    ],
    Intent.SEASON_HISTORY: [
        "List the drivers who moved to other teams between two seasons.",
        "Describe constructor changes from one year to the next.",
        "Which racers switched racing teams in the off-season?",
        "Show the changes in driver-team membership over time.",
        "Track the racing teams each driver represented by year.",
        "Find driver transfers from one championship season to another.",
    ],
    Intent.PODIUM_PREDICTION: [
        "Forecast whether this driver will reach the podium next race.",
        "Estimate a racer's probability of a top-three finish.",
        "Predict the chances of a podium result in an upcoming Grand Prix.",
        "What is the projected podium likelihood for this competitor?",
        "Generate a pre-race podium prediction for this driver.",
        "Estimate whether the selected racer will finish in the top three.",
    ],
    Intent.OUT_OF_SCOPE: [
        "Explain tomorrow's weather forecast in my city.",
        "What are the latest prices of shares on the stock market?",
        "Suggest an easy recipe for dinner tonight.",
        "Help me fix the plumbing in my apartment.",
        "Summarize a chapter from a chemistry textbook.",
        "Recommend a movie for the weekend.",
    ],
}




@dataclass(frozen=True)
class SemanticIntentResult:
    intent: Intent | None
    similarity: float
    margin: float
    abstained: bool
    scores: dict[str, float]


class EmbeddingIntentClassifier:
    """Classify broad F1 intents using pretrained neural embeddings.

    Cosine similarity is a ranking score, NOT a calibrated probability.
    Initial thresholds are provisional and require tuning on a separate
    development set (not the final held-out evaluation questions).
    """

    def __init__(
        self,
        model_name: str = "BAAI/bge-small-en-v1.5",
        min_similarity: float = 0.43,
        min_margin: float = 0.01,
    ) -> None:
        if not -1 <= min_similarity <= 1:
            raise ValueError("min_similarity must be between -1 and 1")
        if min_margin < 0:
            raise ValueError("min_margin must be non-negative")

        self.min_similarity = min_similarity
        self.min_margin = min_margin
        self.model = TextEmbedding(model_name=model_name)

        self.labels: list[Intent] = []
        examples: list[str] = []
        for intent, phrases in INTENT_EXAMPLES.items():
            for phrase in phrases:
                self.labels.append(intent)
                examples.append(phrase)

        vectors = np.asarray(list(self.model.embed(examples)), dtype=np.float32)
        norms = np.maximum(np.linalg.norm(vectors, axis=1, keepdims=True), 1e-12)
        self.example_vectors = vectors / norms

    def predict(self, question: str) -> SemanticIntentResult:
        normalized = re.sub(r"\s+", " ", question).strip()
        if not normalized:
            return SemanticIntentResult(None, 0.0, 0.0, True, {})

        vector = np.asarray(next(iter(self.model.embed([normalized]))), dtype=np.float32)
        vector = vector / max(float(np.linalg.norm(vector)), 1e-12)
        similarities = self.example_vectors @ vector

        # Average the two most relevant prototypes for each broad intent.
        scores: dict[Intent, float] = {}
        for intent in INTENT_EXAMPLES:
            values = [float(sim) for sim, label in zip(similarities, self.labels) if label == intent]
            top_two = sorted(values, reverse=True)[:2]
            scores[intent] = float(sum(top_two) / len(top_two))

        ranking = sorted(scores.items(), key=lambda pair: pair[1], reverse=True)
        best_intent, best_score = ranking[0]
        runner_up_score = ranking[1][1]
        margin = best_score - runner_up_score
        # The assignment prohibits out-of-scope classification on
        # embedding similarity alone. OUT_OF_SCOPE prototypes provide
        # contrast, but a nearest OUT_OF_SCOPE neighbor triggers
        # abstention/clarification, NOT a definitive out-of-scope label.
        abstained = (
            best_score < self.min_similarity
            or margin < self.min_margin
            or best_intent == Intent.OUT_OF_SCOPE
        )

        return SemanticIntentResult(
            intent=None if abstained else best_intent,
            similarity=round(best_score, 4),
            margin=round(margin, 4),
            abstained=abstained,
            scores={intent.value: round(score, 4) for intent, score in ranking},
        )
