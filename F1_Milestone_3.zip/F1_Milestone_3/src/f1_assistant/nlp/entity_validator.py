
from f1_assistant.contracts import (
    EntityExtraction,
    Intent,
    IntentPrediction,
)


# Each rule defines the expected broad intent and
# the exact number of required entities.
#
# We start with four question types.
# Others will be added as retrieval templates are built.

REQUIREMENTS = {
    "driver_season_podiums": (
        Intent.DRIVER_PERFORMANCE,
        {"drivers": 1, "years": 1},
    ),
    "driver_circuit_wins": (
        Intent.DRIVER_PERFORMANCE,
        {"drivers": 1, "circuits": 1},
    ),
    "constructor_season_points": (
        Intent.CONSTRUCTOR_PERFORMANCE,
        {"constructors": 1, "years": 1},
    ),
    "race_winner_or_podium": (
        Intent.RACE_RESULTS,
        {"races": 1},
    ),
    "driver_season_wins": (
        Intent.DRIVER_PERFORMANCE,
        {"drivers": 1, "years": 1},
    ),
    "constructor_season_wins": (
        Intent.CONSTRUCTOR_PERFORMANCE,
        {"constructors": 1, "years": 1},
    ),
    "circuit_location": (
        Intent.CIRCUIT_FACTS,
        {"circuits": 1},
    ),
    "driver_comparison": (
        Intent.HEAD_TO_HEAD,
        {"drivers": 2},
    ),
    "qualifying_position": (
        Intent.QUALIFYING_GRID,
        {"drivers": 1, "races": 1},
    ),
    "fastest_pit_stop": (
        Intent.PIT_STOP_STRATEGY,
        {"races": 1},
    ),
    "season_team_changes": (
        Intent.SEASON_HISTORY,
        {"years": 2},
    ),
}


def validate_entities(
    prediction: IntentPrediction,
    extraction: EntityExtraction,
) -> EntityExtraction:
    """
    Validate entities against the classified question type.

    Never guess missing values or select one of
    several ambiguous candidates.
    """

    result = EntityExtraction(
        entities=dict(extraction.entities),
        ambiguous={
            key: list(values)
            for key, values in extraction.ambiguous.items()
        },
    )

    if prediction.intent is None or prediction.needs_clarification:
        result.missing.append("recognized_intent")
        return result

    rule = REQUIREMENTS.get(prediction.question_type)

    if rule is None:
        # Fail safely until we implement this question type.
        result.missing.append("supported_question_type")
        return result

    expected_intent, required = rule

    if prediction.intent != expected_intent:
        result.missing.append("intent_question_type_mismatch")
        return result

    for entity_name, expected_count in required.items():
        values = result.entities.get(entity_name, [])

        if not isinstance(values, list):
            result.missing.append(entity_name)
            continue

        if len(values) < expected_count:
            result.missing.append(entity_name)

        elif len(values) > expected_count:
            result.ambiguous[entity_name] = [
                item.get("name", str(item))
                if isinstance(item, dict)
                else str(item)
                for item in values
            ]

    return result


def ready_for_query(validation: EntityExtraction) -> bool:
    """Only proceed when all required entities are resolved."""
    return (
        not validation.missing
        and not validation.ambiguous
    )
