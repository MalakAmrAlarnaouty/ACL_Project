
import re
import unicodedata

from f1_assistant.contracts import EntityExtraction
from f1_assistant.nlp.year_extractor import extract_year_entities


def normalize_name(text: str) -> str:
    """Normalize accents, punctuation, case, and spacing."""
    text = unicodedata.normalize("NFKD", text)
    text = "".join(
        char for char in text
        if not unicodedata.combining(char)
    )
    text = re.sub(r"[^\w\s]", " ", text.casefold())
    return " ".join(text.split())


def get_race_aliases(name: str) -> set[str]:
    """Support Grand Prix and GP naming."""
    normalized = normalize_name(name)
    aliases = {normalized}

    if normalized.endswith(" grand prix"):
        aliases.add(
            normalized[:-len(" grand prix")] + " gp"
        )

    return aliases


def extract_race_entities(
    question: str,
    races: list[dict],
) -> EntityExtraction:
    """
    Resolve a single named Grand Prix using its year.

    Missing or ambiguous information is reported
    rather than guessed.
    """
    result = EntityExtraction()
    text = normalize_name(question)

    # Build name aliases from real Neo4j records.
    alias_to_names = {}

    for race in races:
        name = race["race_name"]

        for alias in get_race_aliases(name):
            alias_to_names.setdefault(alias, set()).add(name)

    # Locate race-name mentions in the question.
    matches = []

    for alias, names in alias_to_names.items():
        pattern = r"(?<!\w)" + re.escape(alias) + r"(?!\w)"

        for match in re.finditer(pattern, text):
            matches.append((
                match.start(),
                match.end(),
                names,
            ))

    # Prefer longer matches when names overlap.
    matches.sort(
        key=lambda item: (
            -(item[1] - item[0]),
            item[0],
        )
    )

    occupied = []
    found_names = set()

    for start, end, names in matches:
        if any(
            start < other_end and end > other_start
            for other_start, other_end in occupied
        ):
            continue

        occupied.append((start, end))
        found_names.update(names)

    if not found_names:
        result.missing.append("race")
        return result

    # Multiple distinct race names require further handling.
    if len(found_names) > 1:
        result.ambiguous["race"] = sorted(found_names)
        return result

    race_name = next(iter(found_names))
    result.entities["race_name"] = race_name

    # Use our existing year extractor.
    year_result = extract_year_entities(question)
    years = year_result.entities.get("years", [])

    if not years:
        result.missing.append("year")
        return result

    if len(years) > 1:
        result.ambiguous["year"] = [
            str(year) for year in years
        ]
        return result

    year = years[0]
    result.entities["years"] = [year]

    # Resolve the exact graph race.
    candidates = [
        race for race in races
        if race["race_name"] == race_name
        and race["year"] == year
    ]

    if len(candidates) == 1:
        race = candidates[0]

        result.entities["races"] = [{
            "race_id": race["race_id"],
            "name": race_name,
            "year": year,
        }]

    elif not candidates:
        result.missing.append("race")

    else:
        result.ambiguous["race"] = [
            f"{race_name} ({year}), ID {race['race_id']}"
            for race in candidates
        ]

    return result
