"""Optional neural classifier for the *exact* 13 Milestone 3 question types.

Independent of the existing broad-intent neural prototype and pipeline.
Uses neural sentence embeddings; never uses similarity alone to declare OUT_OF_SCOPE.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any
import re

import numpy as np

# All implemented Cypher routes, plus prediction and out-of-scope.
# UNKNOWN is an abstention result, NOT an additional gold-label category.
QUESTION_TYPE_EXAMPLES: dict[str, tuple[str, ...]] = {
    "circuit_location": (
        "Find the country and town of an F1 racing venue.",
        "Give geographic details about a motorsport circuit.",
        "Where can this Formula One track be found?",
        "Identify the host city for a named race circuit.",
        "Tell me what nation this racing facility is situated in.",
        "Look up the location of this motorsport track.",
    ),
    "constructor_season_points": (
        "Calculate the championship score recorded by this racing team in one season.",
        "How many Grand Prix points were awarded to this constructor that year?",
        "Summarize the points accumulated by this Formula One squad during a championship.",
        "Report a team's total points across races in a selected season.",
        "Find the season points tally for a constructor.",
        "Show how many scoring points the team collected in that racing year.",
    ),
    "constructor_season_wins": (
        "Count the Grand Prix victories achieved by an F1 constructor in one season.",
        "How many times did this racing team take first place that year?",
        "Give the number of race wins for this constructor over the championship.",
        "What was the team's victory total for a particular season?",
        "Calculate the number of winning race entries for this Formula One team in that year.",
        "Tell me how many Grands Prix the team won during the season.",
    ),
    "driver_circuit_wins": (
        "Count one driver's historical victories at a selected track.",
        "How often did this racer win on that particular circuit?",
        "Give a driver's number of first-place results at a Formula One venue.",
        "Has this competitor ever taken a Grand Prix win at that track?",
        "What is the win count for a named racer at one circuit?",
        "Report victories by a driver at a specified racing location.",
    ),
    "driver_comparison": (
        "Compare the finishing order of two competitors in races they shared.",
        "Which teammate finished in front more frequently in shared events?",
        "Evaluate how often racer one beat racer two while both drove for the team.",
        "Give the head-to-head result of a pair of drivers at one constructor.",
        "Between these two Formula One teammates, who generally placed higher?",
        "Count shared races where one competitor was classified ahead of the other.",
    ),
    "driver_season_podiums": (
        "Find the number of top-three race results recorded by a driver in one year.",
        "What is this racer's season podium-finishes total?",
        "Count how many Grand Prix podium appearances this driver made that season.",
        "Provide the season total of first, second, or third-place finishes for a driver.",
        "How often did this competitor stand on the podium during a championship?",
        "Calculate a driver's podium count for a selected season.",
    ),
    "driver_season_wins": (
        "How many Formula One races did this driver win within one championship year?",
        "Report this racer's season victory count.",
        "Give the number of first-place Grand Prix results for a driver during that season.",
        "Calculate the total race wins achieved by this competitor in one year.",
        "Count victories by the named racer throughout a season.",
        "Show the driver's winning race total in that championship.",
    ),
    "fastest_pit_stop": (
        "Find the shortest recorded pit-lane duration in a specified Grand Prix.",
        "Which driver had the quickest pit visit at this race?",
        "Show the minimum elapsed time of a pit stop during the event.",
        "Identify the fastest measured pit lane stop in one Grand Prix.",
        "Look up the driver and duration for the least time spent at a pit stop.",
        "Report the smallest recorded pit-stop duration for the selected race.",
    ),
    "qualifying_position": (
        "What position did this Formula One driver achieve in qualifying at the event?",
        "Tell me where the racer placed during the qualifying session for a Grand Prix.",
        "Which qualifying rank did the competitor record at that race?",
        "Give the driver's official qualifying position for the specified weekend.",
        "Find the qualifying classification of the named racer at the given Grand Prix.",
        "Report the position earned by this driver in the qualification results.",
    ),
    "race_winner_or_podium": (
        "Identify the winner of one particular Formula One Grand Prix.",
        "Name the first three classified finishers in this individual race.",
        "Who took the race victory at the specified championship round?",
        "List the podium finishers for this one Grand Prix event.",
        "Give the names of the top three race finishers in the selected race.",
        "Which racer finished first in that Grand Prix?",
    ),
    "season_team_changes": (
        "Find drivers whose constructor affiliations differed across two seasons.",
        "Show the team membership changes from one championship year to another.",
        "Which racers competed for different constructors between the selected years?",
        "Compare driver-team participation across consecutive racing seasons.",
        "List Formula One drivers switching constructor representation from year one to year two.",
        "Report the changes in team assignments recorded for drivers across two years.",
    ),
    "podium_prediction": (
        "Predict the chances of finishing among the top three in a future race.",
        "Estimate this driver's likelihood of a podium before the Grand Prix begins.",
        "Forecast whether a competitor will get a podium in the upcoming event.",
        "Calculate a pre-race probability for a top-three finish.",
        "Give an estimated podium prediction for the next race weekend.",
        "What are the projected odds this racer reaches the podium?",
    ),
    "out_of_scope": (
        "Help me repair my laptop keyboard.",
        "Suggest a delicious lunch recipe for tomorrow.",
        "What is the largest desert on Earth?",
        "Teach me a few chords on the piano.",
        "How should I decorate my home office?",
        "Recommend a book about ancient Egypt.",
    ),
}

LABELS: tuple[str, ...] = tuple(QUESTION_TYPE_EXAMPLES)


@dataclass(frozen=True)
class QuestionTypeEmbeddingResult:
    question_type: str | None
    similarity: float
    margin: float
    abstained: bool
    scores: dict[str, float]
    method: str = "embedding_similarity"


class QuestionTypeEmbeddingClassifier:
    """Nearest-prototype classifier over the exact Milestone 3 label set.

    Similarity is not a confidence probability. The threshold values are
    provisional design settings, not calibrated on a final test set.
    ``encoder`` is optional and intended for deterministic unit tests.
    """

    def __init__(
        self,
        model_name: str = "BAAI/bge-small-en-v1.5",
        min_similarity: float = 0.43,
        min_margin: float = 0.01,
        encoder: Any = None,
    ) -> None:
        if not -1.0 <= min_similarity <= 1.0:
            raise ValueError("min_similarity must lie in [-1, 1]")
        if not 0.0 <= min_margin <= 2.0:
            raise ValueError("min_margin must lie in [0, 2]")
        self.min_similarity = min_similarity
        self.min_margin = min_margin
        if encoder is None:
            from fastembed import TextEmbedding
            encoder = TextEmbedding(model_name=model_name)
        self.encoder = encoder
        phrases = [p for samples in QUESTION_TYPE_EXAMPLES.values() for p in samples]
        self._example_labels = [k for k, samples in QUESTION_TYPE_EXAMPLES.items() for _ in samples]
        vectors = np.asarray(list(self.encoder.embed(phrases)), dtype=np.float32)
        if vectors.ndim != 2 or vectors.shape[0] != len(phrases):
            raise ValueError("Embedding model produced an unexpected number or shape of vectors")
        self._vectors = self._normalize(vectors)

    @staticmethod
    def _normalize(vectors: np.ndarray) -> np.ndarray:
        norms = np.maximum(np.linalg.norm(vectors, axis=-1, keepdims=True), 1e-12)
        return vectors / norms

    def predict(self, question: str) -> QuestionTypeEmbeddingResult:
        question = re.sub(r"\s+", " ", question).strip()
        if not question:
            return QuestionTypeEmbeddingResult(None, 0.0, 0.0, True, {})

        embeddings = list(self.encoder.embed([question]))
        if len(embeddings) != 1:
            raise ValueError("Embedding model must produce exactly one vector per question")
        vector = np.asarray(embeddings[0], dtype=np.float32)
        if vector.shape != (self._vectors.shape[1],):
            raise ValueError("Question embedding dimension does not match prototypes")
        vector = self._normalize(vector)
        similarity = self._vectors @ vector
        ranked_scores: list[tuple[str, float]] = []
        for label in LABELS:
            values = [float(sim) for sim, name in zip(similarity, self._example_labels) if name == label]
            best_two = sorted(values, reverse=True)[:2]
            ranked_scores.append((label, sum(best_two) / len(best_two)))
        ranked_scores.sort(key=lambda x: x[1], reverse=True)
        best_label, best_score = ranked_scores[0]
        margin = best_score - ranked_scores[1][1]
        # Out of scope MUST NOT be concluded from nearest-neighbor similarity.
        abstained = (
            best_score < self.min_similarity
            or margin < self.min_margin
            or best_label == "out_of_scope"
        )
        return QuestionTypeEmbeddingResult(
            question_type=None if abstained else best_label,
            similarity=round(best_score, 4),
            margin=round(margin, 4),
            abstained=abstained,
            scores={label: round(score, 4) for label, score in ranked_scores},
        )
