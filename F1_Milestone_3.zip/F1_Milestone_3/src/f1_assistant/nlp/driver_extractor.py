
import re
from collections import defaultdict

from f1_assistant.contracts import EntityExtraction


def normalize(text: str) -> str:
    """Normalize capitalization and whitespace."""
    return " ".join(text.casefold().split())


def find_mentions(text: str, name: str):
    """Find complete name mentions, not parts of words."""
    pattern = (
        r"(?<!\w)"
        + re.escape(normalize(name))
        + r"(?!\w)"
    )
    return list(re.finditer(pattern, text))


def extract_driver_entities(
    question: str,
    drivers: list[dict],
) -> EntityExtraction:
    """
    Extract driver IDs from a natural-language question.

    Full names take priority over surnames.
    Ambiguous surnames are reported, never guessed.
    """

    text = normalize(question)
    result = EntityExtraction()

    found = {}
    full_name_spans = []

    # Step 1: Find complete driver names.
    for driver in drivers:
        full_name = (
            f"{driver['first_name']} "
            f"{driver['last_name']}"
        )

        for match in find_mentions(text, full_name):
            full_name_spans.append(match.span())

            found[driver["driver_id"]] = {
                "driver_id": driver["driver_id"],
                "name": full_name,
            }

    # Step 2: Group drivers by surname.
    surname_map = defaultdict(list)

    for driver in drivers:
        surname = normalize(driver["last_name"])
        surname_map[surname].append(driver)

    # Step 3: Look for surname-only mentions.
    for surname, candidates in surname_map.items():
        for match in find_mentions(text, surname):

            # Skip surnames already included in a full name.
            inside_full_name = any(
                start <= match.start()
                and match.end() <= end
                for start, end in full_name_spans
            )

            if inside_full_name:
                continue

            if len(candidates) == 1:
                driver = candidates[0]

                found[driver["driver_id"]] = {
                    "driver_id": driver["driver_id"],
                    "name": (
                        f"{driver['first_name']} "
                        f"{driver['last_name']}"
                    ),
                }

            else:
                result.ambiguous[surname] = [
                    (
                        f"{driver['first_name']} "
                        f"{driver['last_name']}"
                    )
                    for driver in candidates
                ]

            break

    # Step 4: Return all uniquely identified drivers.
    if found:
        result.entities["drivers"] = list(found.values())

    # Step 5: Report missing drivers.
    if not found and not result.ambiguous:
        result.missing.append("driver")

    return result
