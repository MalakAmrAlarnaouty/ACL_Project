"""Combine F1 entity recognizers and resolve explicit cross-type name roles."""

import re

from f1_assistant.contracts import EntityExtraction
from f1_assistant.nlp.driver_extractor import extract_driver_entities
from f1_assistant.nlp.constructor_extractor import extract_constructor_entities
from f1_assistant.nlp.circuit_extractor import extract_circuit_entities
from f1_assistant.nlp.race_extractor import extract_race_entities
from f1_assistant.nlp.year_extractor import extract_year_entities


def _normalized(text: str) -> str:
    """Normalize punctuation and whitespace for role-context matching."""
    return " ".join(re.sub(r"[^\w\s]", " ", text.casefold()).split())


def _mentioned(text: str, name: str) -> bool:
    """Test a complete word-boundary phrase, not a substring."""
    if not name:
        return False
    return re.search(r"(?<!\w)" + re.escape(name) + r"(?!\w)", text) is not None


def _constructor_role_explicit(question: str, constructor_name: str) -> bool:
    """Check for language that identifies a constructor, not a driver surname.

    Example: "Norris versus Ricciardo at McLaren" uses McLaren as a team.
    Do not infer a constructor role from the bare word "McLaren" alone.
    """
    text = _normalized(question)
    name = _normalized(constructor_name)
    if not name:
        return False

    role_before = (
        r"\b(?:at|for|with|under|from|team|constructor|"
        r"driving\s+for|racing\s+for)\s+" + re.escape(name) + r"\b"
    )
    role_after = r"\b" + re.escape(name) + r"\s+(?:team|constructor)\b"
    return bool(re.search(role_before, text) or re.search(role_after, text))


def _driver_mention_position(question: str, driver: dict) -> int:
    """Order named drivers as mentioned, not by historical graph driverId."""
    text = _normalized(question)
    full = _normalized(driver.get("name", ""))
    # Prefer explicit full names; fall back to surname-only references.
    for term in (full, full.rsplit(" ", 1)[-1]):
        match = re.search(r"(?<!\w)" + re.escape(term) + r"(?!\w)", text)
        if match:
            return match.start()
    return len(text)


def _resolve_driver_constructor_collision(question: str, result: EntityExtraction) -> None:
    """Remove false surname-only drivers where the text explicitly means a team.

    Bruce McLaren, Jonathan Williams and other historical F1 drivers share
    their surnames with constructors. Never drop an explicitly named driver,
    even when their surname is also used elsewhere as a constructor name.
    """
    drivers = result.entities.get("drivers", [])
    constructors = result.entities.get("constructors", [])
    if not drivers or not constructors:
        return

    normalized_question = _normalized(question)
    explicitly_team_names = {
        _normalized(team.get("name", ""))
        for team in constructors
        if _constructor_role_explicit(question, team.get("name", ""))
    }
    if not explicitly_team_names:
        return

    retained = []
    for driver in drivers:
        name = _normalized(driver.get("name", ""))
        surname = name.rsplit(" ", 1)[-1]
        is_full_name_present = _mentioned(normalized_question, name)
        if surname in explicitly_team_names and not is_full_name_present:
            continue
        retained.append(driver)

    if retained:
        result.entities["drivers"] = retained
    else:
        result.entities.pop("drivers", None)

    # A team name can also be an ambiguous *surname* (for example Stewart).
    # If the wording explicitly names that constructor role, it must not
    # force an unrelated driver-name clarification. Other ambiguities stay.
    for surname in list(result.ambiguous):
        if _normalized(surname) in explicitly_team_names:
            has_explicit_driver = any(
                _mentioned(normalized_question, _normalized(candidate))
                for candidate in result.ambiguous[surname]
            )
            if not has_explicit_driver:
                del result.ambiguous[surname]


def extract_all_entities(
    question: str,
    drivers: list[dict],
    constructors: list[dict],
    circuits: list[dict],
    races: list[dict],
) -> EntityExtraction:
    """Extract all F1 entities, preserving ambiguous names for clarification.

    Missing fields are determined by the downstream, intent-specific validator.
    """
    result = EntityExtraction()

    extractions = [
        extract_driver_entities(question, drivers),
        extract_constructor_entities(question, constructors),
        extract_circuit_entities(question, circuits),
        extract_race_entities(question, races),
        extract_year_entities(question),
    ]

    for extraction in extractions:
        for key, value in extraction.entities.items():
            if key == "years":
                existing = result.entities.get("years", [])
                result.entities["years"] = list(dict.fromkeys(existing + value))
            else:
                result.entities[key] = value

        for key, candidates in extraction.ambiguous.items():
            result.ambiguous[key] = candidates

    _resolve_driver_constructor_collision(question, result)

    if "drivers" in result.entities:
        result.entities["drivers"].sort(
            key=lambda driver: _driver_mention_position(question, driver)
        )

    return result
