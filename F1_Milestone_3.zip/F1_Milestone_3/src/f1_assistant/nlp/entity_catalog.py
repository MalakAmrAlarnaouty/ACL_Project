
from f1_assistant.retrieval.neo4j_client import Neo4jClient


def load_drivers(db: Neo4jClient) -> list[dict]:
    """Load all drivers and their unique IDs."""

    query = """
        MATCH (d:Driver)
        RETURN
            d.driverId AS driver_id,
            d.forename AS first_name,
            d.surname AS last_name
        ORDER BY d.driverId
    """

    return db.run_read(query)


def load_constructors(db: Neo4jClient) -> list[dict]:
    """Load constructor names, references, and IDs."""

    query = """
        MATCH (c:Constructor)
        RETURN
            c.constructorId AS constructor_id,
            c.constructor_name AS constructor_name,
            c.constructorRef AS constructor_ref
        ORDER BY c.constructorId
    """

    return db.run_read(query)


def load_circuits(db: Neo4jClient) -> list[dict]:
    """Load circuits and their geographical information."""

    query = """
        MATCH (c:Circuit)
        RETURN
            c.circuitId AS circuit_id,
            c.circuit_name AS circuit_name,
            c.circuitRef AS circuit_ref,
            c.circuit_loc AS city,
            c.circuit_country AS country
        ORDER BY c.circuitId
    """

    return db.run_read(query)


def load_races(db: Neo4jClient) -> list[dict]:
    """Load Grand Prix names, years, and IDs."""

    query = """
        MATCH (r:Race)
        RETURN
            r.raceId AS race_id,
            r.name AS race_name,
            r.year AS year
        ORDER BY r.year, r.round, r.raceId
    """

    return db.run_read(query)
