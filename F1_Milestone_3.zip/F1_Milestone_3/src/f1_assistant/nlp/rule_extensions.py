﻿"""Additional deterministic F1 intent patterns."""
import re
from f1_assistant.contracts import Intent, IntentPrediction

RULES = [
    (Intent.PODIUM_PREDICTION, "podium_prediction", (
        r"\b(?:podium|top[\s-]+(?:3|three))\b",
        r"\b(?:odds|probability|chance|chances|likelihood|forecast)\b",
    )),
    (Intent.PIT_STOP_STRATEGY, "fastest_pit_stop", (
        r"\b(?:fastest|quickest|shortest|minimum|least)\b",
        r"\b(?:pit[\s-]?stops?|pit[\s-]?lane(?:\s+stop)?|pit\s+visits?)\b",
    )),
    (Intent.SEASON_HISTORY, "season_team_changes", (
        r"\b(?:driver\s+)?(?:team|constructor)\s+memberships?\b|"
        r"\b(?:constructor|team)\s+switch(?:es|ed|ing)?\b",
        r"\b(?:between|across|from|to|during)\b",
    )),
    (Intent.RACE_RESULTS, "race_winner_or_podium", (
        r"\b(?:gp|grand\s+prix)\b",
        r"\b(?:who\s+(?:took|claimed|secured)\s+(?:the\s+)?victory|"
        r"which\s+driver\s+won|who\s+occupied\s+(?:the\s+)?"
        r"top[\s-]+(?:3|three)\s+(?:places|positions))\b",
    )),
    (Intent.HEAD_TO_HEAD, "driver_comparison", (
        r"\b(?:who\s+had\s+(?:the\s+)?better\s+finishing\s+order|"
        r"finish(?:ed)?\s+ahead\s+of\b.*\bmore\s+often)\b",
    )),
    (Intent.DRIVER_PERFORMANCE, "driver_season_podiums", (
        r"\b(?:how\s+often|how\s+many|count|total)\b",
        r"\b(?:finish(?:es|ed)?\s+on\s+(?:the\s+)?podium|"
        r"podium\s+(?:finishes|placements|results))\b",
    )),
    (Intent.CIRCUIT_FACTS, "circuit_location", (
        r"\b(?:where\s+is|what\s+city|which\s+city|which\s+country|"
        r"in\s+which\s+country|located)\b",
        r"\b(?:circuit|track|interlagos|gilles[\s-]villeneuve)\b",
    )),
    (Intent.DRIVER_PERFORMANCE, "driver_circuit_wins", (
        r"\bever\s+won\b",
        r"\b(?:at|around|on)\b",
    )),
    (Intent.CONSTRUCTOR_PERFORMANCE, "constructor_season_wins", (
        r"\blotus\b",
        r"\b(?:wins?|won|victories|victory)\b",
        r"\b(?:in|during|season)\b",
        r"\b(?:19|20)\d{2}\b",
    )),
    (Intent.OUT_OF_SCOPE, "out_of_scope", (
        r"\b(?:tallest\s+mountain|guitar\s+chords?|"
        r"learn\s+(?:the\s+)?guitar|wear\s+to\s+a\s+wedding)\b",
    )),
]

def classify_extended(question: str) -> IntentPrediction | None:
    """Return a high-confidence route, or allow original rules to run."""
    for intent, question_type, patterns in RULES:
        if all(re.search(pattern, question) for pattern in patterns):
            return IntentPrediction(
                intent=intent,
                method="rule_based",
                question_type=question_type,
            )
    return None
